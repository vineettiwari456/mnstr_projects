import os
import mysql
import mysql.connector
import requests, zlib
import psutil, time
from datetime import datetime

main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sync_ids")
resume_insertpid = main_directory + "/user_insert_pid"
fd = open(resume_insertpid)
pidval = fd.read()
fd.close()
if pidval:
    if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
        print('Process is already running------', pidval)
        exit(0)
pidfile = open(resume_insertpid, 'w')
pidfile.write(str(os.getpid()))
pidfile.close()


class UserWorkPermitCountry:
    def __init__(self):
        self.max_time = int(time.time() * 1000)
        self.chunk = 1000
        self.logfilename = main_directory + "/insert_error_log"
        self.track_count = main_directory + "/job_count_log"
        # self.conf_falcon_write = {"user": str(os.getenv("USER")), "password": str(os.getenv("PASSWORD")),
        #                           "host": str(os.getenv("WRITE_HOST")),
        #                           "database": str(os.getenv("DATABASE_NAME"))}
        # self.conf_falcon_read = {"user": str(os.getenv("USER")), "password": str(os.getenv("PASSWORD")),
        #                          "host": str(os.getenv("READ_HOST")),
        #                          "database": str(os.getenv("DATABASE_NAME"))}
        # uvtiwari -pvtiwari@123## -h10.216.247.108 -A falcon
        # self.conf_falcon_read = {"user": "vtiwari", "password": "vtiwari@123##", "host": "10.216.247.108",
        #                    "database": "falcon"}
        self.conf_falcon_write = {"user": "vtiwari", "password": "vtiwari@123#", "host": "10.216.204.150",
                                  "database": "falcon"}
        self.conf_falcon_read = {"user": "vtiwari", "password": "vtiwari@123#", "host": "10.216.204.150",
                                  "database": "falcon"}
        connection_master, cursor_master = self.falcon_connection()
        query_master_loc = "select country,uuid from job_locations where site_context = 'monstergulf';"
        cursor_master.execute(query_master_loc)
        location_iso_raw = cursor_master.fetchall()
        self.location_iso_master = self.get_key_value_format_mapping(location_iso_raw)
        query_master_count = 'select iso_code,uuid from countries;'
        cursor_master.execute(query_master_count)
        countries_iso_raw = cursor_master.fetchall()
        self.countries_iso_master = self.get_country_format_mapping(countries_iso_raw)

    def falcon_connection(self):
        connection_falcon = mysql.connector.connect(user=self.conf_falcon_read['user'],
                                                    password=self.conf_falcon_read['password'],
                                                    host=self.conf_falcon_read['host'],
                                                    database=self.conf_falcon_read['database'])
        cursor_falcon = connection_falcon.cursor(dictionary=True)
        return connection_falcon, cursor_falcon

    def write_falcon_connection(self):
        connection_falcon = mysql.connector.connect(user=self.conf_falcon_write['user'],
                                                    password=self.conf_falcon_write['password'],
                                                    host=self.conf_falcon_write['host'],
                                                    database=self.conf_falcon_write['database'])
        cursor_falcon = connection_falcon.cursor(dictionary=True)
        return connection_falcon, cursor_falcon

    def execute_falcon_query(self, query):
        connection, cursor = self.falcon_connection()
        cursor.execute(query)
        all_data = cursor.fetchall()
        connection.close()
        return all_data

    def get_key_value_format_mapping(self, total_data):
        result = {}
        for da in total_data:
            result[str(da.get("uuid"))] = str(da.get("country")).lower()
        return result

    def get_country_format_mapping(self, total_data):
        result = {}
        for da in total_data:
            result[str(da.get("iso_code")).lower()] = str(da.get("uuid"))
        return result

    def write_log(self, logtext):
        logopenfile = open(self.logfilename, 'a')
        logopenfile.write(str(logtext))
        logopenfile.write("\n")
        logopenfile.close()

    def userid_log(self, ids):
        logopenfile = open(self.track_count, 'w')
        logopenfile.write(str(ids))
        # logopenfile.write("\n")
        logopenfile.close()

    def update_user_work_permit_countries(self, uwp_id_list):
        is_success = False
        try:
            uwp_ids = ','.join(uwp_id_list)
            update_query = "update user_work_permit_countries set deleted = 1 where id in (%s)" % (uwp_ids)
            conn, curr = self.write_falcon_connection()
            curr.execute(update_query)
            conn.commit()
            conn.close()
            is_success = True
        except Exception as err:
            logtext = "Error in update_user_work_permit_countries : " + str(err) + str(uwp_id_list)
            self.write_log(logtext)
            pass
        return is_success

    def insert_falcon_db(self, records):
        try:
            for rec in records:
                insert_query = """insert into user_work_permit_countries (`created_at`,`updated_at`,`deleted`,`country`,`user_id`,`visa_type_uuid`) values (%s,%s,%s,%s,%s,%s);"""
                conn, curr = self.write_falcon_connection()
                curr.executemany(insert_query, [rec])
                conn.commit()
                conn.close()
        except Exception as err:
            logtext = "Error in insert_falcon_db : " + str(err) + str(rec)
            self.write_log(logtext)
            pass

    def check_exist(self, all_user_data):
        insert_records = []
        need_to_update = []
        for u_id in all_user_data:
            user_id = u_id.get("userid")
            countryuuid = u_id.get("country_uuid")
            query = "select id, user_id from user_work_permit_countries where (deleted is null or deleted = 0) and user_id={0} and country='{1}' ;".format(
                user_id, countryuuid)
            if u_id.get("deleted"):
                deleted = u_id.get("deleted")
            else:
                deleted = 0
            user_records = self.execute_falcon_query(query)
            tup_record = (
                u_id.get("updated_at"), u_id.get("updated_at"), deleted, u_id.get("country_uuid"), u_id.get("userid"),
                u_id.get("uae_work_visa_type_uuid"))
            if len(user_records) > 0:
                insert_records.append(tup_record)
                for w_id in user_records:
                    need_to_update.append(str(w_id.get("id")))
            else:
                insert_records.append(tup_record)
        return list(set(insert_records)), need_to_update

    def map_country(self, all_user_profile_data):
        Total_data = []
        for md in all_user_profile_data:
            loc_records = self.location_iso_master.get(str(md.get("current_location_uuid")), None)
            if loc_records:
                uuid_country = self.countries_iso_master.get(loc_records, None)
                if uuid_country:
                    md["country_uuid"] = uuid_country
                    Total_data.append(md)
        return Total_data

    def get_user_work_permit(self):
        last_updated_time = main_directory + "/last_updated_time"
        read_file = open(last_updated_time)
        last_upadated_at = read_file.read()
        read_file.close()
        print(last_upadated_at)
        lastupdated_at_time = int(last_upadated_at)
        print("start time :", lastupdated_at_time)
        is_next = True
        job_count_read = open(self.track_count)
        count = int(job_count_read.read())
        job_count_read.close()
        while lastupdated_at_time and is_next:
            process_data = []
            need_to_update_data = []
            try:
                # query = "select us.id as userid,up.current_location_uuid,us.uae_work_visa_type_uuid,us.updated_at,up.deleted from users as us inner join user_profiles as up on us.id=up.user_id where up.enabled = 1 and (up.deleted is null or up.deleted = 0) and up.site_context='monstergulf' and us.uae_work_visa_type_uuid is not null and us.uae_work_visa_type_uuid!='' and us.id in (74705068)"
                query = "select us.id as userid,up.current_location_uuid,us.uae_work_visa_type_uuid,us.updated_at,up.deleted from users as us inner join user_profiles as up on us.id=up.user_id where up.enabled = 1 and (up.deleted is null or up.deleted = 0) and up.site_context='monstergulf' and us.uae_work_visa_type_uuid is not null and us.uae_work_visa_type_uuid!='' and (us.updated_at> {0} and us.updated_at<={1}) order by us.updated_at asc limit {2};".format(
                    lastupdated_at_time, self.max_time, self.chunk)
                print(query)
                userupdateddata = self.execute_falcon_query(query)
                print('data : ', len(userupdateddata))
                for j_time in userupdateddata:
                    lastupdated_at_time = j_time.get("updated_at")
                print("last time of chunck : ", lastupdated_at_time)
                # print userupdateddata
                if len(userupdateddata) > 0:
                    map_records = self.map_country(userupdateddata)
                    print ("map_records :", len(map_records))
                    if len(map_records) > 0:
                        count += len(map_records)
                        process_data, need_to_update_data = self.check_exist(map_records)
                        print ("insert---",process_data)
                        print ("update--",need_to_update_data)
                        print("Process for update data length ::", str(len(need_to_update_data)) + " Date : " + str(
                            datetime.now()))
                        if len(need_to_update_data) > 0:
                            is_success = self.update_user_work_permit_countries(need_to_update_data)
                            print ("Success ::", is_success)
                        print("Process for insert data length ::",
                              str(len(process_data)) + " Date : " + str(datetime.now()))
                        if len(process_data) > 0:
                            self.insert_falcon_db(process_data)
                        self.userid_log(count)
                last_writeid = open(last_updated_time, 'w')
                last_writeid.write(str(lastupdated_at_time))
                last_writeid.close()
                is_next = False
                if len(userupdateddata) == 0:
                    is_next = False
            except Exception as err:
                logtext = "Error in get_user_work_permit : " + str(err) + str(query) + str(process_data) + str(
                    need_to_update_data)
                self.write_log(logtext)
                print(logtext)
                pass


if __name__ == "__main__":
    obj = UserWorkPermitCountry()
    obj.get_user_work_permit()
