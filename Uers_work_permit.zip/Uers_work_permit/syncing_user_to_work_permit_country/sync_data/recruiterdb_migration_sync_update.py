# -*-coding:utf-8 -*-
import sys
import time
# import datetime
reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
from mysql.connector import pooling
import concurrent.futures
import sched,time
from datetime import datetime
from dateutil.parser import parse
startdate = datetime.now().strftime("%Y:%m:%d:%H:%M:%S")
print startdate
import os
import psutil
main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txtfiles")
savepid = main_directory+"/savepid"
fd = open(savepid)
pidval = fd.read()
fd.close()
if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
    print '------', pidval
    exit(0)
fd1 = open(savepid,'w')
fd1.write(str(os.getpid()))
fd1.close()

s = sched.scheduler(time.time, time.sleep)
def db1sl_connection():
    conf={"user": "readonly","password": "readonly","host": "10.216.248.117","database": "bazooka"}
    connection = mysql.connector.connect(user=conf['user'], password=conf['password'],
                                                     host=conf['host'],
                                                     database=conf['database'])
    cursor = connection.cursor(dictionary=True, buffered=True)
    return connection,cursor

def eagle_connection():
    conf_eagle = {"user": "migration", "password": "migration007", "host": "10.216.247.110", "database": "eagle"}
    connection_eagle = mysql.connector.connect(user=conf_eagle['user'], password=conf_eagle['password'],
                                         host=conf_eagle['host'],
                                         database=conf_eagle['database'])
    cursor_eagle = connection_eagle.cursor(dictionary=True)
    return connection_eagle,cursor_eagle


def get_industry_uuid(ind_id):
    ind_val=None
    if ind_id>0:
        connection_object, curs = db1sl_connection()
        query = "select name from industry where id=%s;"%(ind_id)
        # print query
        curs.execute(query)
        value_data = curs.fetchone()
        connection_object.close()
        if value_data:
            ind_name = value_data.get("name","")
            connection_obj_eag, cursor_read = eagle_connection()
            query1 = "select uuid from industries where id in (select industry_id from industry_langs where name ='%s');"%(ind_name)
            # print query1
            cursor_read.execute(query1)
            data = cursor_read.fetchone()
            if data:
               ind_val = data.get("uuid","")
            connection_obj_eag.close()
    return ind_val

def get_country_uuid(iso_code):
    iso_value = None
    if iso_code:
        connection_object, cursor_read = eagle_connection()
        query1 = "select uuid from countries where iso_code ='%s';" % (
            iso_code)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            iso_value= data.get("uuid", "")
        connection_object.close()
    return iso_value
# print get_country_uuid('IN')
def get_service_channel_id(service_name):
    service_id = None
    if service_name:
        connection_object, cursor_read = eagle_connection()
        query1 = "select id from service_channels where name ='%s';" % (
            service_name)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            service_id= data.get("id", "")
        connection_object.close()
    return service_id

def get_city_uuid(city_name, id):
    cityuuid = None
    if city_name:
        connection_object, cursor_read = eagle_connection()
        query1 = "select uuid from job_locations where id in (select job_location_id from job_location_langs where name ='%s');" % (
            city_name)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            cityuuid =  data.get("uuid", "")
        connection_object.close()
    return cityuuid
# print '=============', get_city_uuid("Kolkata")
def get_extra_info_value(info_data):
    aor_exp_date = None
    cjt_exp_date =None
    rec_social_profile =None
    orig_service_channel_id=None
    customize_type=None
    company_list=None
    if info_data:
        try:
            extra_value = info_data.replace("~", '')
            extra_info_list = extra_value.split(":")
            for value in extra_info_list:
                if 'AOR_EXP_DATE' in value:
                    aor_exp_date  = value.split("=")[-1].strip()
                if 'CJT_EXP_DATE' in value:
                    cjt_exp_date  = value.split("=")[-1].strip()
                if 'REC_SOCIAL_PROFILE' in value:
                    rec_social_profile  = value.split("=")[-1].strip()
                if 'ORIG_SERVICE_CHANNEL' in value:
                    orig_service_channel_id = get_service_channel_id(value.split("=")[-1].strip())
                if 'CUSTOMIZE_TYPE' in value:
                    customize_type  = value.split("=")[-1].strip()
                if 'COMPANY_LIST' in value:
                    company_list  = value.split("=")[-1].strip()
        except Exception as exc:
            print 'get_extra_info_value', exc
            pass
    return aor_exp_date, cjt_exp_date,rec_social_profile,orig_service_channel_id,customize_type,company_list

def get_dateunixtimestamp(datatime_data):
    flag_time = False
    if datatime_data:
        # print datatime_data
        # import datetime
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime(y, m, day, h, mi, sec)
        else:
            d = datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple()))*1000
        return unixtime
    else:
        return int(time.time()*1000)
# print get_dateunixtimestamp("2104-10-2")
def get_logo_url(logocode, xcode):
    if logocode:
        if 'JDLOGO' in logocode:
            if xcode:
                return "https://media.monsterindia.com/logos/"+str(xcode).strip()+"/jdlogo.gif"
            else:
                return None
        else:
            return None
    else:
        return None
def get_corp_profile(corpid):
    profile_text = None
    if corpid:
        connection_object, cursor_read = db1sl_connection()
        query1 = "select profile from corps_profile where corp_id =%s;" % (
            corpid)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            profile_text = data.get("profile", None)
        connection_object.close()
    return profile_text


def get_site_context(subchannelid):
    site = {1: "rexmonster", 2: "monstergulf", 6: "monstersingapore", 8: "monsterthailand",
            7: "monsterphilippines", 9: "monstervietnam", 11: "monstermalaysia", 10: "monsterindonesia",
            5: "monsterhongkong"}
    site_context = None
    try:
        if subchannelid:
            site_context = site.get(subchannelid)
    except:
        pass
    return site_context

def get_corp_profile_url_insert(corps_id, kiwicordid):
    total_profile1 = []
    if kiwicordid:
        connection_object, cursor_read = db1sl_connection()
        query = "select * from corps_brandings where type = 'CP' and corp_id='%s';" % (
            kiwicordid)
        cursor_read.execute(query)
        datalist= cursor_read.fetchall()
        for data in datalist:
            if data:
                if data.get("extra_info",None):
                    if data.get("extra_info",None).split(":")[-1]:
                        total_profile=[]
                        total_profile.append(corps_id)
                        total_profile.append(data.get("enabled",None))
                        total_profile.append(data.get("extra_info",None).split(":")[-1])
                        total_profile.append(get_dateunixtimestamp(data.get("created", None)))
                        total_profile.append(get_dateunixtimestamp(data.get("updated", None)))
                        total_profile.append(get_dateunixtimestamp(data.get("expiry", None)))
                        total_profile.append(data.get("channel_id",None))
                        total_profile.append(get_site_context(data.get("subchannel_id", None)))
                        total_profile1.append(tuple(total_profile))
            connection_object.close()
    return total_profile1

def get_extra_info_cjt_value(info_data):
    cjt_exp_date =None
    if info_data:
        try:
            extra_value = info_data.replace("~", '')
            extra_info_list = extra_value.split(":")
            for value in extra_info_list:
                if 'CJT_EXP_DATE' in value:
                    cjt_exp  = value.split("=")[-1].strip()
                    parse(str(cjt_exp))
                    cjt_exp_date  = value.split("=")[-1].strip()
        except Exception as exc:
            print 'get_extra_info_value', exc
            pass
    return cjt_exp_date

def get_corps_service_record(new_corp_id,row):
    temp = []
    if new_corp_id:
        is_microsite='0'
        is_cjt = '0'
        if row["customize"]=='1':
            is_microsite='1'
        if row["customize"]=='2':
            is_cjt='1'
        if row["customize"]=='3':
            is_cjt='1'
            is_microsite = '1'
        temp.append(is_microsite)
        temp.append(is_cjt)
        cjt_exp_date = get_extra_info_cjt_value(
            row["extra_info"])
        temp.append(cjt_exp_date)
        temp.append(get_dateunixtimestamp(row["currdt"]))
        temp.append(int(time.time() * 1000))
        temp.append(new_corp_id)
    return temp

def add_or_update_corp_id(lastupdatetime):
    total_corpsid = []
    connection_object, cursor = db1sl_connection()
    query = "SELECT distinct(cp.id) FROM corps AS cp LEFT JOIN corps_brandings AS cb ON cp.id=cb.corp_id LEFT JOIN corps_profile AS gcp ON cp.id=gcp.corp_id WHERE ((cp.updated> cp.created) OR (cb.updated>cb.created) OR  (gcp.updated>=gcp.created))  AND ((cp.updated>='%s') OR (cb.updated>='%s') OR (gcp.updated>='%s'));"%(lastupdatetime,lastupdatetime,lastupdatetime)
    print query
    cursor.execute(query)
    total_corpsid = cursor.fetchall()
    # print total_corpsid
    if len(total_corpsid)>0:
        total_corpsid = [str(l.get("id", None)) for l in total_corpsid if l.get("id", None)]
    connection_object.close()
    return total_corpsid

def fetch_data(updatetime):
    total_data_main = []
    connection_object, cursor = db1sl_connection()
    addorupdated_corpid = add_or_update_corp_id(updatetime)
    # print addorupdated_corpid
    query = "select * from corps where id in ('" + "','".join(addorupdated_corpid) + "');"
    print query
    cursor.execute(query)
    total_data_main = cursor.fetchall()
    connection_object.close()
    return total_data_main

def get_pcp_value(valuedata):
    val1 = None
    val2 = None
    if valuedata:
        naame = valuedata.split()
        if len(naame) > 1:
            val1 = naame[0]
            val2 = ' '.join(naame[1:])
    return val1, val2

def get_evaluated_temp_corps_record(row):
    value_none = None
    temp = []
    temp.append(row["xcode"])
    temp.append(row["name"])
    temp.append(row["short_name"])
    temp.append(row["phone"])
    temp.append(row["address"])
    temp.append(row["url"])
    temp.append(row["email"])
    temp.append(str(row["loginexpires"]))
    temp.append(row["maxagent"])
    temp.append(row["enabled"])
    temp.append(get_industry_uuid(row["industry"]))
    if row["pcp_name"]:
        naame = row["pcp_name"].split()
        if len(naame) > 1:
            temp.append(naame[0])
            temp.append(' '.join(naame[1:]))
        else:
            temp.append(row["pcp_name"])
            temp.append(value_none)
    else:
        temp.append(value_none)
        temp.append(value_none)
    # temp.append(row["pcp_name"])
    if row["package_purchased"]:
        temp.append(row["package_purchased"])
    else:
        temp.append(value_none)
    if row["company_type"]:
        temp.append(row["company_type"])
    else:
        temp.append(value_none)
    temp.append(row["redirect_url"])
    temp.append(get_logo_url(row["logos"], row["xcode"]))
    temp.append(get_city_uuid(row["city"], row["id"]))
    temp.append(row["city"])
    temp.append(get_country_uuid(row["country"]))
    temp.append(row["mail_report"])
    temp.append(row["company_website"])
    temp.append(row["customize"])
    if row["service_type"]:
        temp.append(row["service_type"])
    else:
        temp.append(value_none)
    temp.append(get_service_channel_id(row["service_channel"]))
    temp.append(row["redirect_url_control"])
    temp.append(row["can_edit_compname"])
    temp.append(row["keep_confidential"])
    temp.append(row["ip_restriction"])
    aor_exp_date, cjt_exp_date, rec_social_profile, orig_service_channel_id, customize_type, company_list = get_extra_info_value(
        row["extra_info"])
    temp.append(aor_exp_date)
    temp.append(cjt_exp_date)
    temp.append(rec_social_profile)
    temp.append(orig_service_channel_id)
    temp.append(customize_type)
    temp.append(company_list)
    temp.append(row["xcode"])
    temp.append(row["id"])
    temp.append(get_corp_profile(row["id"]))
    temp.append(get_dateunixtimestamp(row["currdt"]))
    temp.append(int(time.time() * 1000))
    temp.append(value_none)
    return temp

def checckifExist(kiwicorpid):
    is_present = False
    corpid = None
    connection_object, cursor = eagle_connection()
    query1 = "select id from corps where kiwi_corp_id ='%s';" % (
        kiwicorpid)
    # print query1
    cursor.execute(query1)
    data = cursor.fetchone()
    if data:
        is_present = True
        corpid = data.get("id", None)
    connection_object.close()

    return is_present, corpid

def checkexistin_corp_profile_url(new_corp_id):
    is_present = False
    connection_object, cursor = eagle_connection()
    query1 = "select id from corp_profile_url where corp_id ='%s';" % (
        new_corp_id)
    # print query1
    cursor.execute(query1)
    data = cursor.fetchone()
    if data:
        is_present = True
    connection_object.close()

    return is_present

def checkexistin_corp_service(new_corp_id):
    is_present = False
    connection_object, cursor = eagle_connection()
    query1 = "select id from corp_service where corp_id ='%s';" % (
        new_corp_id)
    # print query1
    cursor.execute(query1)
    data = cursor.fetchone()
    if data:
        is_present = True
    connection_object.close()
    return is_present

def migrate(total_dataupdate):
    connection_object, cursor_write = eagle_connection()
    i=0
    for rows in total_dataupdate:
        try:
            is_prensentid, corps_newid = checckifExist(rows["id"])
            print is_prensentid, corps_newid
            if is_prensentid:
                temp = get_evaluated_temp_corps_record(rows)
                # print '*'*10
                temp.append(corps_newid)
                ssourcesql = 'UPDATE corps SET corp_id=%s,name=%s,short_name=%s,phone=%s,address=%s,apply_url=%s,email=%s,login_expire_at=%s,max_login_account=%s,enabled=%s,industry_uuid=%s,owner_first_name=%s,owner_last_name=%s,package_purchased=%s,company_type=%s,redirect_url=%s,logo_url=%s,city_uuid=%s,city_text=%s,country_uuid=%s,mail_report=%s,company_website=%s,customize=%s,service_type=%s,service_channel_id=%s,redirect_url_control=%s,can_edit_company_name=%s,keep_confidential=%s,ip_restriction=%s,aor_exp_date=%s,cjt_exp_date=%s,rec_social_profile=%s,orig_service_channel_id=%s,customize_type=%s,company_list=%s,kiwi_xcode=%s,kiwi_corp_id=%s,profile=%s,created_at=%s,updated_at=%s,created_by_uuid=%s,latest_updated=now() where id=%s'
                ssourceval = tuple(temp)
                # print
                cursor_write.execute(ssourcesql, ssourceval)
                get_corp_profile_url_records = get_corp_profile_url_insert(corps_newid, rows["id"])
                if len(get_corp_profile_url_records) > 0:
                    sql_deljbwalkadd = "delete from corp_profile_url where corp_id=%s" % (corps_newid)
                    cursor_write.execute(sql_deljbwalkadd)
                    ssourcesqlinsert = 'insert into corp_profile_url (corp_id,enabled,profile_url,created_at,updated_at,expires_at,channel_id,site_context) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)'
                    ssourcevalinsert = get_corp_profile_url_records
                    cursor_write.executemany(ssourcesqlinsert, ssourcevalinsert)
                    """is_corp_profile = checkexistin_corp_profile_url(corps_newid)
                    if is_corp_profile:
                        lastcorpid = get_corp_profile_url_records[0]
                        get_corp_profile_url_rec = get_corp_profile_url_records[1:]
                        get_corp_profile_url_rec.append(corps_newid)
                        # print get_corp_profile_url_rec
                        ssourcesql = 'UPDATE corp_profile_url SET enabled=%s,profile_url=%s,created_at=%s,updated_at=%s,expires_at=%s,channel_id=%s,site_context=%s where corp_id=%s'
                        ssourceval = tuple(get_corp_profile_url_rec)
                        cursor_write.execute(ssourcesql, ssourceval)
                    else:
                        ssourcesqlinsert = 'insert into corp_profile_url (corp_id,enabled,profile_url,created_at,updated_at,expires_at,channel_id,site_context) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)'
                        ssourcevalinsert = tuple(get_corp_profile_url_records)
                        cursor_write.execute(ssourcesqlinsert, ssourcevalinsert)"""
                temp_service = get_corps_service_record(corps_newid,rows)
                is_corp_service = checkexistin_corp_service(corps_newid)
                if is_corp_service:
                    if len(temp_service) > 0:
                        ssourcesql1 = 'UPDATE corp_service SET is_microsite=%s,is_cjt=%s,cjt_expiry_date=%s,created_at=%s,updated_at=%s where corp_id=%s'
                        ssourceval1 = tuple(temp_service)
                        #print ssourceval1
                        cursor_write.execute(ssourcesql1, ssourceval1)
                else:
                    if len(temp_service)>0:
                        temp_service2 = temp_service[:-1]
                        temp_service2.insert(0,corps_newid)
                        print temp_service2
                        ssourcesq2 = 'insert into corp_service (corp_id,is_microsite,is_cjt,cjt_expiry_date,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                        ssourceva2 = tuple(temp_service2)
                        # print ssourceval
                        cursor_write.execute(ssourcesq2, ssourceva2)
                if i==10:
                    connection_object.commit()
                    i=0
                i+=1
                print "corps updated with id : "+str(rows["id"])+" Time : "+str(datetime.now().strftime("%Y:%m:%d:%H:%M:%S"))
        except Exception as e:
            print e
            pass
    connection_object.commit()
    connection_object.close()

def set_scheduler_function_update():
    corp_updatetime = main_directory+"/corp_updatetime"
    corp_file = open(corp_updatetime)
    corp_last_update = corp_file.read()
    corp_file.close()
    print '============================',corp_last_update
    total_data_main = fetch_data(corp_last_update)
    print 'Total corps update : ',len(total_data_main)
    migrate(total_data_main)
    corp_file = open(corp_updatetime,'w')
    corp_file.write(str(startdate))
    corp_file.close()

if __name__ == "__main__":
    set_scheduler_function_update()
    # s.enter(60, 1, set_scheduler_function, (s,))
    # s.run()


