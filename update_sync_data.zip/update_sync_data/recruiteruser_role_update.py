# -*-coding:utf-8 -*-

import sys
import time
import datetime
reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
import bcrypt
import uuid
import json
# import phonenumbers
import re
from hashlib import md5
from Crypto.Cipher import DES
import string
import os
import psutil
from decouple import config

startdate_recruiter = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# print startdate_recruiter
main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txtfiles")
corpaccount_insertid = main_directory+"/recruiter_update_pid"
"""fd = open(corpaccount_insertid)
pidval = fd.read()
fd.close()
if pidval:
    if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
        print 'Process is already running------', pidval
        exit(0)
fd1 = open(corpaccount_insertid,'w')
fd1.write(str(os.getpid()))
fd1.close()"""

def bcryptencrypt(passwd):
    salt = bcrypt.gensalt(rounds=10)
    password_hashed = bcrypt.hashpw(passwd, salt)
    # password_hashed=bcrypt.using(ident="2a").hash(passwd)
    return password_hashed

def check_is_crypt(passwd, uid):
    salt = str(uid) + '1lLVV0O'
    if len(passwd) % 16 == 0 and len(passwd) >= 16 and re.findall(r'^[A-Fa-f0-9]+$', passwd) != []:
        cipher = DES.new(md5(salt).digest()[:8], DES.MODE_CBC, IV="mnstcypt")
        str1 = cipher.decrypt(passwd.decode("hex"))
        return ''.join(str(c) for c in str1 if c in string.printable)
    return passwd

def get_bycrypt_password(passwd, idval):
    password = None
    try:
        password = bcryptencrypt(check_is_crypt(str(passwd).encode('UTF-8'), str(idval)))
        if password != None:
            password = '{bcrypt}' + password
    except Exception as e:
        print e
        pass
    return password

def db1sl_connection():
    conf={"user": config('DB_BAZOOKA_USER'), "password": config('DB_BAZOOKA_PASS'), "host": config('DB_BAZOOKA_HOST'), "database": config('DB_BAZOOKA')}
    connection = mysql.connector.connect(user=conf['user'], password=conf['password'],
                                                     host=conf['host'],
                                                     database=conf['database'])
    cursor = connection.cursor(dictionary=True,buffered=True)
    return connection,cursor

def eagle_connection():
    conf_eagle = {"user": config('DB_EAGLE_USER'), "password": config('DB_EAGLE_PASS'), "host": config('DB_EAGLE_HOST'), "database": config('DB_EAGLE')}
    connection_eagle = mysql.connector.connect(user=conf_eagle['user'], password=conf_eagle['password'],
                                         host=conf_eagle['host'],
                                         database=conf_eagle['database'])
    cursor_eagle = connection_eagle.cursor(dictionary=True)
    return connection_eagle,cursor_eagle


def rio_qa1_connection():
    conf_rio = {"user": config('DB_RIO_USER'), "password": config('DB_RIO_PASS'), "host": config('DB_RIO_HOST'), "database": config('DB_RIO')}
    connection_rio = mysql.connector.connect(user=conf_rio['user'], password=conf_rio['password'],
                                             host=conf_rio['host'],
                                             database=conf_rio['database'])
    cursor_rio = connection_rio.cursor(dictionary=True)
    return connection_rio, cursor_rio

def get_key_value_format_mapping(total_data):
    result = {}
    for da in total_data:
        da_list = da.values()
        result[str(da_list[0]).lower().strip()] = da_list[1]
    return result

def master_fetch_data_from_eagle_database():
    connection_master, cursor_master = eagle_connection()
    query_master_count = 'select  cl.name, ct.iso_code from countries as ct inner join country_langs as cl on cl.country_id=ct.id;'
    cursor_master.execute(query_master_count)
    countries_iso_raw = cursor_master.fetchall()
    countries_iso_master = get_key_value_format_mapping(countries_iso_raw)
    query_master_job_location = 'select jll.name,jl.uuid from job_locations as jl inner join job_location_langs as jll on jl.id= jll.job_location_id;'
    cursor_master.execute(query_master_job_location)
    countries_locuuid_raw = cursor_master.fetchall()
    job_locationuuid_name_master = get_key_value_format_mapping(countries_locuuid_raw)
    query_master_searc_cmp = 'select scl.name,sc.uuid from search_companies as sc inner join search_company_langs as scl on sc.id= scl.search_company_id;'
    cursor_master.execute(query_master_searc_cmp)
    compsearch = cursor_master.fetchall()
    search_cmpuuid_name_master = get_key_value_format_mapping(compsearch)
    query_master_hiring_level = 'select hll.hiring_level_id,hl.uuid from hiring_levels as hl inner join hiring_level_langs as hll on hl.id= hll.hiring_level_id;'
    cursor_master.execute(query_master_hiring_level)
    hiring_level_raw = cursor_master.fetchall()
    hiring_leveluuid_name_master = get_key_value_format_mapping(hiring_level_raw)
    query_master_indus = 'select indl.name,ind.uuid from industries as ind inner join industry_langs as indl on ind.id= indl.industry_id;'
    cursor_master.execute(query_master_indus)
    industry_raw = cursor_master.fetchall()
    industry_data_master = get_key_value_format_mapping(industry_raw)
    query_master_functionrole = 'select farl.name,far.uuid from function_and_roles as far inner join function_and_role_langs as farl on far.id= farl.function_and_role_id;'
    cursor_master.execute(query_master_functionrole)
    functionrole_raw = cursor_master.fetchall()
    function_role_data_master = get_key_value_format_mapping(functionrole_raw)
    query_master_designatioon = 'select dll.name,dl.uuid from designations as dl inner join designation_langs as dll on dl.id= dll.designation_id;'
    cursor_master.execute(query_master_designatioon)
    designation_raw = cursor_master.fetchall()
    designation_data_master = get_key_value_format_mapping(designation_raw)
    query_master_skill = 'select skl.name,sk.uuid from skills as sk inner join skill_langs as skl on sk.id= skl.skill_id;'
    cursor_master.execute(query_master_skill)
    skill_raw = cursor_master.fetchall()
    skill_data_master = get_key_value_format_mapping(skill_raw)
    connection_master.close()
    return countries_iso_master, job_locationuuid_name_master, search_cmpuuid_name_master, hiring_leveluuid_name_master, industry_data_master, function_role_data_master, designation_data_master, skill_data_master
countries_iso_master, job_locationuuid_name_master, search_cmpuuid_name_master, hiring_leveluuid_name_master, industry_data_master, function_role_data_master, designation_data_master, skill_data_master = master_fetch_data_from_eagle_database()

def get_recruiter_name(cfname, clname, sfname, slname):
    first_name = None
    last_name = None
    full_name = None
    if sfname:
        first_name = sfname.strip().encode("utf8")
    else:
        if cfname:
            first_name = cfname.strip().encode("utf8")
    if slname:
        last_name = slname.strip().encode("utf8")
    else:
        if clname:
            last_name = clname.strip().encode("utf8")

    if first_name:
        full_name = first_name.strip().encode("utf8")
    if last_name:
        try:
            if full_name:
                full_name += " " + last_name.strip().encode("utf8")
            else:
                full_name = last_name.strip().encode("utf8")
        except Exception as e:
            # print e, first_name, last_name
            pass

    return first_name, last_name, full_name

channel_map = {
    "1": "India",
    "2": "Gulf",
    "5": "Hong Kong",
    "6": "Singapore",
    "10": "Indonesia",
    "7": "Philippines",
    "8": "Thailand",
    "9": "Vietnam",
    "11": "Malaysia"
}

def get_country_isocode(isoval):
    iso_code = None
    # print isoval, countries_iso_master
    if isoval:
        country_val = channel_map.get(str(isoval), None)
        if country_val:
            iso_code = countries_iso_master.get(str(country_val).strip().lower(), None)
    return iso_code

def get_dateunixtimestamp(datatime_data):
    flag_time = False
    if datatime_data:
        # print datatime_data
        # import datetime
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime.datetime(y, m, day, h, mi, sec)
        else:
            d = datetime.datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple())) * 1000
        return unixtime
    else:
        return int(time.time() * 1000)

def get_site_context(subchannelid, channelid):
    site = {1: "rexmonster", 2: "monstergulf", 6: "monstersingapore", 8: "monsterthailand",
            7: "monsterphilippines", 9: "monstervietnam", 11: "monstermalaysia", 10: "monsterindonesia",
            5: "monsterhongkong"}
    site_context = None
    try:
        if subchannelid:
            site_context = site.get(int(subchannelid))
            if site_context == None:
                if channelid:
                    site_context = site.get(int(channelid))
        else:
            if site_context == None:
                if channelid:
                    site_context = site.get(int(channelid))
    except:
        pass
    return site_context


def get_location_uuid(loc_id):
    ind_name = None
    jobuuid = None
    if loc_id:
        connet, curs = db1sl_connection()
        if "," in str(loc_id):
            loc_id = str(loc_id).split(",")[0]
        query = "select name from job_locations where id=%s;" % (loc_id)
        # print query
        curs.execute(query)
        value_data = curs.fetchone()
        ind_name = value_data.get("name", "")
        connet.close()
        jobuuid = job_locationuuid_name_master.get(str(ind_name).lower().strip(), None)
    return jobuuid, ind_name

def get_company_uuid(cmp_name):
    cmpuuid = None
    if cmp_name:
        cmpuuid = search_cmpuuid_name_master.get(str(cmp_name).lower().strip(), None)
    return cmpuuid


def recruiter_client_hiring_for_insert(recruiterid, is_enable, cmp_names, createdate, updatedate):
    Total_company_values = []
    enable = '0'
    if is_enable:
        if '0' in str(is_enable):
            enable = "1"
    if cmp_names:
        eagcon_hire, eagcur_hire = eagle_connection()
        if len(cmp_names.split(",")) > 0:
            for cmp_name in cmp_names.split(","):
                if cmp_name:
                    temp_cmp = []
                    cmpuuid = search_cmpuuid_name_master.get(str(cmp_name).lower().strip(), None)
                    temp_cmp.append(recruiterid)
                    temp_cmp.append(cmpuuid)
                    temp_cmp.append(cmp_name)
                    temp_cmp.append(enable)
                    temp_cmp.append(createdate)
                    temp_cmp.append(updatedate)
                    Total_company_values.append(tuple(temp_cmp))
            eagcon_hire.close()
            return Total_company_values
        else:
            [(recruiterid, None, None, enable, createdate, updatedate)]
    else:
        return [(recruiterid, None, None, enable, createdate, updatedate)]


def recruiter_level_hire_for_insert(recruiterid, is_enable, level_id, createdate, updatedate):
    Total_tmp_level_for = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if level_id:
            if len(level_id.split(",")) > 0:
                for cmp_name in level_id.split(","):
                    temp_level = []
                    if cmp_name:
                        leveluuid = hiring_leveluuid_name_master.get(str(cmp_name).lower().strip(), None)
                        if leveluuid:
                            temp_level.append(recruiterid)
                            temp_level.append(leveluuid)
                            temp_level.append(enable)
                            temp_level.append(createdate)
                            temp_level.append(updatedate)
                            Total_tmp_level_for.append(tuple(temp_level))
            return Total_tmp_level_for
    except:
        pass
    return Total_tmp_level_for


def recruiter_industry_insert(recruiterid, is_enable, industry_id, createdate, updatedate):
    Total_industry = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if industry_id:
            connet, curs = db1sl_connection()
            if len(industry_id.split(",")) > 0:
                for cmp_name in industry_id.split(","):
                    temp_ind = []
                    if cmp_name:
                        query = "select name from industry where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            induuid = industry_data_master.get(value_data.get("name").lower().strip(), None)
                            if induuid:
                                temp_ind.append(recruiterid)
                                temp_ind.append(induuid)
                                temp_ind.append(enable)
                                temp_ind.append(createdate)
                                temp_ind.append(updatedate)
                                Total_industry.append(tuple(temp_ind))
            # eagcon_industry.close()
            connet.close()
            return Total_industry
    except:
        pass
    return Total_industry


def recruiter_function_insert(recruiterid, is_enable, function_id, createdate, updatedate):
    Total_function = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if function_id:
            connet, curs = db1sl_connection()
            if len(function_id.split(",")) > 0:
                for cmp_name in function_id.split(","):
                    temp_func = []
                    if cmp_name:
                        query = "select name from job_categories where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            funcuuid = function_role_data_master.get(value_data.get("name").lower().strip())
                            if funcuuid:
                                temp_func.append(recruiterid)
                                temp_func.append(funcuuid)
                                temp_func.append(enable)
                                temp_func.append(createdate)
                                temp_func.append(updatedate)
                                Total_function.append(tuple(temp_func))
            # eagcon_industry.close()
            connet.close()
            return Total_function
    except:
        pass
    return Total_function


def get_designationuuid(designat):
    desiguuid = None
    if designat:
        desiguuid = designation_data_master.get(designat.strip().lower(), None)
    return desiguuid


def get_start_end_date(date_year):
    start_date = None
    end_date = None
    if date_year:
        if 'present' in date_year.lower():
            if '-' in date_year:
                date_value = date_year.split("-")
                start_date = date_value[0].strip()+"-01-01"
        else:
            if '-' in date_year:
                date_value = date_year.split("-")
                if len(date_value) == 2:
                    start_date = date_value[0].strip() + '-01-01'
                    end_date = date_value[1].strip() + "-12-31"
    return start_date, end_date


def recruiter_achieve_and_work_history_insert(recruiterid, social_id):
    Total_achieve = []
    Total_work_history = []
    try:
        if social_id:
            # eagcon_function, eagcur_function = eagle_connection()
            connet, curs = db1sl_connection()
            query = "select * from rec_social_profile_exp_achieve where social_id='%s';" % (
                social_id)
            # print query
            curs.execute(query)
            for row_data in curs:
                if row_data["type"] == "ach":
                    if row_data["description"]:
                        temp_achive = []
                        temp_achive.append(recruiterid)
                        temp_achive.append(row_data["description"].encode("utf8"))
                        years = None
                        if row_data["year"]:
                            years = row_data["year"] + "-01-01"
                        temp_achive.append(years)
                        enable = '0'
                        if row_data["enabled"]:
                            if '0' in str(row_data["enabled"]):
                                enable = "1"
                        temp_achive.append(enable)
                        temp_achive.append(get_dateunixtimestamp(str(row_data["createdate"])))
                        temp_achive.append(get_dateunixtimestamp(str(row_data["updatedate"])))
                        # print '===========>>>',len(temp_achive)
                        Total_achieve.append(tuple(temp_achive))
                if row_data["type"] == "exp":
                    if row_data["company_name"]:
                        temp_exp = []
                        designat_uuid = get_designationuuid(row_data["designation"])
                        temp_exp.append(recruiterid)
                        temp_exp.append(designat_uuid)
                        temp_exp.append(row_data["designation"])
                        cmp_uuid = get_company_uuid(row_data["company_name"])
                        temp_exp.append(cmp_uuid)
                        temp_exp.append(row_data["company_name"])
                        startdate, enddate = get_start_end_date(row_data["year"])
                        temp_exp.append(startdate)
                        temp_exp.append(enddate)
                        temp_exp.append(row_data["is_current"])
                        temp_exp.append(row_data["enabled"])
                        temp_exp.append(get_dateunixtimestamp(str(row_data["createdate"])))
                        temp_exp.append(get_dateunixtimestamp(str(row_data["updatedate"])))
                        # print '<<<<<<===========>>>', len(temp_exp)
                        Total_work_history.append(tuple(temp_exp))
    except Exception as exc:
        # print exc
        pass
    return Total_achieve, Total_work_history


def recruiter_skills_insert(recruiterid, is_enable, skills_data, createdate, updatedate):
    Total_skills = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if skills_data:
            if len(skills_data.split(",")) > 0:
                for cmp_name in skills_data.split(","):
                    temp_skill = []
                    if cmp_name:
                        skilluuid = skill_data_master.get(cmp_name.strip().lower(), None)
                        temp_skill.append(recruiterid)
                        temp_skill.append(skilluuid)
                        temp_skill.append(cmp_name.strip().encode("utf8"))
                        temp_skill.append(enable)
                        temp_skill.append(createdate)
                        temp_skill.append(updatedate)
                        Total_skills.append(tuple(temp_skill))
            return Total_skills
    except:
        pass
    return Total_skills


def get_image_id(rec_social_profile_id):
    image_id = None
    if rec_social_profile_id:
        connet, curs = db1sl_connection()
        query = "select * from rec_social_profile_image where recruiter_profile_id=%s;" % (rec_social_profile_id)
        # print query
        curs.execute(query)
        value_data = curs.fetchone()
        # print value_data
        connet.close()
        if value_data:
            eagcon, eagcur = eagle_connection()
            ssourcesql_image = 'insert into recruiter_image (image_name,image_type,image_data,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
            ssourceval_image = (
                value_data.get("image_name", ""), value_data.get("image_type", ""), value_data.get("image_data", ""),
                get_dateunixtimestamp(value_data.get("createdate", "")),
                get_dateunixtimestamp(value_data.get("updatedate", "")))
            eagcur.execute(ssourcesql_image, ssourceval_image)
            eagcur.execute("select LAST_INSERT_ID() as id")
            image_id = eagcur.fetchone()['id']
            eagcon.commit()
            eagcon.close()
            # print 'imageid++++++++++++++',image_id
    return image_id
    # return None


# print get_image_id("1010")
def get_is_job_isemail(extra_value):
    isjob = '0'
    isemail = '0'
    if extra_value:
        email_job_data = json.loads(str(extra_value))
        isjob = email_job_data.get("JOB", '0')
        isemail = email_job_data.get("EMAIL", '0')
    return isjob, isemail


def check_deleted(is_enable):
    enable = '0'
    if is_enable:
        if '0' in str(is_enable):
            enable = "1"
    return enable


def get_corp_account_id(login_account):
    corp_id = []
    connection_eagle_account_read, cursor_eagle_account_read = eagle_connection()
    query = "select id from corp_account where kiwi_login_id='%s';" % (login_account.replace("'",""))
    #print query, login_account
    cursor_eagle_account_read.execute(query)
    for df in cursor_eagle_account_read:
        if df:
            corp_id.append(str(df.get("id", "")))
    # print corp_id
    return ','.join(corp_id)

def get_image_update_id(rec_social_profile_id, imgid):
    image_id = None
    if imgid:
        if rec_social_profile_id:
            connection, cursor = db1sl_connection()
            query = "select * from rec_social_profile_image where recruiter_profile_id=%s;" % (rec_social_profile_id)
            # print query
            cursor.execute(query)
            value_data = cursor.fetchone()
            connection.close()
            if value_data:
                connection_eag, eagcur = eagle_connection()
                ssourcesql_image = 'UPDATE recruiter_image SET image_name=%s,image_type=%s,image_data=%s,created_at=%s,updated_at=%s where id=%s'
                ssourceval_image = (
                    value_data.get("image_name", ""), value_data.get("image_type", ""),
                    value_data.get("image_data", ""),
                    get_dateunixtimestamp(value_data.get("createdate", "")),
                    get_dateunixtimestamp(value_data.get("updatedate", "")), imgid)
                eagcur.execute(ssourcesql_image, ssourceval_image)
                connection_eag.commit()
                connection_eag.close()
                image_id = imgid
    else:
        image_id = get_image_id(rec_social_profile_id)
    return image_id


def checckifExist(kiwicorpid):
    is_present = False
    corp_userid = None
    uuid_user = None
    images_id = None
    connection, cursor = eagle_connection()
    # query1 = "select id from users where kiwi_user_id ='%s';" % (kiwicorpid)
    query1 = "select id, uuid, image_id from recruiters where kiwi_subuid ='%s';" % (kiwicorpid)
    # print query1
    cursor.execute(query1)
    data = cursor.fetchone()
    if data:
        is_present = True
        corp_userid = data.get("id", None)
        uuid_user = data.get("uuid", None)
        images_id = data.get("image_id", None)
    connection.close()
    return is_present, corp_userid, uuid_user, images_id

def get_all_data_from_db1sl(lastrecid):
    if lastrecid:
        connection, cursor = db1sl_connection()
        query = '''SELECT a.id,a.passwd,a.first_name,a.last_name, a.enabled as enb_corp,a.createdate,a.login,a.passwd_change_date,
        b.id as id_social_profile,b.social_name,b.email,b.fname,b.lname,b.mobile,b.country_code,b.current_position,b.current_location,b.current_company,b.address,b.profile_image,b.image_status,
        b.total_hiring_exp,b.client_hire_for,b.
        level_hire_for,b.skills_hire_for,b.industry,b.function,b.profile_desc,b.enabled as enb_profile,
        b.profile_status,b.createdate as createdate_profile,b.updatedate as updatedate_profile,b.lastactive,b.cid,b.scid,b.extrainfo,
        b.profile_pin,b.pin_updated,c.corpid,c.subuid,c.social_id
        FROM corps_login a
        LEFT JOIN rec_social_profile_mapping c ON c.subuid=a.id and c.profile_enabled='1'
        LEFT JOIN rec_social_profile b ON b.id = c.social_id where ((a.updated>a.created) OR (b.updatedate>b.createdate) OR (c.updatedate>c.createdate)) AND ((a.updated>'%s') OR (b.updatedate>'%s') OR (c.updatedate>'%s'))
        ;'''%(lastrecid, lastrecid,lastrecid)
        cursor.execute(query)
        recruter_total_data = cursor.fetchall()
        connection.close()
    return recruter_total_data
def recruiter_user_role_update(recut_time):
    # Flag =False
    connection_write, cursor_write = rio_qa1_connection()
    i = 0
    connection_eagle_recruiter_write, cursor_eagle_recruiter_write = eagle_connection()
    recruter_total_data_main = get_all_data_from_db1sl(recut_time)
    print 'recruter_total_data_main update: ',len(recruter_total_data_main)
    for row in recruter_total_data_main:
        try:
            is_prensentid, recruiter_id, uuid_user, imageid = checckifExist(row["id"])
            if is_prensentid:
                value_none = None
                temp = []
                # temp.append(str(uuid.uuid4()))
                temp.append(get_bycrypt_password(row["passwd"], row["id"]))
                fname, lname, fullname = get_recruiter_name(row["first_name"], row["last_name"], row["fname"], row["lname"])
                temp.append(fname)
                temp.append(lname)
                temp.append(fullname)
                temp.append(row["cid"])
                temp.append(get_country_isocode(row["scid"]))
                if row["enb_corp"]:
                    temp.append(row["enb_corp"])
                else:
                    temp.append('0')
                temp.append(get_dateunixtimestamp(row["createdate"]))
                temp.append(int(time.time() * 1000))
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(value_none)
                temp.append(get_site_context(row["scid"], row["cid"]))
                temp.append(row["id"])
                temp.append(uuid_user)
                ssourcesql_rio = 'UPDATE users SET password=%s,first_name=%s,last_name=%s,full_name=%s,site=%s,country=%s,status=%s,created_at=%s,updated_at=%s,aadhar_number=%s,avatar=%s,dob=%s,gender=%s,gender_text=%s,marital_status=%s,marital_status_text=%s,passport_number=%s,nationality=%s,nationality_text=%s,religion=%s,religion_text=%s,site_context=%s,kiwi_user_id=%s where uuid=%s'
                ssourceval_rio = tuple(temp)
                cursor_write.execute(ssourcesql_rio, ssourceval_rio)

                recruiter_data = []
                # recruiter_data.append(uuid_user)
                loc_uuid, loc_name = get_location_uuid(row["current_location"])
                recruiter_data.append(loc_uuid)
                recruiter_data.append(loc_name)
                if row["total_hiring_exp"]:
                    recruiter_data.append(row["total_hiring_exp"])
                else:
                    recruiter_data.append(None)
                recruiter_data.append(row["current_position"])
                recruiter_data.append(get_company_uuid(row["current_company"]))
                recruiter_data.append(row["current_company"])
                recruiter_data.append(row["address"])
                recruiter_data.append(row["profile_desc"])
                recruiter_data.append(row["id_social_profile"])
                recruiter_data.append(row["email"])
                recruiter_data.append(row["mobile"])
                recruiter_data.append(get_image_update_id(row["id_social_profile"], imageid))  # get image id
                recruiter_data.append(None)
                recruiter_data.append(row["enb_profile"])
                if row["profile_status"]:
                    recruiter_data.append(row["profile_status"])
                else:
                    recruiter_data.append(None)
                recruiter_data.append(get_dateunixtimestamp(row["createdate_profile"]))
                recruiter_data.append(get_dateunixtimestamp(row["updatedate_profile"]))
                recruiter_data.append(get_dateunixtimestamp(row["lastactive"]))
                is_job, is_email = get_is_job_isemail(row["extrainfo"])
                recruiter_data.append(is_job)
                recruiter_data.append(is_email)
                recruiter_data.append(row["id"])
                recruiter_data.append(recruiter_id)
                # print len(recruiter_data), recruiter_data
                ssourcesql_recruiter = 'UPDATE recruiters SET current_location_uuid=%s,current_location_text=%s,experience=%s,current_position_text=%s,current_company_uuid=%s,current_company_text=%s,address=%s,profile_description=%s,kiwi_social_id=%s,email=%s,mobile=%s,image_id=%s,image_url=%s,enabled=%s,profile_status=%s,created_at=%s,updated_at=%s,last_active_at=%s,is_job=%s,is_email=%s, kiwi_subuid=%s where id=%s'
                ssourceval_recruiter = tuple(recruiter_data)
                cursor_eagle_recruiter_write.execute(ssourcesql_recruiter, ssourceval_recruiter)

                recruiter_client_hiring_records = recruiter_client_hiring_for_insert(recruiter_id, row["enb_profile"],
                                                                                     row["client_hire_for"],
                                                                                     get_dateunixtimestamp(
                                                                                         row["createdate_profile"]),
                                                                                     get_dateunixtimestamp(
                                                                                         row["updatedate_profile"]))
                # print 'sourcsql_client_hiring++++++++++', recruiter_client_hiring_records
                sql_del_hire = "delete from recruiter_client_hiring_for where recruiter_id=%s" % (recruiter_id)
                cursor_eagle_recruiter_write.execute(sql_del_hire)
                for records_hire in recruiter_client_hiring_records:

                    sourcsql_client_hiring = 'insert into recruiter_client_hiring_for (recruiter_id,client_company_uuid,client_company_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                    cursor_eagle_recruiter_write.execute(sourcsql_client_hiring, records_hire)
                    # sourcsql_client_hiring = 'UPDATE recruiter_client_hiring_for SET client_company_uuid=%s,client_company_text=%s,deleted=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                    # records_hire_tmp = records_hire[1:] + (recruiter_id,)
                    # cursor_eagle_recruiter_write.execute(sourcsql_client_hiring, records_hire_tmp)

                recruiter_level_hire_for_records = recruiter_level_hire_for_insert(recruiter_id, row["enb_profile"],
                                                                                   row["level_hire_for"],
                                                                                   get_dateunixtimestamp(
                                                                                       row["createdate_profile"]),
                                                                                   get_dateunixtimestamp(
                                                                                       row["updatedate_profile"]))
                # print '-----------', recruiter_level_hire_for_records
                # ssourcesql_level_for = 'UPDATE recruiter_hiring_level SET hiring_level_uuid=%s,deleted=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                if len(recruiter_level_hire_for_records) > 0:
                    sql_del_level = "delete from recruiter_hiring_level where recruiter_id=%s" % (recruiter_id)
                    cursor_eagle_recruiter_write.execute(sql_del_level)
                    for level_data in recruiter_level_hire_for_records:
                        ssourcesql_level_for = 'insert into recruiter_hiring_level (recruiter_id,hiring_level_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                        cursor_eagle_recruiter_write.execute(ssourcesql_level_for, level_data)
                        #
                        # level_data_tmp = level_data[1:] + (recruiter_id,)
                        # cursor_eagle_recruiter_write.execute(ssourcesql_level_for, level_data_tmp)

                recruiter_skills_data = recruiter_skills_insert(recruiter_id, row["enb_profile"], row["skills_hire_for"],
                                                                get_dateunixtimestamp(row["createdate_profile"]),
                                                                get_dateunixtimestamp(row["updatedate_profile"]))
                # print recruiter_skills_data
                # ssourcesql_skill = 'UPDATE recruiter_skill SET skill_uuid=%s,skill_text=%s,deleted=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                if len(recruiter_skills_data) > 0:
                    sql_skill = "delete from recruiter_skill where recruiter_id=%s" % (recruiter_id)
                    cursor_eagle_recruiter_write.execute(sql_skill)
                    for skill_data in recruiter_skills_data:

                        ssourcesql_skill = 'insert into recruiter_skill (recruiter_id,skill_uuid,skill_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                        cursor_eagle_recruiter_write.execute(ssourcesql_skill, skill_data)
                        # skill_data_tmp = skill_data[1:] + (recruiter_id,)
                        # cursor_eagle_recruiter_write.execute(ssourcesql_skill, skill_data_tmp)
                recruiter_industry_data = recruiter_industry_insert(recruiter_id, row["enb_profile"], row["industry"],
                                                                    get_dateunixtimestamp(row["createdate_profile"]),
                                                                    get_dateunixtimestamp(row["updatedate_profile"]))
                # print '000000000000',recruiter_industry_data
                # ssourcesql_industry = 'UPDATE recruiter_industry SET industry_uuid=%s,deleted=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                if len(recruiter_industry_data) > 0:
                    sqldel_indus = "delete from recruiter_industry where recruiter_id=%s" % (recruiter_id)
                    cursor_eagle_recruiter_write.execute(sqldel_indus)
                    for indus_data in recruiter_industry_data:
                        ssourcesql_industry = 'insert into recruiter_industry (recruiter_id,industry_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                        cursor_eagle_recruiter_write.execute(ssourcesql_industry, indus_data)
                        # indus_data_tmp = indus_data[1:] + (recruiter_id,)
                        # cursor_eagle_recruiter_write.execute(ssourcesql_industry, indus_data_tmp)
                recruiter_function_data = recruiter_function_insert(recruiter_id, row["enb_profile"], row["function"],
                                                                    get_dateunixtimestamp(row["createdate_profile"]),
                                                                    get_dateunixtimestamp(row["updatedate_profile"]))
                # print '========>>>>',recruiter_function_data,row["function"]
                if len(recruiter_function_data) > 0:
                    sql_delfunc = "delete from recruiter_function where recruiter_id=%s" % (recruiter_id)
                    cursor_eagle_recruiter_write.execute(sql_delfunc)
                    # ssourcesql_function = 'UPDATE recruiter_function SET function_uuid=%s,deleted=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                    for funct_data in recruiter_function_data:

                        ssourcesql_function = 'insert into recruiter_function (recruiter_id,function_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                        cursor_eagle_recruiter_write.execute(ssourcesql_function, funct_data)
                        # funct_data_tmp = funct_data[1:] + (recruiter_id,)
                        # cursor_eagle_recruiter_write.execute(ssourcesql_function, funct_data_tmp)
                recruiter_portability_setting_data = (
                    row["social_name"], row["profile_pin"], get_dateunixtimestamp(row["createdate_profile"]),
                    get_dateunixtimestamp(row["updatedate_profile"]), recruiter_id)
                ssourcesql_portability = 'UPDATE recruiter_portability_setting SET social_name=%s,profile_pin=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                # print recruiter_portability_setting_data
                cursor_eagle_recruiter_write.execute(ssourcesql_portability, recruiter_portability_setting_data)
                recruiter_achieve, work_history_data = recruiter_achieve_and_work_history_insert(recruiter_id,
                                                                                                 row["id_social_profile"])
                if len(recruiter_achieve) > 0:
                    sql_delachie = "delete from recruiter_achievement where recruiter_id=%s" % (recruiter_id)
                    cursor_eagle_recruiter_write.execute(sql_delachie)
                    # ssourcesql_achieve = 'UPDATE recruiter_achievement SET description=%s,achievement_date=%s,deleted=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                    for achieve_data in recruiter_achieve:

                        ssourcesql_achieve = 'insert into recruiter_achievement (recruiter_id,description,achievement_date,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                        cursor_eagle_recruiter_write.execute(ssourcesql_achieve, achieve_data)
                        # achieve_data_tmp = achieve_data[1:] + (recruiter_id,)
                        # cursor_eagle_recruiter_write.execute(ssourcesql_achieve, achieve_data_tmp)
                if len(work_history_data) > 0:
                    sql_delworkhist = "delete from recruiter_work_history where recruiter_id=%s" % (recruiter_id)
                    cursor_eagle_recruiter_write.execute(sql_delworkhist)
                    # ssourcesql_work_history = 'UPDATE recruiter_work_history SET designation_uuid=%s,designation_text=%s,company_uuid=%s,company_text=%s,start_date=%s,end_date=%s,is_current_company=%s,enabled=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                    for work_hist in work_history_data:
                        ssourcesql_work_history = 'insert into recruiter_work_history (recruiter_id,designation_uuid,designation_text,company_uuid,company_text,start_date,end_date,is_current_company,enabled,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                        cursor_eagle_recruiter_write.execute(ssourcesql_work_history, work_hist)
                        # work_hist_tmp = work_hist[1:] + (recruiter_id,)
                        # cursor_eagle_recruiter_write.execute(ssourcesql_work_history, work_hist_tmp)
                # # print len(work_history_data)
                # corp_account_id = get_corp_account_id(row["login"])
                deletd_val = check_deleted(row["enb_corp"])
                # # break
                ssourcesql_corp_account_recruiter = 'UPDATE corp_account_recruiter SET deleted=%s,created_at=%s,updated_at=%s where recruiter_id=%s'
                ssourceVal_corp_account_recruiter = (
                    deletd_val, get_dateunixtimestamp(row["createdate"]),
                    get_dateunixtimestamp(row["passwd_change_date"]), recruiter_id)
                # print '==========', ssourceVal_corp_account_recruiter
                if '' not in ssourceVal_corp_account_recruiter:
                    cursor_eagle_recruiter_write.execute(ssourcesql_corp_account_recruiter,
                                                         ssourceVal_corp_account_recruiter)
                if i == 10:
                    connection_write.commit()
                    connection_eagle_recruiter_write.commit()
                    i = 0
                i += 1
                print 'New recruiter update id: '+ str(recruiter_id)+ " Old recruiter Id : "+str(row["id"])+" Time : "+str(datetime.datetime.now().strftime("%Y:%m:%d:%H:%M:%S"))
        except Exception as e:
            print e
            pass
    connection_write.commit()
    connection_eagle_recruiter_write.commit()
    connection_write.close()
    connection_eagle_recruiter_write.close()

def run_recruiter_role_update_script():
    recruiter_updatetime = main_directory + "/recruiteruserrole_updatetime"
    recruiter_file = open(recruiter_updatetime)
    recruiter_last_update = recruiter_file.read()
    recruiter_file.close()
    if recruiter_last_update:
        print recruiter_last_update
        recruiter_user_role_update(recruiter_last_update)
        recaccount_file = open(recruiter_updatetime, 'w')
        recaccount_file.write(str(startdate_recruiter))
        recaccount_file.close()

if __name__ == "__main__":
    run_recruiter_role_update_script()

