# -*-coding:utf-8 -*-

import sys
import requests
import re
import copy
import operator, pymongo
from bs4 import BeautifulSoup
import json, time, uuid
from datetime import datetime, timedelta
reload(sys)
sys.setdefaultencoding("utf-8")
import urllib3
from urlparse import urljoin
import concurrent.futures
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from pymongo import MongoClient
client = MongoClient("localhost", 27017)
db = client.JobData
coll = db.malaysia_jobs1
coll_demo = db.malaysia_jobs

class ScraperMalaysia:
    
    def __init__(self):
        self.date_field = datetime.now().strftime("%d:%m:%Y")
        self.headers = {
                'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; WOW64)\
                AppleWebKit/537.36 (KHTML'}
        
    def scrape_job_value(self, url_link, posted_date):
        #posted_date = ""
        #print url_link
        session = requests.session()
        resp = session.get(url_link, timeout=40, headers = self.headers)
        #print resp
        if resp.status_code == 200:
            dic = {}
            su = BeautifulSoup(str(resp.text),'html.parser')
            position_title = ""
            company_name = ""
            about_company = ""
            location = ""
            requirements = ""
            role_and_responsibilities = ""
            experience_required = ""
            work_location = ""
            raw_title = su.find("h1",{"id":"position_title"})
            if raw_title:
                position_title = ' '.join(raw_title.text.split()).encode("utf8")
            raw_company_name = su.find("div", {"id":"company_name"})
            if raw_company_name:
                company_name = raw_company_name.text.strip().encode("utf8")
                
            raw_about_company = su.find("div", {"id":"company_overview_all"})
            if raw_about_company:
                about_company = ' '.join(raw_about_company.text.split()).encode("utf8")
            raw_location = su.find("span", {"id":"single_work_location"})
            if raw_location:
                location = ' '.join(raw_location.text.split()).encode("utf8")
            raw_experience = su.find("span", {"id":"years_of_experience"})
            if raw_experience:
                experience_required = ' '.join(raw_experience.text.split()).encode("utf8")
            raw_work_loc = su.find("p", {"id":"address"})
            if raw_work_loc:
                work_location = ' '.join(raw_work_loc.text.split()).encode("utf8")
            
            #print about_company#location,company_name,position_title
            raw_jd = su.find("div", {"id":"job_description"})
            if raw_jd:
                raw_div = raw_jd.find_all("div")
                #print len(raw_div)
                if len(raw_div)>0:
                    raw_requirement = [j for j in raw_div if j if 'Requirement' in j.text if (len(j.text)>12 and len(j.text)<15)]
                    if len(raw_requirement)>0:
                        try:
                            requirements = ' '.join(raw_requirement[0].next_sibling.text.split())
                        except:
                            requirements = ' '.join(raw_requirement[0].findNext("ul").text.split())
                            pass
                        if requirements=="":
                            try:
                                requirements = ' '.join(raw_requirement[0].next_sibling.next_sibling.text.split())
                            except:
                                requirements = ' '.join(raw_requirement[0].next_sibling.next_sibling.text.split())
                                pass
                    else:
                        requirements = ' '.join(raw_jd.text.split()).encode("utf8")
            
                else:
                    requirements = ' '.join(raw_jd.text.split()).encode("utf8")
                role_and_responsibilities = ' '.join(raw_jd.text.split()).encode("utf8")
            
          
        dic["position_title"] = position_title
        dic["company_name"] = company_name
        dic["about_company"] = about_company
        dic["location"] = location
        dic["requirements"] = requirements
        dic["role_and_responsibilities"] = role_and_responsibilities
        dic["experience_required"] = experience_required
        dic["work_location"] = work_location
        dic["job_url"] = url_link
        dic["crawled_date"] = self.date_field
        dic["job_posted_date"] = posted_date
        #print dic
        if position_title !="":
            return dic
        else:
            #print url_link
            return None
        
        
    def crawl(self, url, days):
#         is_page = True
#         i=2
#         All_urls = []
#         while is_page:
#             print url
#             session = requests.session()
#             res = session.get(url, timeout=40, headers = self.headers)
#             print res.status_code
#             if res.status_code == 200:
#                 soup = BeautifulSoup(str(res.text),'html.parser')
#                 raw_job_section = soup.find_all("div",{"itemtype":"http://schema.org/JobPosting"})
#                 if len(raw_job_section)>0:
#                     for job_so in raw_job_section:
#                         date_check = job_so.find("span", {"class":"job-date-text text-muted"})
#                         if date_check:
#                             date_value = date_check.text.strip()
#                             #print date_value
#                             date_range = 0
#                             post = ""
#                             if '-' in date_value:
#                                 val = date_value.split("-")[0]+'2018'
#                                 from dateutil import parser
#                                 datetime_object = parser.parse(val)
#                                 a= datetime.date(datetime_object)
#                                 b = datetime.date(datetime.now())
#                                 diff = b-a
#                                 date_range = diff.days
#                                 post = datetime_object.strftime("%d/%m/%Y")
#                                 #a = datetime.strptime(str(datetime_object.strftime("%m/%d/%Y")),"%m/%d/%Y")
#                                 #b= datetime.strptime(datetime.now().strftime("%m/%d/%Y"),"%m/%d/%Y")
#                                 #print '==', date_range, type(date_range)
#                             if ("minute" in date_value.lower()) or ('hour' in date_value.lower()):
#                                 post = self.date_field
#                             if 'yesterday' in date_value.lower():
#                                 yesterday = datetime.now() - timedelta(days=1)
#                                 post = yesterday.strftime("%d:%m:%Y")
#                                 
#                             if ('yesterday' in date_value.lower()) or  ("minute" in date_value.lower()) or ('hour' in date_value.lower()) or (date_range<=days):
#                                 print date_value, date_range, post
#                                 raw_job_link = job_so.find("a", {"class":"position-title-link"})
#                                 if raw_job_link:
#                                     temp = []
#                                     job_link = raw_job_link.get("href")
#                                     temp.append(job_link)
#                                     temp.append(post)
#                                     All_urls.append(temp)
#                             
#                             else:
#                                 is_page = False
#                 url = "https://www.jobstreet.com.my/en/job-search/job-vacancy/"+str(i)+"/"
#                 i = i+1
#                 #is_page = False
#             else:
#                 is_page = False
#                 
#         
#         All_urls = [list(item) for item in set(tuple(row) for row in All_urls)]
#         print 'All_urls',len(All_urls)
        #f = open('malesia_urls.txt','wb')
        #f.write(str(All_urls))
        #f.close()
        f=open('malesia_urls.txt','rb')
        All_urls = eval(f.read())
        f.close()
        print len(All_urls)
        Total_data = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=40) as executor:
            future_to_url = {executor.submit(self.scrape_job_value, url_jb[0], url_jb[1]): url_jb for url_jb in
                             All_urls}
            for future in concurrent.futures.as_completed(future_to_url):
                url2 = future_to_url[future]
                try:
                    data = future.result()
                    if data:
                        Total_data.append(data)
                        coll.insert(data)
                except Exception as exc:
                    print '=====>', url2, exc
                    pass
        return Total_data
            
if __name__=="__main__":
    obj = ScraperMalaysia()
    main_url = "https://www.jobstreet.com.my/en/job-search/job-vacancy/1/"
    data_obj = obj.crawl(main_url, 10)
#     data_obj = obj.scrape_job_value("https://www.jobstreet.com.my/en/job/marketing-executive-ipoh-3638582?fr=J&src=16",'jj')
#     print len(data_obj),data_obj
    coll_demo.insert(data_obj)
    
    
    
    
    