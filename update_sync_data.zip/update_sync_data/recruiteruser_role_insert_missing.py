# -*-coding:utf-8 -*-

import sys
import time
import datetime
reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
import bcrypt
import uuid
from decouple import config
import json
# import phonenumbers
import re
from hashlib import md5
from Crypto.Cipher import DES
import string
import os
import psutil

main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txtfiles")
corpaccount_insertid = main_directory+"/recruiterrole_insert_pid"
"""fd = open(corpaccount_insertid)
pidval = fd.read()
fd.close()
if pidval:
    if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
        print 'Process is already running------', pidval
        exit(0)
fd1 = open(corpaccount_insertid,'w')
fd1.write(str(os.getpid()))
fd1.close()"""
def bcryptencrypt(passwd):
    salt = bcrypt.gensalt(rounds=10)
    password_hashed = bcrypt.hashpw(passwd, salt)
    # password_hashed=bcrypt.using(ident="2a").hash(passwd)
    return password_hashed

def check_is_crypt(passwd, uid):
    salt = str(uid) + '1lLVV0O'
    if len(passwd) % 16 == 0 and len(passwd) >= 16 and re.findall(r'^[A-Fa-f0-9]+$', passwd) != []:
        cipher = DES.new(md5(salt).digest()[:8], DES.MODE_CBC, IV="mnstcypt")
        str1 = cipher.decrypt(passwd.decode("hex"))
        return ''.join(str(c) for c in str1 if c in string.printable)
    return passwd

def get_bycrypt_password(passwd, idval):
    password = None
    try:
        password = bcryptencrypt(check_is_crypt(str(passwd).encode('UTF-8'), str(idval)))
        if password != None:
            password = '{bcrypt}' + password
    except Exception as e:
        print e
        pass
    return password

def db1sl_connection():
    conf={"user": config('DB_BAZOOKA_USER'), "password": config('DB_BAZOOKA_PASS'), "host": config('DB_BAZOOKA_HOST'), "database": config('DB_BAZOOKA')}
    connection = mysql.connector.connect(user=conf['user'], password=conf['password'],
                                                     host=conf['host'],
                                                     database=conf['database'])
    cursor = connection.cursor(dictionary=True,buffered=True)
    return connection,cursor

def eagle_connection():
    conf_eagle = {"user": config('DB_EAGLE_USER'), "password": config('DB_EAGLE_PASS'), "host": config('DB_EAGLE_HOST'), "database": config('DB_EAGLE')}
    connection_eagle = mysql.connector.connect(user=conf_eagle['user'], password=conf_eagle['password'],
                                         host=conf_eagle['host'],
                                         database=conf_eagle['database'])
    cursor_eagle = connection_eagle.cursor(dictionary=True)
    return connection_eagle,cursor_eagle


def rio_qa1_connection():
    conf_rio = {"user": config('DB_RIO_USER'), "password": config('DB_RIO_PASS'), "host": config('DB_RIO_HOST'), "database": config('DB_RIO')}
    connection_rio = mysql.connector.connect(user=conf_rio['user'], password=conf_rio['password'],
                                             host=conf_rio['host'],
                                             database=conf_rio['database'])
    cursor_rio = connection_rio.cursor(dictionary=True)
    return connection_rio, cursor_rio

def get_key_value_format_mapping(total_data):
    result = {}
    for da in total_data:
        da_list = da.values()
        result[str(da_list[0]).lower().strip()] = da_list[1]
    return result

def master_fetch_data_from_eagle_database():
    connection_master, cursor_master = eagle_connection()
    query_master_count = 'select  cl.name, ct.iso_code from countries as ct inner join country_langs as cl on cl.country_id=ct.id;'
    cursor_master.execute(query_master_count)
    countries_iso_raw = cursor_master.fetchall()
    countries_iso_master = get_key_value_format_mapping(countries_iso_raw)
    query_master_job_location = 'select jll.name,jl.uuid from job_locations as jl inner join job_location_langs as jll on jl.id= jll.job_location_id;'
    cursor_master.execute(query_master_job_location)
    countries_locuuid_raw = cursor_master.fetchall()
    job_locationuuid_name_master = get_key_value_format_mapping(countries_locuuid_raw)
    query_master_searc_cmp = 'select scl.name,sc.uuid from search_companies as sc inner join search_company_langs as scl on sc.id= scl.search_company_id;'
    cursor_master.execute(query_master_searc_cmp)
    compsearch = cursor_master.fetchall()
    search_cmpuuid_name_master = get_key_value_format_mapping(compsearch)
    query_master_hiring_level = 'select hll.hiring_level_id,hl.uuid from hiring_levels as hl inner join hiring_level_langs as hll on hl.id= hll.hiring_level_id;'
    cursor_master.execute(query_master_hiring_level)
    hiring_level_raw = cursor_master.fetchall()
    hiring_leveluuid_name_master = get_key_value_format_mapping(hiring_level_raw)
    query_master_indus = 'select indl.name,ind.uuid from industries as ind inner join industry_langs as indl on ind.id= indl.industry_id;'
    cursor_master.execute(query_master_indus)
    industry_raw = cursor_master.fetchall()
    industry_data_master = get_key_value_format_mapping(industry_raw)
    query_master_functionrole = 'select farl.name,far.uuid from function_and_roles as far inner join function_and_role_langs as farl on far.id= farl.function_and_role_id;'
    cursor_master.execute(query_master_functionrole)
    functionrole_raw = cursor_master.fetchall()
    function_role_data_master = get_key_value_format_mapping(functionrole_raw)
    query_master_designatioon = 'select dll.name,dl.uuid from designations as dl inner join designation_langs as dll on dl.id= dll.designation_id;'
    cursor_master.execute(query_master_designatioon)
    designation_raw = cursor_master.fetchall()
    designation_data_master = get_key_value_format_mapping(designation_raw)
    query_master_skill = 'select skl.name,sk.uuid from skills as sk inner join skill_langs as skl on sk.id= skl.skill_id;'
    cursor_master.execute(query_master_skill)
    skill_raw = cursor_master.fetchall()
    skill_data_master = get_key_value_format_mapping(skill_raw)
    connection_master.close()
    return countries_iso_master, job_locationuuid_name_master, search_cmpuuid_name_master, hiring_leveluuid_name_master, industry_data_master, function_role_data_master, designation_data_master, skill_data_master
countries_iso_master, job_locationuuid_name_master, search_cmpuuid_name_master, hiring_leveluuid_name_master, industry_data_master, function_role_data_master, designation_data_master, skill_data_master = master_fetch_data_from_eagle_database()

def get_recruiter_name(cfname, clname, sfname, slname):
    first_name = None
    last_name = None
    full_name = None
    if sfname:
        first_name = sfname.strip().encode("utf8")
    else:
        if cfname:
            first_name = cfname.strip().encode("utf8")
    if slname:
        last_name = slname.strip().encode("utf8")
    else:
        if clname:
            last_name = clname.strip().encode("utf8")

    if first_name:
        full_name = first_name.strip().encode("utf8")
    if last_name:
        try:
            if full_name:
                full_name += " " + last_name.strip().encode("utf8")
            else:
                full_name = last_name.strip().encode("utf8")
        except Exception as e:
            # print e, first_name, last_name
            pass

    return first_name, last_name, full_name

channel_map = {
    "1": "India",
    "2": "Gulf",
    "5": "Hong Kong",
    "6": "Singapore",
    "10": "Indonesia",
    "7": "Philippines",
    "8": "Thailand",
    "9": "Vietnam",
    "11": "Malaysia"
}

def get_country_isocode(isoval):
    iso_code = None
    # print isoval, countries_iso_master
    if isoval:
        country_val = channel_map.get(str(isoval), None)
        if country_val:
            iso_code = countries_iso_master.get(str(country_val).strip().lower(), None)
    return iso_code

def get_dateunixtimestamp(datatime_data):
    flag_time = False
    if datatime_data:
        # print datatime_data
        # import datetime
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime.datetime(y, m, day, h, mi, sec)
        else:
            d = datetime.datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple())) * 1000
        return unixtime
    else:
        return int(time.time() * 1000)

def get_site_context(subchannelid, channelid):
    site = {1: "rexmonster", 2: "monstergulf", 6: "monstersingapore", 8: "monsterthailand",
            7: "monsterphilippines", 9: "monstervietnam", 11: "monstermalaysia", 10: "monsterindonesia",
            5: "monsterhongkong"}
    site_context = None
    try:
        if subchannelid:
            site_context = site.get(int(subchannelid))
            if site_context == None:
                if channelid:
                    site_context = site.get(int(channelid))
        else:
            if site_context == None:
                if channelid:
                    site_context = site.get(int(channelid))
    except:
        pass
    return site_context


def get_location_uuid(loc_id):
    ind_name = None
    jobuuid = None
    if loc_id:
        connet, curs = db1sl_connection()
        if "," in str(loc_id):
            loc_id = str(loc_id).split(",")[0]
        query = "select name from job_locations where id=%s;" % (loc_id)
        # print query
        curs.execute(query)
        value_data = curs.fetchone()
        ind_name = value_data.get("name", "")
        connet.close()
        jobuuid = job_locationuuid_name_master.get(str(ind_name).lower().strip(), None)
    return jobuuid, ind_name

def get_company_uuid(cmp_name):
    cmpuuid = None
    if cmp_name:
        cmpuuid = search_cmpuuid_name_master.get(str(cmp_name).lower().strip(), None)
    return cmpuuid


def recruiter_client_hiring_for_insert(recruiterid, is_enable, cmp_names, createdate, updatedate):
    Total_company_values = []
    enable = '0'
    if is_enable:
        if '0' in str(is_enable):
            enable = "1"
    if cmp_names:
        eagcon_hire, eagcur_hire = eagle_connection()
        if len(cmp_names.split(",")) > 0:
            for cmp_name in cmp_names.split(","):
                if cmp_name:
                    temp_cmp = []
                    cmpuuid = search_cmpuuid_name_master.get(str(cmp_name).lower().strip(), None)
                    temp_cmp.append(recruiterid)
                    temp_cmp.append(cmpuuid)
                    temp_cmp.append(cmp_name)
                    temp_cmp.append(enable)
                    temp_cmp.append(createdate)
                    temp_cmp.append(updatedate)
                    Total_company_values.append(tuple(temp_cmp))
            eagcon_hire.close()
            return Total_company_values
        else:
            [(recruiterid, None, None, enable, createdate, updatedate)]
    else:
        return [(recruiterid, None, None, enable, createdate, updatedate)]


def recruiter_level_hire_for_insert(recruiterid, is_enable, level_id, createdate, updatedate):
    Total_tmp_level_for = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if level_id:
            if len(level_id.split(",")) > 0:
                for cmp_name in level_id.split(","):
                    temp_level = []
                    if cmp_name:
                        leveluuid = hiring_leveluuid_name_master.get(str(cmp_name).lower().strip(), None)
                        if leveluuid:
                            temp_level.append(recruiterid)
                            temp_level.append(leveluuid)
                            temp_level.append(enable)
                            temp_level.append(createdate)
                            temp_level.append(updatedate)
                            Total_tmp_level_for.append(tuple(temp_level))
            return Total_tmp_level_for
    except:
        pass
    return Total_tmp_level_for


def recruiter_industry_insert(recruiterid, is_enable, industry_id, createdate, updatedate):
    Total_industry = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if industry_id:
            connet, curs = db1sl_connection()
            if len(industry_id.split(",")) > 0:
                for cmp_name in industry_id.split(","):
                    temp_ind = []
                    if cmp_name:
                        query = "select name from industry where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            induuid = industry_data_master.get(value_data.get("name").lower().strip(), None)
                            if induuid:
                                temp_ind.append(recruiterid)
                                temp_ind.append(induuid)
                                temp_ind.append(enable)
                                temp_ind.append(createdate)
                                temp_ind.append(updatedate)
                                Total_industry.append(tuple(temp_ind))
            # eagcon_industry.close()
            connet.close()
            return Total_industry
    except:
        pass
    return Total_industry


def recruiter_function_insert(recruiterid, is_enable, function_id, createdate, updatedate):
    Total_function = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if function_id:
            connet, curs = db1sl_connection()
            if len(function_id.split(",")) > 0:
                for cmp_name in function_id.split(","):
                    temp_func = []
                    if cmp_name:
                        query = "select name from job_categories where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            funcuuid = function_role_data_master.get(value_data.get("name").lower().strip())
                            if funcuuid:
                                temp_func.append(recruiterid)
                                temp_func.append(funcuuid)
                                temp_func.append(enable)
                                temp_func.append(createdate)
                                temp_func.append(updatedate)
                                Total_function.append(tuple(temp_func))
            # eagcon_industry.close()
            connet.close()
            return Total_function
    except:
        pass
    return Total_function


def get_designationuuid(designat):
    desiguuid = None
    if designat:
        desiguuid = designation_data_master.get(designat.strip().lower(), None)
    return desiguuid


def get_start_end_date(date_year):
    start_date = None
    end_date = None
    if date_year:
        if 'present' in date_year.lower():
            if '-' in date_year:
                date_value = date_year.split("-")
                start_date = date_value[0].strip()+"-01-01"
        else:
            if '-' in date_year:
                date_value = date_year.split("-")
                if len(date_value) == 2:
                    start_date = date_value[0].strip() + '-01-01'
                    end_date = date_value[1].strip() + "-12-31"
    return start_date, end_date


def recruiter_achieve_and_work_history_insert(recruiterid, social_id):
    Total_achieve = []
    Total_work_history = []
    try:
        if social_id:
            # eagcon_function, eagcur_function = eagle_connection()
            connet, curs = db1sl_connection()
            query = "select * from rec_social_profile_exp_achieve where social_id='%s';" % (
                social_id)
            # print query
            curs.execute(query)
            for row_data in curs:
                if row_data["type"] == "ach":
                    if row_data["description"]:
                        temp_achive = []
                        temp_achive.append(recruiterid)
                        temp_achive.append(row_data["description"].encode("utf8"))
                        years = None
                        if row_data["year"]:
                            years = row_data["year"] + "-01-01"
                        temp_achive.append(years)
                        enable = '0'
                        if row_data["enabled"]:
                            if '0' in str(row_data["enabled"]):
                                enable = "1"
                        temp_achive.append(enable)
                        temp_achive.append(get_dateunixtimestamp(str(row_data["createdate"])))
                        temp_achive.append(get_dateunixtimestamp(str(row_data["updatedate"])))
                        # print '===========>>>',len(temp_achive)
                        Total_achieve.append(tuple(temp_achive))
                if row_data["type"] == "exp":
                    if row_data["company_name"]:
                        temp_exp = []
                        designat_uuid = get_designationuuid(row_data["designation"])
                        temp_exp.append(recruiterid)
                        temp_exp.append(designat_uuid)
                        temp_exp.append(row_data["designation"])
                        cmp_uuid = get_company_uuid(row_data["company_name"])
                        temp_exp.append(cmp_uuid)
                        temp_exp.append(row_data["company_name"])
                        startdate, enddate = get_start_end_date(row_data["year"])
                        temp_exp.append(startdate)
                        temp_exp.append(enddate)
                        temp_exp.append(row_data["is_current"])
                        temp_exp.append(row_data["enabled"])
                        temp_exp.append(get_dateunixtimestamp(str(row_data["createdate"])))
                        temp_exp.append(get_dateunixtimestamp(str(row_data["updatedate"])))
                        # print '<<<<<<===========>>>', len(temp_exp)
                        Total_work_history.append(tuple(temp_exp))
    except Exception as exc:
        # print exc
        pass
    return Total_achieve, Total_work_history


def recruiter_skills_insert(recruiterid, is_enable, skills_data, createdate, updatedate):
    Total_skills = []
    try:
        enable = '0'
        if is_enable:
            if '0' in str(is_enable):
                enable = "1"
        if skills_data:
            if len(skills_data.split(",")) > 0:
                for cmp_name in skills_data.split(","):
                    temp_skill = []
                    if cmp_name:
                        skilluuid = skill_data_master.get(cmp_name.strip().lower(), None)
                        temp_skill.append(recruiterid)
                        temp_skill.append(skilluuid)
                        temp_skill.append(cmp_name.strip().encode("utf8"))
                        temp_skill.append(enable)
                        temp_skill.append(createdate)
                        temp_skill.append(updatedate)
                        Total_skills.append(tuple(temp_skill))
            return Total_skills
    except:
        pass
    return Total_skills


def get_image_id(rec_social_profile_id):
    image_id = None
    if rec_social_profile_id:
        connet, curs = db1sl_connection()
        query = "select * from rec_social_profile_image where recruiter_profile_id=%s;" % (rec_social_profile_id)
        # print query
        curs.execute(query)
        value_data = curs.fetchone()
        # print value_data
        connet.close()
        if value_data:
            eagcon, eagcur = eagle_connection()
            ssourcesql_image = 'insert into recruiter_image (image_name,image_type,image_data,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
            ssourceval_image = (
                value_data.get("image_name", ""), value_data.get("image_type", ""), value_data.get("image_data", ""),
                get_dateunixtimestamp(value_data.get("createdate", "")),
                get_dateunixtimestamp(value_data.get("updatedate", "")))
            eagcur.execute(ssourcesql_image, ssourceval_image)
            eagcur.execute("select LAST_INSERT_ID() as id")
            image_id = eagcur.fetchone()['id']
            eagcon.commit()
            eagcon.close()
            # print 'imageid++++++++++++++',image_id
    return image_id
    # return None


# print get_image_id("1010")
def get_is_job_isemail(extra_value):
    isjob = '0'
    isemail = '0'
    if extra_value:
        email_job_data = json.loads(str(extra_value))
        isjob = email_job_data.get("JOB", '0')
        isemail = email_job_data.get("EMAIL", '0')
    return isjob, isemail


def check_deleted(is_enable):
    enable = '0'
    if is_enable:
        if '0' in str(is_enable):
            enable = "1"
    return enable


def get_corp_account_id(login_account):
    corp_id = []
    connection_eagle_account_read, cursor_eagle_account_read = eagle_connection()
    query = "select id from corp_account where kiwi_subuid='%s';" % (login_account)
    #print query, login_account
    cursor_eagle_account_read.execute(query)
    for df in cursor_eagle_account_read:
        if df:
            corp_id.append(str(df.get("id", "")))
    # print corp_id
    return ','.join(corp_id)

def get_all_data_from_db1sl(lastrecid,accid):
    last_rec_id = None
    if lastrecid:
        connection, cursor = db1sl_connection()
        query = '''SELECT a.id,a.passwd,a.first_name,a.last_name, a.enabled as enb_corp,a.createdate,a.login,a.passwd_change_date,
        b.id as id_social_profile,b.social_name,b.email,b.fname,b.lname,b.mobile,b.country_code,b.current_position,b.current_location,b.current_company,b.address,b.profile_image,b.image_status,
        b.total_hiring_exp,b.client_hire_for,b.
        level_hire_for,b.skills_hire_for,b.industry,b.function,b.profile_desc,b.enabled as enb_profile,
        b.profile_status,b.createdate as createdate_profile,b.updatedate as updatedate_profile,b.lastactive,b.cid,b.scid,b.extrainfo,
        b.profile_pin,b.pin_updated,c.corpid,c.subuid,c.social_id
        FROM corps_login a
        LEFT JOIN rec_social_profile_mapping c ON c.subuid=a.id and c.profile_enabled='1'
        LEFT JOIN rec_social_profile b ON b.id = c.social_id where (a.id=745835) order by a.id asc
        ;'''
        cursor.execute(query)
        recruter_total_data = cursor.fetchall()
        if len(recruter_total_data)>0:
            last_rec_id = recruter_total_data[-1].get("id", None)
        else:
            last_rec_id = lastrecid
        connection.close()
    return recruter_total_data, last_rec_id
def recruiter_user_role_insert(recut_id, accountid):
    connection_write, cursor_write = rio_qa1_connection()
    i = 0
    connection_eagle_recruiter_write, cursor_eagle_recruiter_write = eagle_connection()
    recruter_total_data_main, last_rec_id= get_all_data_from_db1sl(recut_id,accountid)
    print 'recruter_total_data_main',len(recruter_total_data_main)
    for row in recruter_total_data_main:
        value_none = None
        temp = []
        temp.append(str(uuid.uuid4()))
        temp.append(get_bycrypt_password(row["passwd"], row["id"]))
        fname, lname, fullname = get_recruiter_name(row["first_name"], row["last_name"], row["fname"], row["lname"])
        temp.append(fname)
        temp.append(lname)
        temp.append(fullname)
        temp.append(row["cid"])
        temp.append(get_country_isocode(row["scid"]))
        if row["enb_corp"]:
            temp.append(row["enb_corp"])
        else:
            temp.append('0')
        temp.append(get_dateunixtimestamp(row["createdate"]))
        temp.append(int(time.time() * 1000))
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(value_none)
        temp.append(get_site_context(row["scid"], row["cid"]))
        temp.append(row["id"])
        ssourcesql = 'insert into users (uuid,password,first_name,last_name,full_name,site,country,status,created_at,updated_at,aadhar_number,avatar,dob,gender,gender_text,marital_status,marital_status_text,passport_number,nationality,nationality_text,religion,religion_text,site_context,kiwi_user_id) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        ssourceval = tuple(temp)
        cursor_write.execute(ssourcesql, ssourceval)
        cursor_write.execute("select LAST_INSERT_ID() as id")
        user_id = cursor_write.fetchone()['id']
        # print '+++++++++++', user_id
        ssourcesql_role = 'insert into user_roles (user_id,role_id,created_at,updated_at) VALUES (%s,%s,%s,%s)'
        ssourceval_role = (user_id, 2, int(time.time() * 1000), int(time.time() * 1000))
        cursor_write.execute(ssourcesql_role, ssourceval_role)
        cursor_write.execute("select uuid from users where id=%s;" % (user_id))
        uuid_user = cursor_write.fetchone()['uuid']
        recruiter_data = []
        recruiter_data.append(uuid_user)
        # print row["current_location"],row["total_hiring_exp"]
        loc_uuid, loc_name = get_location_uuid(row["current_location"])
        recruiter_data.append(loc_uuid)
        recruiter_data.append(loc_name)
        if row["total_hiring_exp"]:
            recruiter_data.append(row["total_hiring_exp"])
        else:
            recruiter_data.append(None)
        recruiter_data.append(row["current_position"])
        recruiter_data.append(get_company_uuid(row["current_company"]))
        recruiter_data.append(row["current_company"])
        recruiter_data.append(row["address"])
        recruiter_data.append(row["profile_desc"])
        recruiter_data.append(row["id_social_profile"])
        recruiter_data.append(row["email"])
        recruiter_data.append(row["mobile"])
        recruiter_data.append(get_image_id(row["id_social_profile"]))  # get image id
        recruiter_data.append(None)
        recruiter_data.append(row["enb_profile"])
        if row["profile_status"]:
            recruiter_data.append(row["profile_status"])
        else:
            recruiter_data.append(None)
        recruiter_data.append(get_dateunixtimestamp(row["createdate_profile"]))
        recruiter_data.append(get_dateunixtimestamp(row["updatedate_profile"]))
        recruiter_data.append(get_dateunixtimestamp(row["lastactive"]))
        is_job, is_email = get_is_job_isemail(row["extrainfo"])
        recruiter_data.append(is_job)
        recruiter_data.append(is_email)
        recruiter_data.append(row["id"])

        ssourcesql_recruiter = 'insert into recruiters (uuid,current_location_uuid,current_location_text,experience,current_position_text,current_company_uuid,current_company_text,address,profile_description,kiwi_social_id,email,mobile,image_id,image_url,enabled,profile_status,created_at,updated_at,last_active_at,is_job,is_email, kiwi_subuid) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        ssourceval_recruiter = tuple(recruiter_data)
        # print '=====>', len(ssourceval_recruiter)
        # print '==============>>>=>>>',ssourceval_recruiter

        cursor_eagle_recruiter_write.execute(ssourcesql_recruiter, ssourceval_recruiter)
        cursor_eagle_recruiter_write.execute("select LAST_INSERT_ID() as id")
        recruiter_id = cursor_eagle_recruiter_write.fetchone()['id']
        # print 'Recruter id >>>>', len(recruiter_data),recruiter_id,recruiter_data
        # connection_eagle_recruiter_write.commit()
        recruiter_client_hiring_records = recruiter_client_hiring_for_insert(recruiter_id, row["enb_profile"],
                                                                             row["client_hire_for"], get_dateunixtimestamp(
                row["createdate_profile"]), get_dateunixtimestamp(row["updatedate_profile"]))
        # print recruiter_client_hiring_records
        # break
        sourcsql_client_hiring = 'insert into recruiter_client_hiring_for (recruiter_id,client_company_uuid,client_company_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
        # print 'sourcsql_client_hiring++++++++++', recruiter_client_hiring_records
        for records_hire in recruiter_client_hiring_records:
            cursor_eagle_recruiter_write.execute(sourcsql_client_hiring, records_hire)
        recruiter_level_hire_for_records = recruiter_level_hire_for_insert(recruiter_id, row["enb_profile"],
                                                                           row["level_hire_for"],
                                                                           get_dateunixtimestamp(row["createdate_profile"]),
                                                                           get_dateunixtimestamp(row["updatedate_profile"]))
        # print '-----------', recruiter_level_hire_for_records
        ssourcesql_level_for = 'insert into recruiter_hiring_level (recruiter_id,hiring_level_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
        if len(recruiter_level_hire_for_records) > 0:
            for level_data in recruiter_level_hire_for_records:
                cursor_eagle_recruiter_write.execute(ssourcesql_level_for, level_data)
        recruiter_skills_data = recruiter_skills_insert(recruiter_id, row["enb_profile"], row["skills_hire_for"],
                                                        get_dateunixtimestamp(row["createdate_profile"]),
                                                        get_dateunixtimestamp(row["updatedate_profile"]))
        # print recruiter_skills_data
        ssourcesql_skill = 'insert into recruiter_skill (recruiter_id,skill_uuid,skill_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
        if len(recruiter_skills_data) > 0:
            for skill_data in recruiter_skills_data:
                cursor_eagle_recruiter_write.execute(ssourcesql_skill, skill_data)
        recruiter_industry_data = recruiter_industry_insert(recruiter_id, row["enb_profile"], row["industry"],
                                                            get_dateunixtimestamp(row["createdate_profile"]),
                                                            get_dateunixtimestamp(row["updatedate_profile"]))
        # print '000000000000',recruiter_industry_data
        ssourcesql_industry = 'insert into recruiter_industry (recruiter_id,industry_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
        if len(recruiter_industry_data) > 0:
            for indus_data in recruiter_industry_data:
                cursor_eagle_recruiter_write.execute(ssourcesql_industry, indus_data)
        recruiter_function_data = recruiter_function_insert(recruiter_id, row["enb_profile"], row["function"],
                                                            get_dateunixtimestamp(row["createdate_profile"]),
                                                            get_dateunixtimestamp(row["updatedate_profile"]))
        # print '========>>>>',recruiter_function_data,row["function"]
        if len(recruiter_function_data) > 0:
            ssourcesql_function = 'insert into recruiter_function (recruiter_id,function_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
            for funct_data in recruiter_function_data:
                cursor_eagle_recruiter_write.execute(ssourcesql_function, funct_data)
        recruiter_portability_setting_data = (
            recruiter_id, row["social_name"], row["profile_pin"], get_dateunixtimestamp(row["createdate_profile"]),
            get_dateunixtimestamp(row["updatedate_profile"]))
        ssourcesql_portability = 'insert into recruiter_portability_setting (recruiter_id,social_name,profile_pin,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
        # print recruiter_portability_setting_data
        cursor_eagle_recruiter_write.execute(ssourcesql_portability, recruiter_portability_setting_data)
        recruiter_achieve, work_history_data = recruiter_achieve_and_work_history_insert(recruiter_id,
                                                                                         row["id_social_profile"])
        if len(recruiter_achieve) > 0:
            ssourcesql_achieve = 'insert into recruiter_achievement (recruiter_id,description,achievement_date,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
            for achieve_data in recruiter_achieve:
                cursor_eagle_recruiter_write.execute(ssourcesql_achieve, achieve_data)
        if len(work_history_data) > 0:
            ssourcesql_work_history = 'insert into recruiter_work_history (recruiter_id,designation_uuid,designation_text,company_uuid,company_text,start_date,end_date,is_current_company,enabled,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
            for work_hist in work_history_data:
                cursor_eagle_recruiter_write.execute(ssourcesql_work_history, work_hist)
        # print len(work_history_data)
        corp_account_id = get_corp_account_id(row["id"])
        deletd_val = check_deleted(row["enb_corp"])
        # break
        ssourcesql_corp_account_recruiter = 'insert into corp_account_recruiter (corp_account_id,recruiter_id,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
        ssourceVal_corp_account_recruiter = (
            corp_account_id, recruiter_id, deletd_val, get_dateunixtimestamp(row["createdate"]),
            get_dateunixtimestamp(row["passwd_change_date"]))
        print 'insert before corp_account_recruiter rec_id,corp_id==========',recruiter_id,corp_account_id,ssourceVal_corp_account_recruiter
        if '' not in ssourceVal_corp_account_recruiter:
            cursor_eagle_recruiter_write.execute(ssourcesql_corp_account_recruiter, ssourceVal_corp_account_recruiter)
        if i == 100:
            connection_write.commit()
            connection_eagle_recruiter_write.commit()
            i = 0
        i += 1
        print 'corps_login Recruiter insert id : '+  str(row["id"])+" Time : "+str(datetime.datetime.now().strftime("%Y:%m:%d:%H:%M:%S"))
    connection_write.commit()
    connection_eagle_recruiter_write.commit()
    # connection.close()
    connection_write.close()
    connection_eagle_recruiter_write.close()
    return last_rec_id

def run_recruiter_role_insert_script():
    last_recruiterinsert_id = main_directory + "/last_recruiterinsert_id"
    read_file = open(last_recruiterinsert_id)
    recruiterid = read_file.read()
    read_file.close()
    last_corpaccountinsert_id = main_directory+"/last_corpaccountinsert_id"
    read_file_corp = open(last_corpaccountinsert_id)
    accountid = read_file_corp.read()
    read_file_corp.close()
    print 'Recruiter_insert,corp_account last id: ', recruiterid, accountid
    if recruiterid:
        last_store_id = recruiter_user_role_insert(recruiterid,accountid)
        """if last_store_id and last_store_id!='':
            last_writeid = open(last_recruiterinsert_id, 'w')
            last_writeid.write(str(last_store_id))
            last_writeid.close()"""

if __name__ == "__main__":
    run_recruiter_role_insert_script()

