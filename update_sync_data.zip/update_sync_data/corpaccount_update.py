# -*- coding:utf-8 -*-

import sys
import time
import datetime
import concurrent.futures
reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
from decouple import config
import os
import psutil
startdate_script = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txtfiles")
corpaccount_insertid = main_directory+"/corpaccount_updateid"
"""fd = open(corpaccount_insertid)
pidval = fd.read()
fd.close()
if pidval:
    if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
        print 'Process is already running------', pidval
        exit(0)
fd1 = open(corpaccount_insertid,'w')
fd1.write(str(os.getpid()))
fd1.close()"""
def db1sl_connection():
    conf={"user": config('DB_BAZOOKA_USER'), "password": config('DB_BAZOOKA_PASS'), "host": config('DB_BAZOOKA_HOST'), "database": config('DB_BAZOOKA')}
    connection = mysql.connector.connect(user=conf['user'], password=conf['password'],
                                                     host=conf['host'],
                                                     database=conf['database'])
    cursor = connection.cursor(dictionary=True,buffered=True)
    return connection,cursor

def eagle_connection():
    conf_eagle = {"user": config('DB_EAGLE_USER'), "password": config('DB_EAGLE_PASS'), "host": config('DB_EAGLE_HOST'), "database": config('DB_EAGLE')}
    connection_eagle = mysql.connector.connect(user=conf_eagle['user'], password=conf_eagle['password'],
                                         host=conf_eagle['host'],
                                         database=conf_eagle['database'])
    cursor_eagle = connection_eagle.cursor(dictionary=True)
    return connection_eagle,cursor_eagle

def get_corp_id(id_value):
    corpid = None
    if id_value:
        connection_read, cursor_read = eagle_connection()
        query_id = 'select id from corps where kiwi_corp_id=%s;'%(id_value)
        # print query_id
        cursor_read.execute(query_id)
        data = cursor_read.fetchone()
        connection_read.close()
        if data:
            corpid = data.get("id",None)
    return corpid

def get_customjd(cutomjd):
    if cutomjd:
        if 'CustomJD' in str(cutomjd):
            return '1'
        else:
            return '0'
    else:
        return '0'

def get_dateunixtimestamp(datatime_data):
    flag_time = False
    if datatime_data:
        # print datatime_data
        # import datetime
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime.datetime(y, m, day, h, mi, sec)
        else:
            d = datetime.datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple()))*1000
        return unixtime
    else:
        return int(time.time()*1000)

def get_temp_record_of_corp_account(row):
    temp = []
    # temp.append(get_corp_id(row["corp_id"]))
    temp.append(row["login"])
    temp.append(row["id"])
    temp.append(row["superuser"])
    temp.append(row["redirect_url_control"])
    temp.append(row["num_saved_search"])
    temp.append(row["daily_mail_limit"])
    temp.append(row["monthly_mail_limit"])
    temp.append(row["total_mail_limit"])
    temp.append(row["resume_attachment_flag"])
    temp.append(row["monster_shortcuts_flag"])
    temp.append(row["alert"])
    temp.append(row["login_type"])
    temp.append('0')
    temp.append(row["enabled"])
    if row["access"]:
        temp.append(row["access"])
    else:
        temp.append(None)
    temp.append(get_customjd(row["extra_info"]))
    temp.append(get_dateunixtimestamp(row["createdate"]))
    temp.append(get_dateunixtimestamp(row["info_updated"]))
    temp.append(get_dateunixtimestamp(row["expiredate"]))
    return temp

def checckifExist(kiwicorpid):
    is_present = False
    corp_accountid = None
    connection_read, cursor_read = eagle_connection()
    query1 = "select id from corp_account where kiwi_subuid ='%s';" % (
        kiwicorpid)
    # print query1
    cursor_read.execute(query1)
    data = cursor_read.fetchone()
    if data:
        is_present = True
        corp_accountid = data.get("id", None)
    connection_read.close()

    return is_present, corp_accountid


def corp_account_update(last_script_time):
    connection,cursor  = db1sl_connection()
    query = \
        "select * from corps_login WHERE ((updated> created)  AND (updated>='%s'));"%(last_script_time)
    print query
    cursor.execute(query)
    total_data_main = cursor.fetchall()
    print 'Total Updation corps_login for corp account : ', len(total_data_main)
    total_data = []
    i=0
    connection_write,cursor_write  = eagle_connection()
    for rows in total_data_main:
        try:
            is_prensentid, corp_account_id = checckifExist(rows["id"])
            if is_prensentid:
                print 'New corp id with old : '+ str(corp_account_id)+" corps_loginid : "+ str(rows["id"])+" Time : "+str(datetime.datetime.now().strftime("%Y:%m:%d:%H:%M:%S"))
                temp = get_temp_record_of_corp_account(rows)
                #print temp
                temp.append(corp_account_id)
                ssourcesql = 'UPDATE corp_account SET kiwi_login_id=%s,kiwi_subuid=%s,super_user=%s,redirect_url_control=%s,num_saved_searches=%s,daily_mail_limit=%s,monthly_mail_limit=%s,total_mail_limit=%s,resume_attachment_flag=%s,monster_shortcuts_flag=%s,alert=%s,login_type=%s,deleted=%s,enabled=%s,access=%s,cjt_enabled=%s,created_at=%s,updated_at=%s,expire_date=%s where id=%s'
                ssourceval = tuple(temp)
                cursor_write.execute(ssourcesql, ssourceval)
                if i==10:
                    i=0
                    connection_write.commit()
                i+=1
                #print i
        except Exception as e:
            print e
            pass
    connection_write.commit()
    connection.close()
    connection_write.close()

def run_corpaccount_update():
    corpaccount_updatetime = main_directory + "/corpaccounnt_updatetime"
    corp_file = open(corpaccount_updatetime)
    corp_last_update = corp_file.read()
    corp_file.close()
    if corp_last_update:
        corp_account_update(corp_last_update)
        corpaccount_file = open(corpaccount_updatetime, 'w')
        corpaccount_file.write(str(startdate_script))
        corpaccount_file.close()

if __name__ == "__main__":
    run_corpaccount_update()












