# -*- coding:utf-8 -*-

import sys
import time
import datetime
import json

reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
import os
import psutil

main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txtfiles")
corpaccount_insertid = main_directory+"/jobs_insert_pid"
fd = open(corpaccount_insertid)
pidval = fd.read()
fd.close()
if pidval:
    if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
        print 'Process is already running------', pidval
        exit(0)
fd1 = open(corpaccount_insertid,'w')
fd1.write(str(os.getpid()))
fd1.close()

def db1sl_connection():
    conf={"user": "readonly","password": "readonly","host": "10.216.248.117","database": "bazooka"}
    connection = mysql.connector.connect(user=conf['user'], password=conf['password'],
                                                     host=conf['host'],
                                                     database=conf['database'])
    cursor = connection.cursor(dictionary=True,buffered=True)
    return connection,cursor

def eagle_connection():
    conf_eagle = {"user": "migration", "password": "migration007", "host": "10.216.247.110", "database": "eagle"}
    connection_eagle = mysql.connector.connect(user=conf_eagle['user'], password=conf_eagle['password'],
                                         host=conf_eagle['host'],
                                         database=conf_eagle['database'])
    cursor_eagle = connection_eagle.cursor(dictionary=True)
    return connection_eagle,cursor_eagle

def get_key_value_format_mapping(total_data):
    result = {}
    for da in total_data:
        da_list = da.values()
        result[str(da_list[0]).lower().strip()] = da_list[1]
    return result


def master_fetch_data_from_eagle_database():
    connection_master, cursor_master = eagle_connection()
    query_master_count = 'select  cl.name, ct.iso_code from countries as ct inner join country_langs as cl on cl.country_id=ct.id;'
    cursor_master.execute(query_master_count)
    countries_iso_raw = cursor_master.fetchall()
    countries_iso_master = get_key_value_format_mapping(countries_iso_raw)
    query_master_job_location = 'select jll.name,jl.uuid from job_locations as jl inner join job_location_langs as jll on jl.id= jll.job_location_id;'
    cursor_master.execute(query_master_job_location)
    countries_locuuid_raw = cursor_master.fetchall()
    job_locationuuid_name_master = get_key_value_format_mapping(countries_locuuid_raw)
    query_master_searc_cmp = 'select scl.name,sc.uuid from search_companies as sc inner join search_company_langs as scl on sc.id= scl.search_company_id;'
    cursor_master.execute(query_master_searc_cmp)
    compsearch = cursor_master.fetchall()
    search_cmpuuid_name_master = get_key_value_format_mapping(compsearch)
    query_master_hiring_level = 'select hll.hiring_level_id,hl.uuid from hiring_levels as hl inner join hiring_level_langs as hll on hl.id= hll.hiring_level_id;'
    cursor_master.execute(query_master_hiring_level)
    hiring_level_raw = cursor_master.fetchall()
    hiring_leveluuid_name_master = get_key_value_format_mapping(hiring_level_raw)

    query_master_indus = 'select indl.name,ind.uuid from industries as ind inner join industry_langs as indl on ind.id= indl.industry_id;'
    cursor_master.execute(query_master_indus)
    industry_raw = cursor_master.fetchall()
    industry_data_master = get_key_value_format_mapping(industry_raw)

    query_master_functionrole = 'select far.id,far.uuid from function_and_roles as far inner join function_and_role_langs as farl on far.id= farl.function_and_role_id;'
    cursor_master.execute(query_master_functionrole)
    functionrole_raw = cursor_master.fetchall()
    function_role_data_master = get_key_value_format_mapping(functionrole_raw)

    query_master_designatioon = 'select dll.name,dl.uuid from designations as dl inner join designation_langs as dll on dl.id= dll.designation_id;'
    cursor_master.execute(query_master_designatioon)
    designation_raw = cursor_master.fetchall()
    designation_data_master = get_key_value_format_mapping(designation_raw)

    query_master_skill = 'select skl.name,sk.uuid from skills as sk inner join skill_langs as skl on sk.id= skl.skill_id;'
    cursor_master.execute(query_master_skill)
    skill_raw = cursor_master.fetchall()
    skill_data_master = get_key_value_format_mapping(skill_raw)

    query_master_employment = 'select etl.name,et.uuid from employment_types as et inner join employment_type_langs as etl on et.id= etl.employment_type_id;'
    cursor_master.execute(query_master_employment)
    employment_type_raw = cursor_master.fetchall()
    employement_type_master = get_key_value_format_mapping(employment_type_raw)

    query_master_nationality = 'select nll.name,nl.uuid from nationalities as nl inner join nationality_langs as nll on nl.id= nll.nationality_id;'
    cursor_master.execute(query_master_nationality)
    nationality_raw = cursor_master.fetchall()
    nationlity_master = get_key_value_format_mapping(nationality_raw)

    query_master_highest_qualifications = 'select hql.name,hq.uuid from highest_qualifications as hq inner join highest_qualification_langs as hql on hq.id= hql.highest_qualification_id;'
    cursor_master.execute(query_master_highest_qualifications)
    highest_qualifications_raw = cursor_master.fetchall()
    highest_qualifications_master = get_key_value_format_mapping(highest_qualifications_raw)
    query_master_qualification_specializations = 'select qsl.name,qs.uuid from qualification_specializations as qs inner join qualification_specialization_langs as qsl on qs.id= qsl.qualification_specialization_id;'
    cursor_master.execute(query_master_qualification_specializations)
    qualification_specializations_raw = cursor_master.fetchall()
    qualification_specializations_master = get_key_value_format_mapping(qualification_specializations_raw)
    query_master_countries = 'select crl.name,cr.uuid from countries as cr inner join country_langs as crl on cr.id= crl.country_id;'
    cursor_master.execute(query_master_countries)
    countries_name_raw = cursor_master.fetchall()
    countries_name_master = get_key_value_format_mapping(countries_name_raw)

    query_master_contract_tenures = 'select ctl.name,ct.uuid from contract_tenures as ct inner join contract_tenure_langs as ctl on ct.id= ctl.contract_tenure_id;'
    cursor_master.execute(query_master_contract_tenures)
    contract_tenures_raw = cursor_master.fetchall()
    contract_tenures_master = get_key_value_format_mapping(contract_tenures_raw)

    query_master_disablity_typesub = 'select dsl.name,ds.uuid from disabilities as ds inner join disability_langs as dsl on ds.id= dsl.disability_id;'
    cursor_master.execute(query_master_disablity_typesub)
    disabilitytypesub_raw = cursor_master.fetchall()
    disability_type_subtype_master = get_key_value_format_mapping(disabilitytypesub_raw)

    query_master_disablity_innersub = 'select ddl.name,dd.uuid from disability_details as dd inner join disability_detail_langs as ddl on dd.id= ddl.disability_detail_id;'
    cursor_master.execute(query_master_disablity_innersub)
    disabilityinnersubtype_raw = cursor_master.fetchall()
    disability_inner_subtype_master = get_key_value_format_mapping(disabilityinnersubtype_raw)

    connection_master.close()
    return countries_iso_master, job_locationuuid_name_master, search_cmpuuid_name_master, hiring_leveluuid_name_master, industry_data_master, function_role_data_master, designation_data_master, skill_data_master, employement_type_master, nationlity_master, highest_qualifications_master, qualification_specializations_master, countries_name_master, contract_tenures_master, disability_type_subtype_master, disability_inner_subtype_master

countries_iso_master, job_locationuuid_name_master, search_cmpuuid_name_master, hiring_leveluuid_name_master, industry_data_master, function_role_data_master, designation_data_master, skill_data_master, employement_type_master, nationlity_master, highest_qualifications_master, qualification_specializations_master, countries_name_master, contract_tenures_master, disability_type_subtype_master, disability_inner_subtype_master = master_fetch_data_from_eagle_database()

def get_corp_id(id_value):
    corp_id = None
    if id_value:
        connection_read, cursor_read = eagle_connection()
        query_id = 'select id from corps where kiwi_corp_id=%s;' % (id_value)
        # print query_id
        cursor_read.execute(query_id)
        data = cursor_read.fetchone()
        connection_read.close()
        if data:
            # print data
            corp_id = data.get("id", "")
    return corp_id


def get_account_id(subuid):
    account_id = None
    recruiter_id = None
    if subuid:
        connection_read, cursor_read = eagle_connection()
        query_id = 'select id from corp_account where kiwi_subuid=%s;' % (subuid)
        # print query_id
        cursor_read.execute(query_id)
        data = cursor_read.fetchone()
        #
        if data:
            account_id = data.get("id", "")
        if account_id:
            query_id_rec = 'select recruiter_id from corp_account_recruiter where corp_account_id = %s;' % (account_id)
            cursor_read.execute(query_id_rec)
            data_rec = cursor_read.fetchone()
            if data_rec:
                recruiter_id = data_rec.get("recruiter_id", "")
        connection_read.close()
    return account_id, recruiter_id


def get_recruiter_id(accountid):
    recruiter_id = None
    if accountid:
        connection_readrec, cursor_readrec = eagle_connection()
        query_id_rec = "select recruiter_id from corp_account_recruiter where corp_account_id = %s;" % (accountid)
        # print query_id_rec
        cursor_readrec.execute(query_id_rec)
        data = cursor_readrec.fetchone()
        connection_readrec.close()
        if data:
            recruiter_id = data.get("recruiter_id", "")
    return recruiter_id


def check_deleted(is_enable):
    enable = '0'
    if is_enable:
        if '0' in str(is_enable):
            enable = "1"
    return enable


def get_dateunixtimestamp(datatime_data):
    flag_time = False
    if datatime_data:
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime.datetime(y, m, day, h, mi, sec)
        else:
            d = datetime.datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple())) * 1000
        return unixtime
    else:
        return None #int(time.time() * 1000)
# print get_dateunixtimestamp("0000-00-00 00:00:00")
def get_draft_scheduleunixtimestamp(datatime_data):
    flag_time = False
    unixtime = None
    if datatime_data:
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime.datetime(y, m, day, h, mi, sec)
        else:
            d = datetime.datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple())) * 1000
    return unixtime


def get_keyskill_records(jobid, keyskill, is_deleted, created, updated):
    total_records = []
    if keyskill:
        if "ÃƒÂƒÃ" in str(keyskill).encode("utf8"):
            keyskill = keyskill.encode("ascii","ignore")
        tmpskill = keyskill.split(",")
        if len(tmpskill) > 0:
            for skl in tmpskill:
                if skl:
                    tmpskill = []
                    skilluuid = skill_data_master.get(skl.strip().lower(), None)
                    tmpskill.append(jobid)
                    tmpskill.append(skilluuid)
                    tmpskill.append(skl.strip().encode("utf8"))
                    tmpskill.append(is_deleted)
                    tmpskill.append(created)
                    tmpskill.append(updated)
                    total_records.append(tuple(tmpskill))
    return total_records


def get_jobtype_uuid(jobtype):
    jobtype_uuid = None
    if jobtype:
        job_val = None
        if jobtype.lower().startswith("full"):
            job_val = "Full time"
        if jobtype.lower().startswith("part"):
            job_val = "Part time"
        if not job_val:
            job_val = "Part time"
        if job_val:
            jobtype_uuid = employement_type_master.get(job_val.lower().strip(), None)
    return jobtype_uuid


def job_cat_function_insert(jobid, function_id, is_deleted, createdate, updatedate):
    Total_function = []
    try:
        if function_id:
            connet, curs = db1sl_connection()
            if ":" in function_id:
                function_id = function_id.split(":")[-1]
            if len(function_id.replace(":", "").split(",")) > 0:
                for cmp_name in function_id.replace(":", "").split(","):
                    temp_func = []
                    if cmp_name:
                        query = "select id from job_categories where id=%s;" % (
                            cmp_name)
                        # print query
                        curs.execute(query)
                        value_data = curs.fetchone()
                        # print value_data
                        if value_data:
                            funcuuid = function_role_data_master.get(str(value_data.get("id")), None)
                            if funcuuid:
                                temp_func.append(jobid)
                                temp_func.append(funcuuid)
                                temp_func.append(is_deleted)
                                temp_func.append(createdate)
                                temp_func.append(updatedate)
                                Total_function.append(tuple(temp_func))
            connet.close()
            return Total_function
    except:
        pass
    return Total_function


def job_industry_insert(jobid, industry_id, is_deleted, createdate, updatedate):
    Total_industry = []
    try:
        if industry_id:
            connet, curs = db1sl_connection()
            if len(industry_id.split(",")) > 0:
                for cmp_name in industry_id.split(","):
                    temp_ind = []
                    if cmp_name:
                        query = "select name from industry where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            induuid = industry_data_master.get(value_data.get("name").strip().lower(), None)
                            if induuid:
                                temp_ind.append(jobid)
                                temp_ind.append(induuid)
                                temp_ind.append(is_deleted)
                                temp_ind.append(createdate)
                                temp_ind.append(updatedate)
                                Total_industry.append(tuple(temp_ind))
            connet.close()
    except:
        pass
    return Total_industry


def job_locations_insert(jobid, locations_id, is_deleted, createdate, updatedate):
    Total_location = []
    try:
        if locations_id:
            connet, curs = db1sl_connection()
            if len(locations_id.split(",")) > 0:
                for cmp_name in locations_id.split(","):
                    temp_loc = []
                    if cmp_name:
                        query = "select name from job_locations where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            if value_data.get("name").strip().lower() == 'hongkong':
                                value_data["name"] = "hong kong"
                            if value_data.get("name").strip().lower() == 'uk':
                                value_data["name"] = "United Kingdom"
                            if value_data.get("name").strip().lower() == 'us':
                                value_data["name"] = "United States"
                            locuuid = job_locationuuid_name_master.get( value_data.get("name").strip().lower(), None)
                            temp_loc.append(jobid)
                            temp_loc.append(locuuid)
                            temp_loc.append(value_data.get("name").strip().encode("utf8"))
                            temp_loc.append(is_deleted)
                            temp_loc.append(createdate)
                            temp_loc.append(updatedate)
                            Total_location.append(tuple(temp_loc))
            connet.close()
    except:
        pass
    return Total_location


def job_nationality_insert(jobid, nationality_iso, is_deleted, createdate, updatedate):
    Total_national = []
    nationality = {'BD': 'Bangladeshi', 'WF': 'Wallis and Futuna', 'BF': 'Burkina Faso', 'BG': 'Bulgaria',
                   'BA': 'Bosnia and Herzegovina', 'BB': 'Barbados', 'BE': 'Belgium', 'BM': 'Bermuda',
                   'BN': 'Brunei Darussalam',
                   'BO': 'Bolivia', 'BH': 'Bahraini', 'BI': 'Burundi', 'BJ': 'Benin', 'BT': 'Bhutan', 'JM': 'Jamaica',
                   'BV': 'Bouvet Island', 'JO': 'Jordanian', 'WS': 'Samoa', 'BR': 'Brazil', 'BS': 'Bahamas',
                   'BY': 'Belarus',
                   'BZ': 'Belize', 'RU': 'Russian', 'RW': 'Rwanda', 'LT': 'Lithuania', 'RE': 'Reunion',
                   'LU': 'Luxembourg',
                   'TJ': 'Tajikistan', 'RO': 'Romania', 'TK': 'Tokelau', 'GW': 'Guinea-Bissau', 'GU': 'Guam',
                   'GT': 'Guatemala',
                   'GS': 'South Georgia and the South Sandwich Islands', 'GR': 'Greece', 'GQ': 'Equatorial Guinea',
                   'GP': 'Guadeloupe', 'JP': 'Japan', 'GY': 'Guyana', 'GF': 'French Guiana', 'GE': 'Georgia',
                   'GD': 'Grenada',
                   'GB': 'United Kingdom', 'GA': 'Gabon', 'PK': 'Pakistani', 'GN': 'Guinea', 'GM': 'Gambia',
                   'GL': 'Greenland',
                   'GI': 'Gibraltar', 'GH': 'Ghana', 'OM': 'Omani', 'TN': 'Tunisia', 'BW': 'Botswana', 'HR': 'Croatia',
                   'HT': 'Haiti',
                   'HU': 'Hungary', 'HK': 'Hong Kong', 'HN': 'Honduras', 'HM': 'Heard Island and Mcdonald Islands',
                   'VE': 'Venezuela',
                   'PR': 'Puerto Rico', 'PS': 'Palestinian Territory, Occupied', 'PW': 'Palau', 'PT': 'Portugal',
                   'SJ': 'Svalbard and Jan Mayen', 'PY': 'Paraguay', 'IQ': 'Iraqi', 'PA': 'Panama',
                   'PF': 'French Polynesia',
                   'PG': 'Papua New Guinea', 'PE': 'Peru', 'SO': 'Somalia', 'PH': 'Filipino', 'PN': 'Pitcairn',
                   'PL': 'Poland',
                   'PM': 'Saint Pierre and Miquelon', 'ZM': 'Zambia', 'EH': 'Western Sahara', 'EE': 'Estonia',
                   'EG': 'Egyptian',
                   'ZA': 'South African', 'EC': 'Ecuador', 'AL': 'Albania', 'AO': 'Angola', 'KZ': 'Kazakhstan',
                   'ET': 'Ethiopia',
                   'ZW': 'Zimbabwe', 'KY': 'Cayman Islands', 'ES': 'Spanish', 'ER': 'Eritrea',
                   'MD': 'Moldova, Republic of',
                   'MG': 'Madagascar', 'MA': 'Moroccan', 'MC': 'Monaco', 'UZ': 'Uzbekistan', 'MM': 'Myanmar',
                   'ML': 'Mali',
                   'MO': 'Macao', 'MN': 'Mongolia', 'MH': 'Marshall Islands', 'US': 'United States',
                   'UM': 'United States Minor Outlying Islands', 'MT': 'Malta', 'MW': 'Malawi', 'MV': 'Maldives',
                   'MQ': 'Martinique',
                   'MP': 'Northern Mariana Islands', 'MS': 'Montserrat', 'MR': 'Mauritania', 'UG': 'Uganda',
                   'UA': 'Ukraine',
                   'MX': 'Mexico', 'IL': 'Israel', 'FR': 'French', 'IO': 'British Indian Ocean Territory',
                   'AF': 'Afghan',
                   'FI': 'Finland', 'FJ': 'Fiji', 'FK': 'Falkland Islands (Malvinas)',
                   'FM': 'Micronesia, Federated States of',
                   'FO': 'Faroe Islands', 'NI': 'Nicaragua', 'NL': 'Netherlands', 'NO': 'Norway', 'NA': 'Namibia',
                   'NC': 'New Caledonia', 'NE': 'Niger', 'NF': 'Norfolk Island', 'NG': 'Nigerian', 'NZ': 'New Zealand',
                   'NP': 'Nepalese', 'NR': 'Nauru', 'NU': 'Niue', 'CK': 'Cook Islands', 'CI': "Cote D'Ivoire",
                   'CH': 'Switzerland',
                   'CO': 'Colombia', 'CN': 'Chinese', 'CM': 'Cameroon', 'CL': 'Chile', 'CC': 'Cocos (Keeling) Islands',
                   'CA': 'Canadian', 'CG': 'Congo', 'CF': 'Central African Republic',
                   'CD': 'Congo, the Democratic Republic of the',
                   'CZ': 'Czech Republic', 'CY': 'Cyprus', 'CX': 'Christmas Island', 'CS': 'Serbia and Montenegro',
                   'CR': 'Costa Rica', 'KP': "Korea, Democratic People's Republic of", 'CV': 'Cape Verde', 'CU': 'Cuba',
                   'SZ': 'Swaziland', 'SY': 'Syrian', 'KG': 'Kyrgyzstan', 'KE': 'Kenyan', 'SR': 'Suriname',
                   'KI': 'Kiribati',
                   'KH': 'Cambodia', 'SV': 'El Salvador', 'KM': 'Comoros', 'ST': 'Sao Tome and Principe',
                   'SK': 'Slovakia',
                   'KR': 'Korea, Republic of', 'SI': 'Slovenia', 'SH': 'Saint Helena', 'KW': 'Kuwait', 'SN': 'Senegal',
                   'SM': 'San Marino', 'SL': 'Sierra Leone', 'SC': 'Seychelles', 'SB': 'Solomon Islands', 'SA': 'Saudi',
                   'SG': 'Singaporean', 'SE': 'Sweden', 'SD': 'Sudanese', 'DO': 'Dominican Republic', 'DM': 'Dominica',
                   'DJ': 'Djibouti', 'DK': 'Denmark', 'DE': 'German', 'YE': 'Yemeni', 'AT': 'Austria', 'DZ': 'Algerian',
                   'MK': 'Macedonia, the Former Yugoslav Republic of', 'UY': 'Uruguay', 'YT': 'Mayotte',
                   'MU': 'Mauritius',
                   'KN': 'Saint Kitts and Nevis', 'LB': 'Lebanese', 'LC': 'Saint Lucia',
                   'LA': "Lao People's Democratic Republic",
                   'TV': 'Tuvalu', 'TW': 'Taiwanese', 'TT': 'Trinidad and Tobago', 'TR': 'Turkey', 'LK': 'Sri Lankan',
                   'LI': 'Liechtenstein', 'LV': 'Latvia', 'TO': 'Tonga', 'TL': 'Timor-Leste', 'TM': 'Turkmenistan',
                   'LR': 'Liberia',
                   'LS': 'Lesotho', 'TH': 'Thai', 'TF': 'French Southern Territories', 'TG': 'Togo', 'TD': 'Chad',
                   'TC': 'Turks and Caicos Islands', 'LY': 'Libyan Arab Jamahiriya',
                   'VA': 'Holy See (Vatican City State)',
                   'VC': 'Saint Vincent and the Grenadines', 'AE': 'Emirati', 'AD': 'Andorra',
                   'AG': 'Antigua and Barbuda',
                   'VG': 'Virgin Islands, British', 'AI': 'Anguilla', 'VI': 'Virgin Islands, U.s.', 'IS': 'Iceland',
                   'IR': 'Iranian',
                   'AM': 'Armenia', 'IT': 'Italian', 'VN': 'Vietnamese', 'AN': 'Netherlands Antilles',
                   'AQ': 'Antarctica',
                   'AS': 'American Samoa', 'AR': 'Argentina', 'AU': 'Australian', 'VU': 'Vanuatu', 'AW': 'Aruba',
                   'IN': 'Indian',
                   'TZ': 'Tanzania, United Republic of', 'AZ': 'Azerbaijan', 'IE': 'Ireland', 'ID': 'Indonesian',
                   'MY': 'Malaysian',
                   'QA': 'Qatari', 'MZ': 'Mozambique'}

    try:
        if nationality_iso:
            connet, curs = db1sl_connection()
            if len(nationality_iso.split(",")) > 0:
                for cmp_name in nationality_iso.split(","):
                    temp_loc = []
                    if cmp_name:
                        value_data = nationality.get(str(cmp_name).upper(), None)
                        if value_data:
                            natuuid = nationlity_master.get(value_data.strip().lower(), None)
                            temp_loc.append(jobid)
                            temp_loc.append(natuuid)
                            temp_loc.append(value_data.strip().encode("utf8"))
                            temp_loc.append(createdate)
                            temp_loc.append(updatedate)
                            temp_loc.append(is_deleted)
                            Total_national.append(tuple(temp_loc))
            connet.close()
    except:
        pass
    return Total_national


def job_levels_insert(jobid, levels_id, is_deleted, createdate, updatedate):
    Total_levels = []
    try:
        if levels_id:
            connet, curs = db1sl_connection()
            if len(levels_id.split(",")) > 0:
                for cmp_name in levels_id.split(","):
                    temp_loc = []
                    if cmp_name:
                        query = "select name from edu_levels where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            natuuid = highest_qualifications_master.get(value_data.get("name").strip().lower(),None)
                            temp_loc.append(jobid)
                            temp_loc.append(natuuid)
                            temp_loc.append(value_data.get("name").strip().encode("utf8"))
                            temp_loc.append(is_deleted)
                            temp_loc.append(createdate)
                            temp_loc.append(updatedate)
                            Total_levels.append(tuple(temp_loc))
            connet.close()
    except:
        pass
    return Total_levels


def job_streams_insert(jobid, stream_id, is_deleted, createdate, updatedate):
    Total_streams = []
    try:
        if stream_id:
            connet, curs = db1sl_connection()
            if len(stream_id.split(",")) > 0:
                for cmp_name in stream_id.split(","):
                    temp_loc = []
                    if cmp_name:
                        query = "select name from edu_streams where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            streamuuid = qualification_specializations_master.get(value_data.get("name").strip().lower(),None)
                            temp_loc.append(jobid)
                            temp_loc.append(streamuuid)
                            temp_loc.append(value_data.get("name").strip().encode("utf8"))
                            temp_loc.append(is_deleted)
                            temp_loc.append(createdate)
                            temp_loc.append(updatedate)
                            Total_streams.append(tuple(temp_loc))
            connet.close()
    except:
        pass
    return Total_streams


def get_site_context(channelid):
    site = {1: "rexmonster", 2: "monstergulf", 6: "monstersingapore", 8: "monsterthailand",
            7: "monsterphilippines", 9: "monstervietnam", 11: "monstermalaysia", 10: "monsterindonesia",
            5: "monsterhongkong"}
    site_context = None
    try:
        if channelid:
            site_context = site.get(int(channelid))
    except:
        pass
    return site_context


def job_country_insert(jobid, country_id, is_deleted, createdate, updatedate):
    Total_countries = []
    try:
        if country_id:
            if '204' in str(country_id):
                country_id= str(country_id)+',158,170,178,180,182,192,238,237,250,486'
            connet, curs = db1sl_connection()
            if len(country_id.split(",")) > 0:
                for cmp_name in country_id.split(","):
                    temp_loc = []
                    if cmp_name:
                        query = "select name from job_locations where id=%s;" % (
                            cmp_name)
                        curs.execute(query)
                        value_data = curs.fetchone()
                        if value_data:
                            if value_data.get("name").strip().lower() == 'hongkong':
                                value_data["name"] = "hong kong"
                            if value_data.get("name").strip().lower() == 'uk':
                                value_data["name"] = "United Kingdom"
                            if value_data.get("name").strip().lower() == 'us':
                                value_data["name"] = "United States"
                            if value_data.get("name").strip().lower() == 'vietnam':
                                value_data["name"] = "Vietnam"
                            countriesuuid = countries_name_master.get(value_data.get("name").strip().lower(), None)
                            if countriesuuid:
                                temp_loc.append(jobid)
                                temp_loc.append(countriesuuid)
                                temp_loc.append(is_deleted)
                                temp_loc.append(createdate)
                                temp_loc.append(updatedate)
                                Total_countries.append(tuple(temp_loc))
            connet.close()
    except:
        pass
    return Total_countries


def job_targeting_keyword_insert(jobid, free_text_cols_value, is_deleted, createdate, updatedate):
    Total_role_loc = []
    if free_text_cols_value:
        json_data = json.loads(free_text_cols_value)
        if json_data.get("roles", None):
            temo_rolloc = []
            role_data = json_data.get("roles", None)
            temo_rolloc.append(jobid)
            temo_rolloc.append(None)
            temo_rolloc.append(role_data.values()[0])
            temo_rolloc.append("roles")
            temo_rolloc.append(is_deleted)
            temo_rolloc.append(createdate)
            temo_rolloc.append(updatedate)
            Total_role_loc.append(tuple(temo_rolloc))
        if json_data.get("loc", None):
            temo_rolloc = []
            role_data = json_data.get("loc", None)
            temo_rolloc.append(jobid)
            temo_rolloc.append(None)
            # temo_rolloc.append(int(role_data.keys()[0]))
            temo_rolloc.append(role_data.values()[0])
            temo_rolloc.append("loc")
            temo_rolloc.append(is_deleted)
            temo_rolloc.append(createdate)
            temo_rolloc.append(updatedate)
            Total_role_loc.append(tuple(temo_rolloc))
    return Total_role_loc


def get_job_for_women_for_retiree(extra_options):
    job_women = '0'
    job_retiree = '0'
    job_work_from_home = '0'
    job_ncov19 = '0'
    if extra_options:
        json_extra_data = json.loads(extra_options)
        if json_extra_data.get("women_on_top", None):
            if json_extra_data.get("women_on_top", None).values()[0] == '1':
                job_women = '1'
        if json_extra_data.get("careers_after_career", None):
            if json_extra_data.get("careers_after_career", None).values()[0] == '1':
                job_retiree = '1'
        if json_extra_data.get("work_from_home", None):
            if json_extra_data.get("work_from_home", None).values()[0] == '1':
                job_work_from_home = '1'
        if json_extra_data.get("ncov19", None):
            if json_extra_data.get("ncov19", None).values()[0] == '1':
                job_ncov19 = '1'
    return job_women, job_retiree, job_work_from_home, job_ncov19

def get_disability_name(disability_id):
    dis_name = None
    if disability_id:
        connet, curs = db1sl_connection()
        query = "select name from disablity_type_map where id=%s;" % (
            disability_id)
        curs.execute(query)
        value_data = curs.fetchone()
        connet.close()
        if value_data:
            dis_name = value_data.get("name", None)
    return dis_name


def job_contract_insert(jobid, contract_value, is_deleted, createdate, updatedate):
    contract_data = []
    disability_data = []
    billing_freq = None
    if contract_value:
        json_contract_data = json.loads(contract_value)
        json_value = json_contract_data.get("contract", None)
        if json_value:
            tmp_contract = []
            contractuuid = None
            if json_value.get("contract_tenure", None):
                if json_value.get("contract_tenure", None).get("value", None):
                    contract_tenure_val = json_value.get("contract_tenure", None).get("value", None)
                    if contract_tenure_val:
                        contractuuid = contract_tenures_master.get(contract_tenure_val.strip().lower(), None)
            if json_value.get("billing_duration", None):
                if json_value.get("billing_duration", None).get("value", None):
                    if 'month' in json_value.get("billing_duration", None).get("value", None).lower():
                        billing_freq = 'MONTH'
                    if 'year' in json_value.get("billing_duration", None).get("value", None).lower():
                        billing_freq = 'YEAR'
            tmp_contract.append(jobid)
            tmp_contract.append(None)
            tmp_contract.append(contractuuid)
            tmp_contract.append(None)
            tmp_contract.append(None)
            tmp_contract.append(billing_freq)
            tmp_contract.append(is_deleted)
            tmp_contract.append(createdate)
            tmp_contract.append(updatedate)
            contract_data.append(tuple(tmp_contract))
        json_value_disablity = json_contract_data.get("CII", None)
        if json_value_disablity:
            tmp_disability = []
            disablity_type_uuid = None
            disablity_subtype_uuid = None
            disablity_subtype_inner_uuid = None
            if json_value_disablity.get("disable_type", None):
                if json_value_disablity.get("disable_type", None).get("value", None):
                    disablity_type_val = json_value_disablity.get("disable_type", None).get("value", None)
                    if disablity_type_val:
                        disability_name_type = get_disability_name(disablity_type_val)
                        if disability_name_type:
                            disablity_type_uuid = disability_type_subtype_master.get(disability_name_type.strip().lower(), None)
            if json_value_disablity.get("disable_sub_type", None):
                if json_value_disablity.get("disable_sub_type", None).get("value", None):
                    disablity_subtype_val = json_value_disablity.get("disable_sub_type", None).get("value", None)
                    if disablity_subtype_val:
                        disability_name_subtype = get_disability_name(disablity_subtype_val)
                        if disability_name_subtype:
                            disablity_subtype_uuid = disability_type_subtype_master.get(disability_name_subtype.strip().lower(), None)

            if json_value_disablity.get("disable_sub_type_inner", None):
                if json_value_disablity.get("disable_sub_type_inner", None).get("value", None):
                    disablity_subtype_inner_val = json_value_disablity.get("disable_sub_type_inner", None).get("value", None)
                    if disablity_subtype_inner_val:
                        disability_name_subtype_inner = get_disability_name(disablity_subtype_inner_val)
                        if disability_name_subtype_inner:
                            disablity_subtype_inner_uuid = disability_inner_subtype_master.get(disability_name_subtype_inner.strip().lower(), None)
            tmp_disability.append(jobid)
            tmp_disability.append(disablity_type_uuid)
            tmp_disability.append(disablity_subtype_uuid)
            tmp_disability.append(disablity_subtype_inner_uuid)
            tmp_disability.append(is_deleted)
            tmp_disability.append(createdate)
            tmp_disability.append(updatedate)
            disability_data.append(tuple(tmp_disability))
    return contract_data, disability_data


def get_typeuuid(jobtype):
    typeuuid = None
    if jobtype:
        eagcon_type, eagcur_type = eagle_connection()
        query_contract = "select uuid from job_types where id in (select job_type_id from job_type_langs where kiwi_name ='%s' or name='%s');" % (
            jobtype.strip(), jobtype.strip())
        eagcur_type.execute(query_contract)
        data = eagcur_type.fetchone()
        if data:
            typeuuid = data.get("uuid", "")
        eagcon_type.close()
    return typeuuid


def job_walkin_insert(jobid, walkin_details, is_deleted, createdate, updatedate):
    walkin_record = []
    walkin_address_record = []
    if walkin_details:
        json_walkin_data = json.loads(walkin_details)
        json_value = json_walkin_data.get("walkin", None)
        if json_value:
            start_date = None
            end_date = None
            number_opening = None
            if json_value.get("walkin_openings", None):
                open_raw = json_value.get("walkin_openings", None).get("value", None)
                if open_raw:
                    number_opening = open_raw
            if json_value.get("from_date", None):
                start_date_raw = json_value.get("from_date", None).get("value", None)
                if start_date_raw:
                    if len(str(start_date_raw).split())==3:
                        start_date = get_dateunixtimestamp(str(start_date_raw)[:-2].strip())
                    else:
                        start_date = get_dateunixtimestamp(str(start_date_raw).strip())
            if json_value.get("to_date", None):
                end_date_raw = json_value.get("to_date", None).get("value", None)
                if end_date_raw:
                    if len(str(end_date_raw).split())==3:
                        end_date = get_dateunixtimestamp(str(end_date_raw)[:-2].strip())
                    else:
                        end_date = get_dateunixtimestamp(str(end_date_raw).strip())
            walkin_venue = ""
            if json_value.get("walkin_venue", None):
                walkin_venue_raw = json_value.get("walkin_venue", None).get("value", None)
                if walkin_venue_raw:
                    walkin_venue = walkin_venue_raw.strip().encode("utf8")
                    walkin_address_record.append(walkin_venue)
            if json_value.get("walkin_venue_premium", None):
                walkin_venue_raw = json_value.get("walkin_venue_premium", None)
                for df in walkin_venue_raw:
                    if len(df.values()):
                        walkin_address_record.append(df.values()[0])

            if json_value.get("walkin_city", None):
                temp_walkin = []
                tmp_walkin_venue = []
                location_id = json_value.get("walkin_city", None).get("value", None)
                if location_id:
                    connet, curs = db1sl_connection()
                    query = "select name from job_locations where id=%s;" % (
                        location_id)
                    # print query
                    curs.execute(query)
                    value_data = curs.fetchone()
                    # print value_data
                    if value_data:
                        countriesuuid = countries_name_master.get(value_data.get("name").strip().lower(),None)
                        temp_walkin.append(jobid)
                        temp_walkin.append(countriesuuid)
                        temp_walkin.append(value_data.get("name").strip().encode("utf8"))
                        temp_walkin.append(number_opening)
                        temp_walkin.append(start_date)
                        temp_walkin.append(end_date)
                        temp_walkin.append(is_deleted)
                        temp_walkin.append(createdate)
                        temp_walkin.append(updatedate)
                        walkin_record.append(tuple(temp_walkin))
    return walkin_record, list(set(walkin_address_record))


def get_cmp_logo_cmp_website(kiwicorpid):
    cmp_logo = None
    cmp_website = None
    if kiwicorpid:
        eagcon_logo, eagcur_logo = eagle_connection()
        query_contract = "select company_website,logo_url from corps where kiwi_corp_id ='%s';" % (
            kiwicorpid)
        eagcur_logo.execute(query_contract)
        data = eagcur_logo.fetchone()
        if data:
            cmp_logo = data.get("logo_url", None)
            cmp_website = data.get("company_website", None)
        eagcon_logo.close()
    return cmp_logo, cmp_website

def check_msj_actve(jobmodel_type,folderid):
    is_msj = False
    if str(jobmodel_type).lower().strip()=='sjs':
        connet, curs = db1sl_connection()
        query = "select ad.status as adword_status,ac.status as campaigne_status, ( current_date >= ad.start_date and if ( ad.end_date = '0000-00-00' , 1 , ad.end_date>=current_date ) ) and ad.status='active' as is_active from socialjobs_automation_queue as saq inner join adwords as ad on saq.adwords_id = ad.id inner join ad_campaigne as ac on ad.campaigne_id = ac.id where saq.posting_id='%s'" % (
            folderid)
        curs.execute(query)
        value_data = curs.fetchone()
        connet.close()
        if value_data:
            if value_data.get("is_active",0)==1 and value_data.get("adword_status","").lower().strip()=="active" and value_data.get("campaigne_status","").lower().strip()=="active":
                is_msj = True
        connet.close()
    return is_msj

def get_currency_code(currencyid, minSal,maxSal,minSalChannel,maxSalChannel, Channel_id):
    min_salary = minSal
    max_salary = maxSal
    currency_code = None
    if Channel_id:
        if int(Channel_id)!=0:
            if minSal:
                min_salary = int(float(minSal)*100000)
            if maxSal:
                max_salary = int(float(maxSal)*100000)
        
        if ((minSalChannel is not None) and (maxSalChannel is not None)):
                try:
                    min_salary = int(minSalChannel)
                    max_salary = int(maxSalChannel)
                except:
                    pass
        #else:
        #        min_salary = minSalChannel
        #        max_salary = maxSalChannel
    if currencyid:
        eagcon_logo, eagcur_logo = db1sl_connection()
        query_contract = "select code from currency where id ='%s';" % (
            currencyid)
        # print query_contract
        eagcur_logo.execute(query_contract)
        data = eagcur_logo.fetchone()
        if data:
	    if data.get("code", None).lower()=="qmr":
                 currency_code="OMR"
            else:
                 currency_code = data.get("code", None)
        eagcon_logo.close()
    return currency_code, min_salary, max_salary

def get_post_on_public(folderid):
    is_post_on_public = None
    walkin_venue_shedule_list = []
    renew_freq_uuid = None
    start_date = None
    end_date = None
    if folderid:
        connection, cursor = db1sl_connection()
        query = "select enabled from rec_social_shared_jobs where folderid ='%s';" % (
            folderid)
        cursor.execute(query)
        data = cursor.fetchone()
        if data:
            is_post_on_public = data.get("enabled", None)
        query1 = "select * from walkin_venue_shedule_slots where folderid ='%s';" % (
            folderid)
        cursor.execute(query1)
        for data1 in cursor:
            tmp_slot = []
            if data1.get("schedule_date", None):
                tmp_slot.append(str(data1.get("schedule_date", None)))
            else:
                tmp_slot.append(None)
            tmp_slot.append(data1.get("venue", None))
            tmp_slot.append(data1.get("venue_address", None))
            tmp_slot.append(data1.get("from_time", None))
            tmp_slot.append(data1.get("to_time", None))
            tmp_slot.append(data1.get("no_of_candidates", None))
            tmp_slot.append(data1.get("apply", None))
            tmp_slot.append(data1.get("max_apply", None))
            tmp_slot.append(check_deleted(data1.get("enabled", None)))
            tmp_slot.append(get_dateunixtimestamp(data1.get("createdate", None)))
            tmp_slot.append(get_dateunixtimestamp(data1.get("updatedate", None)))
            walkin_venue_shedule_list.append(tmp_slot)
        query2 = "select start_date,expire_date,refresh_periodicity from job_autorefresh where folderid ='%s';" % (
            folderid)
        cursor.execute(query2)
        data2 = cursor.fetchone()
        if data2:
            start_date = data2.get("start_date", None)
            end_date = data2.get("expire_date", None)
            freq_raw = data2.get("refresh_periodicity", None)
            freq_dict = {"0": "Disable", "7": "Every Week", "15": "Every Fortnight", "30": "Every Month"}
            if freq_raw:
                # print 'freq_raw-------', freq_raw
                name_freq = freq_dict.get(str(freq_raw))
                eagcon_freq, eagcur_freq = eagle_connection()
                query_contract = "select uuid from job_renew_frequencies where id in (select job_renew_frequency_id from job_renew_frequency_langs where name='%s');" % (
                    name_freq.strip())
                # print query_contract
                eagcur_freq.execute(query_contract)
                data_freq = eagcur_freq.fetchone()
                if data_freq:
                    renew_freq_uuid = data_freq.get("uuid", None)
                    # print name_freq, renew_freq_uuid
                eagcon_freq.close()
        connection.close()
    return is_post_on_public, walkin_venue_shedule_list, renew_freq_uuid, start_date, end_date

def get_is_questionaire(fold_id):
    is_questionaire = None
    is_scrape = None
    if fold_id:
        connection, cursor = db1sl_connection()
        query = "select questionnaire_id from job_questionnaire_map where folderid ='%s';" % (
            fold_id)
        cursor.execute(query)
        data = cursor.fetchone()
        if data:
            questionaire_raw = data.get("questionnaire_id", None)
            if questionaire_raw:
                is_questionaire = '1'
        query_scrape = "select type from ftp_jobs where folderid ='%s';" % (
            fold_id)
        cursor.execute(query_scrape)
        data1 = cursor.fetchone()
        if data1:
            scrape_raw = data1.get("type", None)
            if scrape_raw:
                is_scrape = 'SCRAPPING'
        connection.close()
    return is_questionaire, is_scrape


def fetch_data(k, lastfolderid):
    total_data_main = []
    last_folid = None
    if lastfolderid:
        connection, cursor = db1sl_connection()
        query = "select jb.*,cf.subchannel_id from jobs_" + str(
            k) + " as jb inner Join corp_folders as cf on cf.id=jb.folderid where jb.folderid>%s order by jb.folderid asc;"%(lastfolderid)
        # query="select jb.*,cf.subchannel_id from jobs_10 as jb inner Join corp_folders as cf on cf.id=jb.folderid where jb.company='10549'"
        # print query
        # query = \
        #     "select * from corps order by id desc limit 100;"
        cursor.execute(query)
        total_data_main = cursor.fetchall()
        if len(total_data_main)>0:
            last_folid = total_data_main[-1].get("folderid", None)
        else:
            last_folid = lastfolderid
        connection.close()
    return total_data_main, last_folid


def jobs_function_execution(total_jobs_data):
    i = 0
    connection_eagle_jobs_write, cursor_eagle_jobs_write = eagle_connection()
    for row in total_jobs_data:
        try:
            value_none = None
            # print row
            temp_jobs = []
            temp_jobs.append(get_corp_id(row["company"]))
            accountid, recruiterid = get_account_id(row["subuid"])
            temp_jobs.append(accountid)
            temp_jobs.append(recruiterid)
            # temp_jobs.append(42659)
            # temp_jobs.append(174491)
            temp_jobs.append(get_typeuuid(row["job_model"]))
            temp_jobs.append(get_jobtype_uuid(row["job_type"]))
            temp_jobs.append(row["ref_code"])
            temp_jobs.append(value_none)
            temp_jobs.append(row["apply_url"])
            temp_jobs.append(value_none)
            currency_code , min_sal,max_sal= get_currency_code(row["currency_id"], row["minsal"],row["maxsal"],row["minsal_channel"],row["maxsal_channel"],row["channel_id"])
            # print currency_code , min_sal,max_sal
            temp_jobs.append(row["minexp"])
            temp_jobs.append(row["maxexp"])
            temp_jobs.append(min_sal)
            temp_jobs.append(max_sal)
            # print temp_jobs
            # break
            temp_jobs.append(currency_code)
            temp_jobs.append(value_none)
            company_logo_url, cmp_website = get_cmp_logo_cmp_website(row["company"])
            temp_jobs.append(company_logo_url)  # Need to implement
            temp_jobs.append(row["hide_cname"])
            temp_jobs.append(row["coordinator_phone"])
            temp_jobs.append(cmp_website)
            temp_jobs.append(get_dateunixtimestamp(row["postingdate"]))
            temp_jobs.append(get_dateunixtimestamp(row["updatedate"]))
            temp_jobs.append(get_dateunixtimestamp(row["postingdate"]))
            temp_jobs.append(get_dateunixtimestamp(row["renewaldate"]))
            temp_jobs.append(get_draft_scheduleunixtimestamp(row["draftdate"]))
            temp_jobs.append(get_draft_scheduleunixtimestamp(row["scheduledate"]))
            temp_jobs.append(get_dateunixtimestamp(row["close"]))
            enabled = row["enabled"]
            if row["job_model"]=='SJS':
               is_msj = check_msj_actve(row["job_model"],row["folderid"])
               if is_msj:
	          enabled = '1'
               else:
	          enabled='9'
            temp_jobs.append(enabled)
            #temp_jobs.append(row["enabled"])
            temp_jobs.append(value_none)
            post_on_public, walkin_venue_shedule_slot, renew_frequuid, renew_from, renew_to = get_post_on_public(
                row["folderid"])
            temp_jobs.append(renew_frequuid)
            temp_jobs.append(renew_from)
            temp_jobs.append(renew_to)
            temp_jobs.append(row["notify"])
            temp_jobs.append(row["apps_by_mail"])
            temp_jobs.append(row["show_cdetails"])
            temp_jobs.append(post_on_public)
            temp_jobs.append(row["inventory_consumed"])
            temp_jobs.append(row["service_id"])
            is_bold = '0'
            is_jd_logo = '0'
            is_serach_logo = '0'
            is_quick_job = '0'
            if row["extra_info"]:
                for jd in row["extra_info"].split(":"):
                    if "bold" in str(jd).lower():
                        if "=" in str(jd):
                            if jd.split("=")[-1] == '1':
                                is_bold = '1'
                    if "JDLOGO" in str(jd):
                        if "=" in str(jd):
                            if jd.split("=")[-1] == '1':
                                is_jd_logo = '1'
                    if "SRLOGO" in str(jd):
                        if "=" in str(jd):
                            if jd.split("=")[-1] == '1':
                                is_serach_logo = '1'
                    if "QUICK_JP" in str(jd):
                        is_quick_job  = '1'

            isquestionare,is_scrape = get_is_questionaire(row["folderid"])
            temp_jobs.append(is_scrape) #Still work for scrape_job
            temp_jobs.append(row["posting_board"])
            temp_jobs.append(row["is_grace"])
            temp_jobs.append(is_quick_job)  # need to
            temp_jobs.append(row["channel_id"])
            temp_jobs.append(get_site_context(row["subchannel_id"]))
            temp_jobs.append(isquestionare) # still working on questionaire job_questionnaire_map
            womenjb, retireejob,is_work_from_home, is_ncov19 = get_job_for_women_for_retiree(row["extra_options"])
            # print womenjb, retireejob
            temp_jobs.append(womenjb)
            temp_jobs.append(retireejob)
            temp_jobs.append(is_work_from_home)
            temp_jobs.append(is_ncov19)
            temp_jobs.append(value_none)  # need to ask
            temp_jobs.append(row["folderid"])
            temp_jobs.append(row["subuid"])
            temp_jobs.append(row["job_from"])
            ssourcesql = 'insert into jobs (corp_id,account_id,recruiter_id,type_uuid,sub_type_uuid,reference_code,video_url,apply_url,opening,min_experience,max_experience,min_salary,max_salary,currency_code,hide_salary,company_logo_image_url,hide_company_name,recruiter_contact_number,company_website,created_at,updated_at,posted_at,renewal_at,drafted_at,scheduled_at,closed_at,status,auto_renew,renew_frequency_uuid,renew_from,renew_to,auto_match,apps_by_mail,show_contact_details,post_on_public,inventory_consumed,service_id,source,posting_board,grace_job,quick_job,channel_id,site_context,is_questionnaire,job_for_woman,job_for_retiree,work_from_home,ncov19,disability_certificate_required,kiwi_job_id,kiwi_subuid,job_from,latest_updated) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,current_timestamp(3))'
            ssourceval = tuple(temp_jobs)
            cursor_eagle_jobs_write.execute(ssourcesql, ssourceval)
            cursor_eagle_jobs_write.execute("select LAST_INSERT_ID() as id")
            job_id = cursor_eagle_jobs_write.fetchone()['id']
            # print job_id
            temp_job_langs = []
            temp_job_langs.append(job_id)
            temp_job_langs.append("en")
            if "ÃƒÂƒÃ" in str(row["title"]).encode("utf8"):
                row["title"] = row["title"].encode("ascii","ignore")
            if "ÃƒÂƒÃ" in str(row["summary"]).encode("utf8"):
                row["summary"] = row["summary"].encode("ascii","ignore")
            if "ÃƒÂƒÃ" in str(row["descr"]).encode("utf8"):
                row["descr"] = row["descr"].encode("ascii","ignore")
            temp_job_langs.append(row["title"])
            temp_job_langs.append(row["summary"])
            temp_job_langs.append(row["descr"])
            temp_job_langs.append(row["company_name"])
            temp_job_langs.append(row["coordinator_name"])
            temp_job_langs.append(row["comp_profile"])
            #temp_job_langs.append(check_deleted(row["enabled"]))
            temp_job_langs.append(get_dateunixtimestamp(row["postingdate"]))
            temp_job_langs.append(get_dateunixtimestamp(row["updatedate"]))
            ssourcesql_job_langs = 'insert into job_langs (job_id,iso_code,title,summary,description,company_name,recruiter_name,company_profile,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
            cursor_eagle_jobs_write.execute(ssourcesql_job_langs, tuple(temp_job_langs))
            keyskill_records = get_keyskill_records(job_id, row["keyskills"], check_deleted(row["enabled"]),
                                                    get_dateunixtimestamp(row["postingdate"]),
                                                    get_dateunixtimestamp(row["updatedate"]))
            # print keyskill_records
            if len(keyskill_records) > 0:
                ssourcesql_job_keyskill = 'insert into job_skill (job_id,skill_uuid,skill_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                for jobs_skill in keyskill_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_keyskill, jobs_skill)
            job_cat_records = job_cat_function_insert(job_id, row["cat"], check_deleted(row["enabled"]),
                                                      get_dateunixtimestamp(row["postingdate"]),
                                                      get_dateunixtimestamp(row["updatedate"]))
            # print job_cat_records
            if len(job_cat_records) > 0:
                ssourcesql_job_cat = 'insert into job_function (job_id,function_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                for job_cat in job_cat_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_cat, job_cat)
            job_roles_records = job_cat_function_insert(job_id, row["roles"], check_deleted(row["enabled"]),
                                                        get_dateunixtimestamp(row["postingdate"]),
                                                        get_dateunixtimestamp(row["updatedate"]))
            # print job_roles_records, row["roles"]
            if len(job_roles_records) > 0:
                ssourcesql_job_role = 'insert into job_role (job_id,role_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                for job_role in job_roles_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_role, job_role)
            job_industry_records = job_industry_insert(job_id, row["industry"], check_deleted(row["enabled"]),
                                                       get_dateunixtimestamp(row["postingdate"]),
                                                       get_dateunixtimestamp(row["updatedate"]))
            # print job_industry_records
            if len(job_industry_records) > 0:
                ssourcesql_job_indus = 'insert into job_industry (job_id,industry_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                for job_indus in job_industry_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_indus, job_indus)

            job_locations_records = job_locations_insert(job_id, row["loc"], check_deleted(row["enabled"]),
                                                         get_dateunixtimestamp(row["postingdate"]),
                                                         get_dateunixtimestamp(row["updatedate"]))
            # print '!!!!!!!!!!!!!!!!!!!!!!!!!!', job_locations_records
            if len(job_locations_records) > 0:
                ssourcesql_job_loc = 'insert into job_job_location (job_id,location_uuid,location_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                for job_loc in job_locations_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_loc, job_loc)
            job_nationality_records = job_nationality_insert(job_id, row["nationality"], check_deleted(row["enabled"]),
                                                             get_dateunixtimestamp(row["postingdate"]),
                                                             get_dateunixtimestamp(row["updatedate"]))
            # print '==========>>>>>>>>', job_nationality_records
            if len(job_nationality_records) > 0:
                ssourcesql_job_nationality = 'insert into job_nationality (job_id,nationality_uuid,nationality_text,created_at,updated_at, deleted) VALUES (%s,%s,%s,%s,%s,%s)'
                for job_nation in job_nationality_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_nationality, job_nation)
            job_levels_records = job_levels_insert(job_id, row["level"], check_deleted(row["enabled"]),
                                                   get_dateunixtimestamp(row["postingdate"]),
                                                   get_dateunixtimestamp(row["updatedate"]))
            # print '==========>>>>>>>>', job_levels_records
            # break
            if len(job_levels_records) > 0:
                ssourcesql_job_level = 'insert into job_highest_qualification (job_id,job_highest_qualification_uuid,job_highest_qualification_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                for job_level in job_levels_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_level, job_level)
            job_streams_records = job_streams_insert(job_id, row["stream"], check_deleted(row["enabled"]),
                                                     get_dateunixtimestamp(row["postingdate"]),
                                                     get_dateunixtimestamp(row["updatedate"]))
            # print '++++++++++',job_streams_records, row["stream"]
            if len(job_streams_records) > 0:
                ssourcesql_job_stream = 'insert into job_qualification_specialization (job_id,qualification_specialization_uuid,qualification_specialization_text,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                for job_stream in job_streams_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_stream, job_stream)
            if row["coordinator_email"]:
                job_owner_email_records = (job_id, row["coordinator_email"].strip(), check_deleted(row["enabled"]),
                                           get_dateunixtimestamp(row["postingdate"]),
                                           get_dateunixtimestamp(row["updatedate"]))
                ssourcesql_job_owner_email = 'insert into job_owner_email (job_id,job_owner_email,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                cursor_eagle_jobs_write.execute(ssourcesql_job_owner_email, job_owner_email_records)
                # print job_owner_email_records

            job_country_records = job_country_insert(job_id, row["country_ids"], check_deleted(row["enabled"]),
                                                     get_dateunixtimestamp(row["postingdate"]),
                                                     get_dateunixtimestamp(row["updatedate"]))
            # print 'CCCCCCCCCCCC', job_country_records, row["country_ids"]
            if len(job_country_records) > 0:
                ssourcesql_job_countries = 'insert into job_country (job_id,country_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                for job_country in job_country_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_countries, job_country)
            job_targeting_keyword_records = job_targeting_keyword_insert(job_id, row["free_text_cols"],
                                                                         check_deleted(row["enabled"]),
                                                                         get_dateunixtimestamp(row["postingdate"]),
                                                                         get_dateunixtimestamp(row["updatedate"]))
            # print '==========>', job_targeting_keyword_records
            if len(job_targeting_keyword_records) > 0:
                ssourcesql_job_target_keyword = 'insert into job_targetting_keyword (job_id,targetting_keyword_id,targetting_keyword_text,type,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s)'
                for job_target_keyword in job_targeting_keyword_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_target_keyword, job_target_keyword)
            job_contract_records, job_disability_records = job_contract_insert(job_id, row["extra_options"], check_deleted(row["enabled"]),
                                                       get_dateunixtimestamp(row["postingdate"]),
                                                       get_dateunixtimestamp(row["updatedate"]))
            # print "@@@@", job_disability_records, job_contract_records
            if len(job_contract_records) > 0:
                ssourcesql_job_contract = 'insert into job_contract (job_id,earlist_joining_date,contract_tenure_uuid,min_billing_rate,max_billing_rate,billing_frequency,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                for job_contracts in job_contract_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_contract, job_contracts)
            if len(job_disability_records):
                ssourcesql_job_disability = 'insert into job_disability (job_id,disability_type_uuid,disability_subtype_uuid,disability_detail_uuid,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s)'
                for job_disable in job_disability_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_disability, job_disable)
            # print '&&&&&&&&&&&&&&&', is_bold, is_jd_logo,is_serach_logo, row["extra_info"]
            job_service_records = (job_id, is_bold, is_jd_logo, is_serach_logo, check_deleted(row["enabled"]),
                                   get_dateunixtimestamp(row["postingdate"]),
                                   get_dateunixtimestamp(row["updatedate"]))
            ssourcesql_job_service = 'insert into job_service (job_id,is_bold,is_jd_logo,is_search_logo,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s)'
            cursor_eagle_jobs_write.execute(ssourcesql_job_service, job_service_records)
            job_walkin_records, job_walkin_address_records = job_walkin_insert(job_id, row["extra_options"],
                                                                               check_deleted(row["enabled"]),
                                                                               get_dateunixtimestamp(row["postingdate"]),
                                                                               get_dateunixtimestamp(row["updatedate"]))

            # print job_walkin_records, job_walkin_address_records
            if len(job_walkin_records) > 0:
                ssourcesql_job_walkin = 'insert into job_walkin (job_id,city_uuid,city_text,openings,starts_at,ends_at,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                for jb_walkin in job_walkin_records:
                    cursor_eagle_jobs_write.execute(ssourcesql_job_walkin, jb_walkin)
                    cursor_eagle_jobs_write.execute("select LAST_INSERT_ID() as id")
                    walkin_id = cursor_eagle_jobs_write.fetchone()['id']
                    print 'walkin_id!!!!', walkin_id
                    if len(job_walkin_address_records) > 0:
                        ssourcesql_job_walkin_address = 'insert into job_walkin_address (job_walkin_id,address,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s)'
                        for waddress in job_walkin_address_records:
                            value_add = (walkin_id, waddress.strip().encode("utf8"), check_deleted(row["enabled"]),
                                         get_dateunixtimestamp(row["postingdate"]), get_dateunixtimestamp(row["updatedate"]))
                            # print'#################', value_add
                            cursor_eagle_jobs_write.execute(ssourcesql_job_walkin_address, value_add)
                    if len(walkin_venue_shedule_slot) > 0:
                        ssourcesql_job_walkin_slot = 'insert into job_walkin_schedule (job_walkin_id,schedule_date,venue,venue_address,from_time,to_time,no_of_candidates,apply,max_apply,deleted,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                        for wakin_slot in walkin_venue_shedule_slot:
                            wakin_slot.insert(0, walkin_id)
                            cursor_eagle_jobs_write.execute(ssourcesql_job_walkin_slot, tuple(wakin_slot))

            if i == 10:
                connection_eagle_jobs_write.commit()
                i = 0
            i += 1
            print 'Inserted  job folderid  and time : '+str(datetime.datetime.now().strftime("%Y:%m:%d:%H:%M:%S"))+"   jobid : "+str(row["folderid"])
        except Exception as ex:
            print ex
            continue
    connection_eagle_jobs_write.commit()
    connection_eagle_jobs_write.close()

def jobs_insert_fun():
    for k in range(1, 21):
        # print k
        last_floderinsert_id = main_directory + "/last_jobsinsert_folderid_"+str(k)
        read_file = open(last_floderinsert_id)
        lastfolderid= read_file.read()
        # read_file.write("1111")
        read_file.close()
        print 'Jobs_insert last id: ', lastfolderid
        if lastfolderid:
            total_data_main, last_folid = fetch_data(k, lastfolderid)
            print 'Total job Insert in Process', k, len(total_data_main)
            jobs_function_execution(total_data_main)
            if last_folid:
                last_writeid = open(last_floderinsert_id, 'w')
                last_writeid.write(str(last_folid))
                last_writeid.close()

if __name__ == "__main__":
    jobs_insert_fun()


