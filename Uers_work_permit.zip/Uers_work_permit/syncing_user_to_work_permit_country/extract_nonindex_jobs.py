# -*-coding:utf-8 -*-
import sys

reload(sys)
sys.setdefaultencoding("utf-8")

import requests
import time
import mysql.connector
import concurrent.futures
import smtplib,os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
from datetime import timedelta

class ExtractNonIndexJobs:
    def __init__(self):
        self.eagle_conf = {"user": "vineet", "password": "vineet@123@", "host": "10.216.247.111",
                           "database": "eagle"}
        self.headers = {
            'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; WOW64)\
                AppleWebKit/537.36 (KHTML'}
        self.path = os.path.dirname(os.path.abspath(__file__))
        self.filename = os.path.join(self.path,"jobid_list.xls")
        self.mainfile = "jobid_list.xls"

    def eagle_connection(self):
        connection_eagle = mysql.connector.connect(user=self.eagle_conf['user'],
                                                   password=self.eagle_conf['password'],
                                                   host=self.eagle_conf['host'],
                                                   database=self.eagle_conf['database'])
        cursor_eagle = connection_eagle.cursor(dictionary=True)
        return connection_eagle, cursor_eagle

    def get_ids(self,id):
        # id=1470752
        idnon = None
        cc = 0
        while cc < 10:
            cc += 1
            try:
                url = "https://apiv2.monsterindia.com/raven/api/public/search/v1/job-detail?jobId="+str(id).strip()
                response = requests.get(url,headers=self.headers,timeout=60)
                if response.status_code==200:
                    break
                elif response.status_code !=200:
                    idnon = id
                    break
            except Exception as e:
                print ("Error in response :",str(e))
                time.sleep(1)
                pass
        return idnon

    def send_mail(self,count):
        # yesterday = datetime.datetime.strftime(datetime.now() - timedelta(1), '%d-%m-%Y')
        yesterday = (datetime.now() - timedelta(days=1)).strftime('%d-%m-%Y')
        fromaddr = "webmaster@monster.co.in"
        toaddr=["Amit.Saini@monsterindia.com","vineetkumar.tiwari@monsterindia.com","Vipul.Kumar@monsterindia.com","vipul.sharma@monsterindia.com","Marghoob.Suleman@monsterindia.com","Upendersingh.Dahiya@monsterindia.com"]
        # tocc = ["vineetkumar.tiwari@monsterindia.com"]
        # toaddr = ["vineetkumar.tiwari@monsterindia.com"]
        msg = MIMEMultipart()
        msg['From'] = fromaddr
        msg['To'] = ", ".join(toaddr)
        # storing the subject
        msg['Subject'] = "Non Index JobId list Report"
        # string to store the body of the mail
        body = """<strong> Hi All,<br><br>Please find the non index Job_Id list Report  for %s and count is %s .<strong><BR><BR>

            Regards,<br>
            Vineet Kumar Tiwari""" % (yesterday,count)
        # attach the body with the msg instance
        msg.attach(MIMEText(body, 'html'))
        if count>0:
            # open the file to be sent
            filename = self.filename
            attachment = open(filename, "rb")
            # instance of MIMEBase and named as p
            p = MIMEBase('application', 'octet-stream')
            # To change the payload into encoded form
            p.set_payload((attachment).read())
            # encode into base64
            encoders.encode_base64(p)
            p.add_header('Content-Disposition', "attachment; filename= %s" % self.mainfile)
            # attach the instance 'p' to instance 'msg'
            msg.attach(p)
        # creates SMTP session
        s = smtplib.SMTP('10.216.240.89')
        # start TLS for security
        s.starttls()
        # Authentication
        s.login('smtp-auth@monsterindia.com', 'vS!wA7*z?_wsD=hx')
        # Converts the Multipart msg into a string
        text = msg.as_string()
        # sending the mail
        s.sendmail(fromaddr, toaddr, text)
        # terminating the session
        s.quit()

    def get_non_index_jobs(self):
        conn,curr = self.eagle_connection()
        query="select id from jobs where date(latest_updated)=date(DATE_ADD(NOW(), INTERVAL -1 DAY));"
        # query = "select id from jobs where date(latest_updated)=curdate();"
        curr.execute(query)
        records = curr.fetchall()
        conn.close()
        if len(records)>0:
            All_ids = [j.get("id") for j in records if j.get("id",None)]
            print ("All job ids count :", len(All_ids))
            Total_data= []
            with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
                future_to_url = {executor.submit(self.get_ids, url_jb): url_jb
                                 for url_jb in
                                 list(set(All_ids))[:]}
                for future in concurrent.futures.as_completed(future_to_url):
                    url2 = future_to_url[future]
                    try:
                        data = future.result()
                        if data:
                            Total_data.append(data)
                    except Exception as exc:
                        print ('=====>', exc, url2)
                        pass
            print ('Total non index count :',len(Total_data))
            if len(Total_data)>0:
                with open(self.filename, "wb") as ofs:
                    vale = ['Jobid']
                    for v in vale:
                        ofs.write(str(v).encode("utf8"))
                        ofs.write('\t')
                    ofs.write('\n')
                    for val in Total_data:
                        ofs.write(str(val).encode("utf8"))
                        ofs.write('\t')
                        ofs.write('\n')
            self.send_mail(len(Total_data))
            print ("Email send Successfully : ", str(datetime.now()))

if __name__=="__main__":
    obj = ExtractNonIndexJobs()
    obj.get_non_index_jobs()