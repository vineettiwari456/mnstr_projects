nationality =[
  'Brazil',
  'Sao Tome and Principe',
  'Kuwait',
  'Korea, Republic of',
  'Costa Rica',
  'Bahamas',
  'Heard Island and Mcdonald Islands',
  'Ireland',
  'Maldives',
  'Burkina Faso',
  'Israel',
  'Iceland',
  'Zambia',
  'Cape Verde',
  'Emirati',
  'Cocos (Keeling) Islands',
  'Guatemala',
  'Belgium',
  'Haiti',
  'Eritrea',
  'Netherlands',
  'Greece',
  'British Indian Ocean Territory',
  'Denmark',
  'Cayman Islands',
  'United States',
  'Sweden',
  'Hungary',
  'Switzerland',
  'Honduras',
  'New Zealand',
  'Angola',
  'Chad',
  'Portugal',
  'Bouvet Island',
  'Guam',
  'Mexico',
  'Brunei Darussalam',
  'United Kingdom',
  'Austria',
  'Holy See (Vatican City State)',
  'Timor-Leste',
  "Korea, Democratic People's Republic of",
  'Japan',
  'Macao'
]


import requests

url = "http://10.216.247.147:9200/jobs_index/_search"

payload = "{\r\n  \"query\": {\"match\": {\r\n    \"jobId\": 1397895\r\n  }},\r\n  \"_source\": \"jobId\"\r\n}\r\n"
headers = {
    'content-type': "application/json",
    'cache-control': "no-cache",
    'postman-token': "da6b2e29-070e-8b74-bbdc-44cfaa0cf8da"
    }

response = requests.request("GET", url, data=payload, headers=headers)

print(response.text)