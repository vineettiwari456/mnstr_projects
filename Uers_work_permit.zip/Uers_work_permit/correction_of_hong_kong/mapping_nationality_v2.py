# -*-coding:utf-8 -*-
import os
from decouple import config
import mysql.connector
from datetime import datetime
import sys


class MapHongKongData:
    def __init__(self):
        self.conf_falcon = {"user": str(config("FALCON_USER")).strip(), "password": str(config("FALCON_PASSWORD")).strip(), "host": str(config("FALCON_HOST")).strip(),
                            "database": str(config("FALCON_DB_NAME")).strip()}
        self.conf_rio = {"user": str(config("RIO_USER")), "password": str(config("RIO_PASSWORD")), "host": str(config("RIO_HOST")).strip(),
                         "database": str(config("RIO_DB_NAME")).strip()}
        self.load_data()
        main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Log")
        if not os.path.exists(main_directory):
            os.mkdir(main_directory)
        self.logfilename = main_directory + "/insert_error_log"
        self.logfilename_ids = main_directory + "/insert_sinnationality_user_ids_log"
        self.nationality = {'BD': 'Bangladeshi', 'WF': 'Wallis and Futuna', 'BF': 'Burkina Faso', 'BG': 'Bulgarian',
                            'BA': 'Bosnia and Herzegovina', 'BB': 'Barbados', 'BE': 'Belgium', 'BM': 'Bermuda',
                            'BN': 'Brunei Darussalam',
                            'BO': 'Bolivia', 'BH': 'Bahraini', 'BI': 'Burundi', 'BJ': 'Benin', 'BT': 'Bhutan',
                            'JM': 'Jamaica',
                            'BV': 'Bouvet Island', 'JO': 'Jordanian', 'WS': 'Samoa', 'BR': 'Brazil', 'BS': 'Bahamas',
                            'BY': 'Belarus',
                            'BZ': 'Belize', 'RU': 'Russian', 'RW': 'Rwanda', 'LT': 'Lithuania', 'RE': 'Reunion',
                            'LU': 'Luxembourg',
                            'TJ': 'Tajikistan', 'RO': 'Romania', 'TK': 'Tokelau', 'GW': 'Guinea-Bissau', 'GU': 'Guam',
                            'GT': 'Guatemala',
                            'GS': 'South Georgia and the South Sandwich Islands', 'GR': 'Greece',
                            'GQ': 'Equatorial Guinea',
                            'GP': 'Guadeloupe', 'JP': 'Japan', 'GY': 'Guyana', 'GF': 'French Guiana', 'GE': 'Georgia',
                            'GD': 'Grenada',
                            'GB': 'United Kingdom', 'GA': 'Gabon', 'PK': 'Pakistani', 'GN': 'Guinea', 'GM': 'Gambia',
                            'GL': 'Greenland',
                            'GI': 'Gibraltar', 'GH': 'Ghana', 'OM': 'Omani', 'TN': 'Tunisia', 'BW': 'Botswana',
                            'HR': 'Croatia',
                            'HT': 'Haiti',
                            'HU': 'Hungary', 'HK': 'Hong Kong', 'HN': 'Honduras',
                            'HM': 'Heard Island and Mcdonald Islands',
                            'VE': 'Venezuela',
                            'PR': 'Puerto Rico', 'PS': 'Palestinian Territory, Occupied', 'PW': 'Palau',
                            'PT': 'Portugal',
                            'SJ': 'Svalbard and Jan Mayen', 'PY': 'Paraguay', 'IQ': 'Iraqi', 'PA': 'Panama',
                            'PF': 'French Polynesia',
                            'PG': 'Papua New Guinea', 'PE': 'Peru', 'SO': 'Somalia', 'PH': 'Filipino', 'PN': 'Pitcairn',
                            'PL': 'Poland',
                            'PM': 'Saint Pierre and Miquelon', 'ZM': 'Zambia', 'EH': 'Western Sahara', 'EE': 'Estonia',
                            'EG': 'Egyptian',
                            'ZA': 'South African', 'EC': 'Ecuador', 'AL': 'Albania', 'AO': 'Angola', 'KZ': 'Kazakhstan',
                            'ET': 'Ethiopia',
                            'ZW': 'Zimbabwe', 'KY': 'Cayman Islands', 'ES': 'Spanish', 'ER': 'Eritrea',
                            'MD': 'Moldova, Republic of',
                            'MG': 'Madagascar', 'MA': 'Moroccan', 'MC': 'Monaco', 'UZ': 'Uzbekistan', 'MM': 'Myanmar',
                            'ML': 'Mali',
                            'MO': 'Macao', 'MN': 'Mongolia', 'MH': 'Marshall Islands', 'US': 'United States',
                            'UM': 'United States Minor Outlying Islands', 'MT': 'Malta', 'MW': 'Malawi',
                            'MV': 'Maldives',
                            'MQ': 'Martinique',
                            'MP': 'Northern Mariana Islands', 'MS': 'Montserrat', 'MR': 'Mauritania', 'UG': 'Uganda',
                            'UA': 'Ukraine',
                            'MX': 'Mexico', 'IL': 'Israel', 'FR': 'French', 'IO': 'British Indian Ocean Territory',
                            'AF': 'Afghan',
                            'FI': 'Finland', 'FJ': 'Fiji', 'FK': 'Falkland Islands (Malvinas)',
                            'FM': 'Micronesia, Federated States of',
                            'FO': 'Faroe Islands', 'NI': 'Nicaragua', 'NL': 'Netherlands', 'NO': 'Norway',
                            'NA': 'Namibia',
                            'NC': 'New Caledonia', 'NE': 'Niger', 'NF': 'Norfolk Island', 'NG': 'Nigerian',
                            'NZ': 'New Zealand',
                            'NP': 'Nepalese', 'NR': 'Nauru', 'NU': 'Niue', 'CK': 'Cook Islands', 'CI': "Cote D'Ivoire",
                            'CH': 'Switzerland',
                            'CO': 'Colombia', 'CN': 'Chinese', 'CM': 'Cameroon', 'CL': 'Chile',
                            'CC': 'Cocos (Keeling) Islands',
                            'CA': 'Canadian', 'CG': 'Congo', 'CF': 'Central African Republic',
                            'CD': 'Congo, the Democratic Republic of the',
                            'CZ': 'Czech Republic', 'CY': 'Cyprus', 'CX': 'Christmas Island',
                            'CS': 'Serbia and Montenegro',
                            'CR': 'Costa Rica', 'KP': "Korea, Democratic People's Republic of", 'CV': 'Cape Verde',
                            'CU': 'Cuba',
                            'SZ': 'Swaziland', 'SY': 'Syrian', 'KG': 'Kyrgyzstan', 'KE': 'Kenyan', 'SR': 'Suriname',
                            'KI': 'Kiribati',
                            'KH': 'Cambodia', 'SV': 'El Salvador', 'KM': 'Comoros', 'ST': 'Sao Tome and Principe',
                            'SK': 'Slovakia',
                            'KR': 'Korea, Republic of', 'SI': 'Slovenia', 'SH': 'Saint Helena', 'KW': 'Kuwait',
                            'SN': 'Senegal',
                            'SM': 'San Marino', 'SL': 'Sierra Leone', 'SC': 'Seychelles', 'SB': 'Solomon Islands',
                            'SA': 'Saudi',
                            'SG': 'Singaporean', 'SE': 'Sweden', 'SD': 'Sudanese', 'DO': 'Dominican Republic',
                            'DM': 'Dominica',
                            'DJ': 'Djibouti', 'DK': 'Denmark', 'DE': 'German', 'YE': 'Yemeni', 'AT': 'Austria',
                            'DZ': 'Algerian',
                            'MK': 'Macedonia, the Former Yugoslav Republic of', 'UY': 'Uruguay', 'YT': 'Mayotte',
                            'MU': 'Mauritius',
                            'KN': 'Saint Kitts and Nevis', 'LB': 'Lebanese', 'LC': 'Saint Lucia',
                            'LA': "Lao People's Democratic Republic",
                            'TV': 'Tuvalu', 'TW': 'Taiwanese', 'TT': 'Trinidad and Tobago', 'TR': 'Turkey',
                            'LK': 'Sri Lankan',
                            'LI': 'Liechtenstein', 'LV': 'Latvia', 'TO': 'Tonga', 'TL': 'Timor-Leste',
                            'TM': 'Turkmenistan',
                            'LR': 'Liberia',
                            'LS': 'Lesotho', 'TH': 'Thai', 'TF': 'French Southern Territories', 'TG': 'Togo',
                            'TD': 'Chad',
                            'TC': 'Turks and Caicos Islands', 'LY': 'Libyan Arab Jamahiriya',
                            'VA': 'Holy See (Vatican City State)',
                            'VC': 'Saint Vincent and the Grenadines', 'AE': 'Emirati', 'AD': 'Andorra',
                            'AG': 'Antigua and Barbuda',
                            'VG': 'Virgin Islands, British', 'AI': 'Anguilla', 'VI': 'Virgin Islands, U.s.',
                            'IS': 'Iceland',
                            'IR': 'Iranian',
                            'AM': 'Armenia', 'IT': 'Italian', 'VN': 'Vietnamese', 'AN': 'Netherlands Antilles',
                            'AQ': 'Antarctica',
                            'AS': 'American Samoa', 'AR': 'Argentina', 'AU': 'Australian', 'VU': 'Vanuatu',
                            'AW': 'Aruba',
                            'IN': 'Indian',
                            'TZ': 'Tanzania, United Republic of', 'AZ': 'Azerbaijan', 'IE': 'Ireland',
                            'ID': 'Indonesian',
                            'MY': 'Malaysian',
                            'QA': 'Qatari', 'MZ': 'Mozambique'}

    def get_key_value_format_mapping(self, total_data):
        result = {}
        for da in total_data:
            da_list = da.values()
            result[str(da.get("name")).lower()] = str(da.get("uuid"))
        return result

    def load_data(self):
        conn_master, cursor_master = self.falcon_connection()
        # query_master_nationality = 'select nll.name,nl.uuid from nationalities as nl inner join nationality_langs as nll on nl.id= nll.nationality_id;'
        query_master_nationality = "select country as name,uuid from nationalities;"
        cursor_master.execute(query_master_nationality)
        nationality_raw = cursor_master.fetchall()
        self.job_country_name_master = self.get_key_value_format_mapping(nationality_raw)
        conn_master.close()

    def falcon_connection(self):
        connection_falcon = mysql.connector.connect(user=self.conf_falcon['user'],
                                                    password=self.conf_falcon['password'],
                                                    host=self.conf_falcon['host'],
                                                    database=self.conf_falcon['database'])
        cursor_falcon = connection_falcon.cursor(dictionary=True)
        return connection_falcon, cursor_falcon

    def rio_connection(self):
        connection_rio = mysql.connector.connect(user=self.conf_rio['user'],
                                                 password=self.conf_rio['password'],
                                                 host=self.conf_rio['host'],
                                                 database=self.conf_rio['database'])
        cursor_rio = connection_rio.cursor(dictionary=True)
        return connection_rio, cursor_rio

    def write_log(self, logtext):
        logopenfile = open(self.logfilename, 'a')
        logopenfile.write(str(logtext))
        logopenfile.write("\n")
        logopenfile.close()

    def write_log_ids(self, logtext):
        logopenfile = open(self.logfilename_ids, 'a')
        logopenfile.write(str(logtext))
        logopenfile.write("\n")
        logopenfile.close()

    def update_rio_db(self, records):
        # for rec in records:
        try:
            update_query = """update users set nationality=%s where id=%s;"""
            print (update_query)
            conn, curr = self.rio_connection()
            curr.executemany(update_query, records)
            conn.commit()
            conn.close()
        except Exception as err:
            logtext = "Error in update_rio_db : " + str(err) + str(records)
            self.write_log(logtext)
            pass

    def _fetch_nationality_uuid(self, records):
        totallist = []
        rioids = []
        total_nation_update_records = []
        for rec in records:
            if rec.get("nationality", None):
                nation_text = str(rec.get("nationality", ''))
                nation_list = []
                if "," in nation_text:
                    nation_list = nation_text.split(",")
                elif "\t" in nation_text:
                    nation_list = nation_text.split("\t")
                else:
                    nation_list = nation_text.split()
                nation_list = [na.strip() for na in nation_list if na]
                if len(nation_list) == 1:
                    for nat_text in nation_list:
                        if nat_text:
                            nation_name = self.nationality.get(nat_text.upper())
                            if nation_name:
                                nation_uuid = self.job_country_name_master.get(nation_name.lower(), None)
                                if nation_uuid:
                                    temp=[]
                                    temp.append(nation_uuid)
                                    temp.append(rec.get("id", None))
                                    total_nation_update_records.append(tuple(temp))
                                    rioids.append(rec.get("id", None))
        print ('Updated records length :', len(total_nation_update_records))
        if len(total_nation_update_records) > 0:
            self.update_rio_db(total_nation_update_records)
            insertdata = "Inserted IDS:"+str(rioids)
            self.write_log_ids(insertdata)

    def fetch_from_rio_db(self, query):
        conn, curr = self.rio_connection()
        curr.execute(query)
        records = curr.fetchall()
        conn.close()
        return records

    def chunks(self,lst, n):
        """Yield successive n-sized chunks from lst."""
        for i in range(0, len(lst), n):
            yield lst[i:i + n]

    def rio_data_h_nationality_map(self):
        query = "select id,nationality from users where length(TRIM(nationality))<6 and (TRIM(nationality)!='' and  TRIM(nationality) is not null);"
        rio_records = self.fetch_from_rio_db(query)
        print ("Fetch records:",len(rio_records))
        rio_records = self.chunks(rio_records,1000)
        for rio_record in rio_records:
            print ("Chunk length::", len(rio_record))
            self._fetch_nationality_uuid(rio_record)


if __name__ == "__main__":
    obj = MapHongKongData()
    obj.rio_data_h_nationality_map()
