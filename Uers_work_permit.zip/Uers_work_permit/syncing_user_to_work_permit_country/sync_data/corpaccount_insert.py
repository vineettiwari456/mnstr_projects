import sys
import time
import datetime
import concurrent.futures
reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
import os
import psutil
main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txtfiles")
corpaccount_insertid = main_directory+"/corpaccount_insertid"
fd = open(corpaccount_insertid)
pidval = fd.read()
fd.close()
if pidval:
    if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
        print ('Process is already running------', pidval)
        exit(0)
fd1 = open(corpaccount_insertid,'w')
fd1.write(str(os.getpid()))
fd1.close()

def db1sl_connection():
    conf={"user": "readonly","password": "readonly","host": "10.216.248.117","database": "bazooka"}
    connection = mysql.connector.connect(user=conf['user'], password=conf['password'],
                                                     host=conf['host'],
                                                     database=conf['database'])
    cursor = connection.cursor(dictionary=True, buffered=True)
    return connection,cursor

def eagle_connection():
    conf_eagle = {"user": "migration", "password": "migration007", "host": "10.216.247.110", "database": "eagle"}
    connection_eagle = mysql.connector.connect(user=conf_eagle['user'], password=conf_eagle['password'],
                                         host=conf_eagle['host'],
                                         database=conf_eagle['database'])
    cursor_eagle = connection_eagle.cursor(dictionary=True)
    return connection_eagle,cursor_eagle

def get_corp_id(id_value):
    corpid = None
    if id_value:
        connection_read, cursor_read = eagle_connection()
        query_id = 'select id from corps where kiwi_corp_id=%s;'%(id_value)
        # print query_id
        cursor_read.execute(query_id)
        data = cursor_read.fetchone()
        connection_read.close()
        if data:
            corpid = data.get("id","")
    return corpid

def get_customjd(cutomjd):
    if cutomjd:
        if 'CustomJD' in str(cutomjd):
            return '1'
        else:
            return '0'
    else:
        return '0'

def get_dateunixtimestamp(datatime_data):
    flag_time = False
    if datatime_data:
        # print datatime_data
        # import datetime
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime.datetime(y, m, day, h, mi, sec)
        else:
            d = datetime.datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple()))*1000
        return unixtime
    else:
        return int(time.time()*1000)

def corp_account_insert(accout_id,lastid_corp):
    last_store_id = None
    if accout_id:
        connection,cursor  = db1sl_connection()
        query = \
            "select * from corps_login where id> %s and corp_id<=%s order by id asc;"%(accout_id,lastid_corp)
        print 'Query for corps_login insert : ',query
        cursor.execute(query)
        total_data_main = cursor.fetchall()
        if len(total_data_main)>0:
            last_store_id = total_data_main[-1].get("id", None)
        else:
            last_store_id = accout_id
        i=0
        connection_write,cursor_write  = eagle_connection()
        for row in total_data_main:
            try:
                temp = []
                temp.append(get_corp_id(row["corp_id"]))
                temp.append(row["login"])
                temp.append(row["id"])
                temp.append(row["superuser"])
                temp.append(row["redirect_url_control"])
                temp.append(row["num_saved_search"])
                temp.append(row["daily_mail_limit"])
                temp.append(row["monthly_mail_limit"])
                temp.append(row["total_mail_limit"])
                temp.append(row["resume_attachment_flag"])
                temp.append(row["monster_shortcuts_flag"])
                temp.append(row["alert"])
                temp.append(row["login_type"])
                temp.append('0')
                temp.append(row["enabled"])
                temp.append(row["access"])
                temp.append(get_customjd(row["extra_info"]))
                temp.append(get_dateunixtimestamp(row["createdate"]))
                temp.append(get_dateunixtimestamp(row["info_updated"]))
                temp.append(get_dateunixtimestamp(row["expiredate"]))
                ssourcesql = 'insert into corp_account (corp_id,kiwi_login_id,kiwi_subuid,super_user,redirect_url_control,num_saved_searches,daily_mail_limit,monthly_mail_limit,total_mail_limit,resume_attachment_flag,monster_shortcuts_flag,alert,login_type,deleted,enabled,access,cjt_enabled,created_at,updated_at,expire_date) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
                ssourceval = tuple(temp)
                cursor_write.execute(ssourcesql, ssourceval)
                # break
                connection_write.commit()
                #if i == 20:
                #    connection_write.commit()
                #    i = 0
                    # break
                i += 1
                print 'corps_login insert ID: '+str( row["id"])+" Time : "+str(datetime.datetime.now().strftime("%Y:%m:%d:%H:%M:%S"))
            except Exception as e:
                print 'Error in corp_account insert : ',str(e)
                pass
        #connection_write.commit()
        connection.close()
        connection_write.close()
    return last_store_id

def run_corp_insert():
    last_corpaccountinsert_id = main_directory+"/last_corpaccountinsert_id"
    read_file = open(last_corpaccountinsert_id)
    accountid = read_file.read()
    read_file.close()
    last_corp_id = main_directory+"/last_corp_id"
    read_file_corp = open(last_corp_id)
    lastid_corp = read_file_corp.read()
    read_file_corp.close()
    print 'Corps_insert last id: ',  accountid
    if accountid:
        last_store_id = corp_account_insert(accountid,lastid_corp)
        if last_store_id:
            last_writeid = open(last_corpaccountinsert_id, 'w')
            last_writeid.write(str(last_store_id))
            last_writeid.close()

if __name__ == "__main__":
    run_corp_insert()







