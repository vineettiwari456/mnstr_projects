# -*- coding:utf-8 -*-

import sys
import time
from datetime import datetime,timedelta
import json

reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
import os
from decouple import config
from job_migration_update_validator import jobs_update_fun_script


class BazookaEagleJobValidator:
    def __init__(self):
        
        self.yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        self.conf = {"user": config('DB_BAZOOKA_USER'), "password": config('DB_BAZOOKA_PASS'),
                     "host": config('DB_BAZOOKA_HOST'),
                     "database": config('DB_BAZOOKA')}
        self.conf_eagle = {"user": config('DB_EAGLE_USER'), "password": config('DB_EAGLE_PASS'),
                           "host": config('DB_EAGLE_HOST'),
                           "database": config('DB_EAGLE')}

    def db1sl_connection(self):
        connection = mysql.connector.connect(user=self.conf['user'], password=self.conf['password'],
                                             host=self.conf['host'],
                                             database=self.conf['database'])
        cursor = connection.cursor(dictionary=True, buffered=True)
        return connection, cursor

    def eagle_connection(self):
        connection_eagle = mysql.connector.connect(user=self.conf_eagle['user'], password=self.conf_eagle['password'],
                                                   host=self.conf_eagle['host'],
                                                   database=self.conf_eagle['database'])
        cursor_eagle = connection_eagle.cursor(dictionary=True)
        return connection_eagle, cursor_eagle

    def fetch_query_db1(self, query):
        conn, curr = self.db1sl_connection()
        curr.execute(query)
        records = curr.fetchall()
        conn.close()
        return records

    def fetch_query_eagle(self, query):
        conn, curr = self.eagle_connection()
        curr.execute(query)
        records = curr.fetchall()
        conn.close()
        return records

    def chunks(self, lst, n):
        """Yield successive n-sized chunks from lst."""
        for i in range(0, len(lst), n):
            yield lst[i:i + n]

    def notexistids(self, db1data, eagle):
        idlist = []
        ids = [int(mk.get("jobid")) for mk in eagle]
        for da in db1data:
            if int(da.get("folderid")) not in ids:
                idlist.append(str(da.get("folderid")))
        return idlist

    def map_records(self, db1datas):
        # print db1data
        Mismap_job_ids = []
        chunkdata = self.chunks(db1datas, 10000)
        for db1data in chunkdata:
            folder_ids = [str(m.get("folderid")) for m in db1data]
            if len(folder_ids) > 0:
                folder_ids = ','.join(folder_ids)
                query = "select kiwi_job_id as jobid,from_unixtime(closed_at/1000,'%%Y-%%m-%%d') as closeat,status from jobs where kiwi_job_id in (%s)" % (
                    folder_ids)
                eagle_data = self.fetch_query_eagle(query)
                # print len(eagle_data)
                notexistlist = self.notexistids(db1data, eagle_data)
                Mismap_job_ids.extend(notexistlist)
                for db1_data in db1data:
                    for eag_data in eagle_data:
                        if db1_data.get("folderid") == eag_data.get("jobid"):
                            if (int(db1_data.get("enabled")) != int(eag_data.get("status"))) or (
                                    str(db1_data.get("close", "")) != str(eag_data.get("closeat", ""))):
                                Mismap_job_ids.append(str(db1_data.get("folderid")))
        # print Mismap_job_ids
        return list(set(Mismap_job_ids))

    def process(self):
        print ("Start Date:: ",str(datetime.now()))
        self.eagle_connection()
        for i in range(1, 21):
            #query = "select folderid,date(close) as close,enabled from jobs_%s where date(close)>'2019-01-01'" % (
            #    i)
            st = self.yesterday
            st_time = str(st) + ' 00:00:00'
            end_time = str(st) + ' 23:59:59'
            
            query = "select folderid,date(close) as close,enabled from jobs_%s where updated_sync between '%s' and '%s'" % (
                i,st_time,end_time)
            print query
            records = self.fetch_query_db1(query)
            print len(records)
            jobids = self.map_records(records)
            print "Process of update length", len(jobids)
            if len(jobids) > 0:
                job_ids = ','.join(jobids)
                jobs_update_fun_script(i, job_ids)
            #break


if __name__ == "__main__":
    obj = BazookaEagleJobValidator()
    obj.process()

