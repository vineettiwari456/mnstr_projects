# -*-coding:utf-8 -*-
from xlrd import open_workbook

input_file="C:\\Users\\vktiwari\\Downloads\\Pendingmissing_nationality.xlsx"

nationality = {'BD': 'Bangladeshi', 'WF': 'Wallis and Futuna', 'BF': 'Burkina Faso', 'BG': 'Bulgarian',
                            'BA': 'Bosnia and Herzegovina', 'BB': 'Barbados', 'BE': 'Belgium', 'BM': 'Bermuda',
                            'BN': 'Brunei Darussalam',
                            'BO': 'Bolivia', 'BH': 'Bahraini', 'BI': 'Burundi', 'BJ': 'Benin', 'BT': 'Bhutan',
                            'JM': 'Jamaica',
                            'BV': 'Bouvet Island', 'JO': 'Jordanian', 'WS': 'Samoa', 'BR': 'Brazil', 'BS': 'Bahamas',
                            'BY': 'Belarus',
                            'BZ': 'Belize', 'RU': 'Russian', 'RW': 'Rwanda', 'LT': 'Lithuania', 'RE': 'Reunion',
                            'LU': 'Luxembourg',
                            'TJ': 'Tajikistan', 'RO': 'Romania', 'TK': 'Tokelau', 'GW': 'Guinea-Bissau', 'GU': 'Guam',
                            'GT': 'Guatemala',
                            'GS': 'South Georgia and the South Sandwich Islands', 'GR': 'Greece',
                            'GQ': 'Equatorial Guinea',
                            'GP': 'Guadeloupe', 'JP': 'Japan', 'GY': 'Guyana', 'GF': 'French Guiana', 'GE': 'Georgia',
                            'GD': 'Grenada',
                            'GB': 'United Kingdom', 'GA': 'Gabon', 'PK': 'Pakistani', 'GN': 'Guinea', 'GM': 'Gambia',
                            'GL': 'Greenland',
                            'GI': 'Gibraltar', 'GH': 'Ghana', 'OM': 'Omani', 'TN': 'Tunisia', 'BW': 'Botswana',
                            'HR': 'Croatia',
                            'HT': 'Haiti',
                            'HU': 'Hungary', 'HK': 'Hong Kong', 'HN': 'Honduras',
                            'HM': 'Heard Island and Mcdonald Islands',
                            'VE': 'Venezuela',
                            'PR': 'Puerto Rico', 'PS': 'Palestinian Territory, Occupied', 'PW': 'Palau',
                            'PT': 'Portugal',
                            'SJ': 'Svalbard and Jan Mayen', 'PY': 'Paraguay', 'IQ': 'Iraqi', 'PA': 'Panama',
                            'PF': 'French Polynesia',
                            'PG': 'Papua New Guinea', 'PE': 'Peru', 'SO': 'Somalia', 'PH': 'Filipino', 'PN': 'Pitcairn',
                            'PL': 'Poland',
                            'PM': 'Saint Pierre and Miquelon', 'ZM': 'Zambia', 'EH': 'Western Sahara', 'EE': 'Estonia',
                            'EG': 'Egyptian',
                            'ZA': 'South African', 'EC': 'Ecuador', 'AL': 'Albania', 'AO': 'Angola', 'KZ': 'Kazakhstan',
                            'ET': 'Ethiopia',
                            'ZW': 'Zimbabwe', 'KY': 'Cayman Islands', 'ES': 'Spanish', 'ER': 'Eritrea',
                            'MD': 'Moldova, Republic of',
                            'MG': 'Madagascar', 'MA': 'Moroccan', 'MC': 'Monaco', 'UZ': 'Uzbekistan', 'MM': 'Myanmar',
                            'ML': 'Mali',
                            'MO': 'Macao', 'MN': 'Mongolia', 'MH': 'Marshall Islands', 'US': 'United States',
                            'UM': 'United States Minor Outlying Islands', 'MT': 'Malta', 'MW': 'Malawi',
                            'MV': 'Maldives',
                            'MQ': 'Martinique',
                            'MP': 'Northern Mariana Islands', 'MS': 'Montserrat', 'MR': 'Mauritania', 'UG': 'Uganda',
                            'UA': 'Ukraine',
                            'MX': 'Mexico', 'IL': 'Israel', 'FR': 'French', 'IO': 'British Indian Ocean Territory',
                            'AF': 'Afghan',
                            'FI': 'Finland', 'FJ': 'Fiji', 'FK': 'Falkland Islands (Malvinas)',
                            'FM': 'Micronesia, Federated States of',
                            'FO': 'Faroe Islands', 'NI': 'Nicaragua', 'NL': 'Netherlands', 'NO': 'Norway',
                            'NA': 'Namibia',
                            'NC': 'New Caledonia', 'NE': 'Niger', 'NF': 'Norfolk Island', 'NG': 'Nigerian',
                            'NZ': 'New Zealand',
                            'NP': 'Nepalese', 'NR': 'Nauru', 'NU': 'Niue', 'CK': 'Cook Islands', 'CI': "Cote D'Ivoire",
                            'CH': 'Switzerland',
                            'CO': 'Colombia', 'CN': 'Chinese', 'CM': 'Cameroon', 'CL': 'Chile',
                            'CC': 'Cocos (Keeling) Islands',
                            'CA': 'Canadian', 'CG': 'Congo', 'CF': 'Central African Republic',
                            'CD': 'Congo, the Democratic Republic of the',
                            'CZ': 'Czech Republic', 'CY': 'Cyprus', 'CX': 'Christmas Island',
                            'CS': 'Serbia and Montenegro',
                            'CR': 'Costa Rica', 'KP': "Korea, Democratic People's Republic of", 'CV': 'Cape Verde',
                            'CU': 'Cuba',
                            'SZ': 'Swaziland', 'SY': 'Syrian', 'KG': 'Kyrgyzstan', 'KE': 'Kenyan', 'SR': 'Suriname',
                            'KI': 'Kiribati',
                            'KH': 'Cambodia', 'SV': 'El Salvador', 'KM': 'Comoros', 'ST': 'Sao Tome and Principe',
                            'SK': 'Slovakia',
                            'KR': 'Korea, Republic of', 'SI': 'Slovenia', 'SH': 'Saint Helena', 'KW': 'Kuwait',
                            'SN': 'Senegal',
                            'SM': 'San Marino', 'SL': 'Sierra Leone', 'SC': 'Seychelles', 'SB': 'Solomon Islands',
                            'SA': 'Saudi',
                            'SG': 'Singaporean', 'SE': 'Sweden', 'SD': 'Sudanese', 'DO': 'Dominican Republic',
                            'DM': 'Dominica',
                            'DJ': 'Djibouti', 'DK': 'Denmark', 'DE': 'German', 'YE': 'Yemeni', 'AT': 'Austria',
                            'DZ': 'Algerian',
                            'MK': 'Macedonia, the Former Yugoslav Republic of', 'UY': 'Uruguay', 'YT': 'Mayotte',
                            'MU': 'Mauritius',
                            'KN': 'Saint Kitts and Nevis', 'LB': 'Lebanese', 'LC': 'Saint Lucia',
                            'LA': "Lao People's Democratic Republic",
                            'TV': 'Tuvalu', 'TW': 'Taiwanese', 'TT': 'Trinidad and Tobago', 'TR': 'Turkey',
                            'LK': 'Sri Lankan',
                            'LI': 'Liechtenstein', 'LV': 'Latvia', 'TO': 'Tonga', 'TL': 'Timor-Leste',
                            'TM': 'Turkmenistan',
                            'LR': 'Liberia',
                            'LS': 'Lesotho', 'TH': 'Thai', 'TF': 'French Southern Territories', 'TG': 'Togo',
                            'TD': 'Chad',
                            'TC': 'Turks and Caicos Islands', 'LY': 'Libyan Arab Jamahiriya',
                            'VA': 'Holy See (Vatican City State)',
                            'VC': 'Saint Vincent and the Grenadines', 'AE': 'Emirati', 'AD': 'Andorra',
                            'AG': 'Antigua and Barbuda',
                            'VG': 'Virgin Islands, British', 'AI': 'Anguilla', 'VI': 'Virgin Islands, U.s.',
                            'IS': 'Iceland',
                            'IR': 'Iranian',
                            'AM': 'Armenia', 'IT': 'Italian', 'VN': 'Vietnamese', 'AN': 'Netherlands Antilles',
                            'AQ': 'Antarctica',
                            'AS': 'American Samoa', 'AR': 'Argentina', 'AU': 'Australian', 'VU': 'Vanuatu',
                            'AW': 'Aruba',
                            'IN': 'Indian',
                            'TZ': 'Tanzania, United Republic of', 'AZ': 'Azerbaijan', 'IE': 'Ireland',
                            'ID': 'Indonesian',
                            'MY': 'Malaysian',
                            'QA': 'Qatari', 'MZ': 'Mozambique'}
book = open_workbook(input_file)
sheet = book.sheet_by_index(0)
keys = [sheet.cell(0, col_index).value for col_index in xrange(sheet.ncols)]
Data=[]
for row_index in xrange(1, sheet.nrows):
    rec = {keys[col_index]: sheet.cell(row_index, col_index).value
         for col_index in xrange(sheet.ncols)}
    if rec.get("nationality",None):
        try:
            nation_text = str(rec.get("nationality", ''))
            nation_list = []
            if "," in nation_text:
                nation_list = nation_text.split(",")
            # elif "\t" in nation_text:
                # nation_list = nation_text.split("\t")
            elif "\\t" in nation_text:
                nation_list = nation_text.split("\\t")
            else:
                nation_list = nation_text.split()
            nation_list = [na.strip() for na in nation_list if na]
            # print nation_text,nation_list
            if len(nation_list)>0:
                temp = []
                for nat_text in nation_list:
                    print nat_text
                    if nat_text:
                        nation_name = nationality.get(nat_text.upper())
                        if nation_name:
                            temp.append(nation_name)
                            # rec.update({"name":nation_name})
                            # Data.append(rec)
                rec.update({"name": ' | '.join(temp)})
                Data.append(rec)
        except Exception as e:
            print "Error",rec.get("nationality", '')
print Data

import xlsxwriter
def save_xlsx_file(total_records, headers):
    total_records.insert(0, headers)
    workbook = xlsxwriter.Workbook("pendingmissing_nationality.xlsx")
    worksheet = workbook.add_worksheet("nationality_with_name")
    row = 0
    # Iterate over the data and write it out row by row.
    for name in (total_records):
        for m, k in enumerate(name):
            worksheet.write(row, m, k)
        row += 1
    workbook.close()
Total_records = []
headers_main=["nationality","name","count"]
for dict in Data:
    temp = []
    for value_data in headers_main:
        temp.append(dict.get(value_data, ""))
    Total_records.append(temp)
if len(Total_records) > 0:
    save_xlsx_file(Total_records,headers_main)








