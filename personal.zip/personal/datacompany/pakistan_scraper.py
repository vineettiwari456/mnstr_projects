# -*-coding:utf-8 -*-

import sys
import requests
import re
import copy
import operator, pymongo
from bs4 import BeautifulSoup
import json, time, uuid
from datetime import datetime, timedelta
reload(sys)
sys.setdefaultencoding("utf-8")
import urllib3
from urlparse import urljoin
import concurrent.futures
#urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from pymongo import MongoClient
client = MongoClient("localhost", 27017)
db = client.JobData
coll = db.Pakistan_jobs
coll_demo = db.Pakistan_jobs_demo

class PakistanScraper:
    
    def __init__(self):
        self.date_field = datetime.now().strftime("%d/%m/%Y")
        self.headers = {
                    'User-Agent':
                    'Mozilla/5.0 (Windows NT 10.0; WOW64)\
                    AppleWebKit/537.36 (KHTML'}
        
    def scrape_job_value(self,jb_url, posted_date):
        #jb_url="https://www.rozee.pk/soft-pyramid-mysql-expert-level-programmerarchitect-lahore-jobs-791424.php?utm_source=jobSearch&utm_medium=website&utm_content=jobSearch_791424&utm_campaign=ROZEE.PK_JOB_SEARCH&utm_term=ROZEE.PK_JOB_SEARCH"
        cc = 0
        while cc < 50:
            cc += 1
            try:
                session = requests.session()
                # session.proxies = proxi_get()
                resp = session.get(str(jb_url), verify=True, headers=self.headers, timeout=40, stream=True)
                if resp.status_code == 200:
                    break
            except Exception as e:
                time.sleep(5)
                pass
 
        if resp.status_code == 200:
            sp = BeautifulSoup(str(resp.text), 'html.parser')
            raw_title = sp.find("h1", {"itemprop":"title"})
            position_title =""
            company_name = ""
            location= ""
            salary = ""
            if raw_title:
                position_title = raw_title.text.strip()
            raw_company = sp.find("h2", {"itemprop":"hiringOrganization"})
            if raw_company:
                company_name = raw_company.text.strip()
            raw_location = sp.find("h4", {"class":" rz-pre cname nrs-18"})
            if raw_location:
                location = ' '.join(raw_location.text.split())
            raw_salary = sp.find("div", {"class":"mrsl mt15 ofa nrs-18 hidden-xs"})
            if raw_salary:
                salary = ''.join(raw_salary.text.split())
            about_company = ""
            rw_abou = sp.find("div", {"class":"text-muted mt10"})
            if rw_abou:
                about_company += ' '.join(rw_abou.text.split())
            rw_abo = sp.find("div", {"class":"mt10 nrs-14"})
            if rw_abo:
                ab = ' '.join(rw_abo.text.split())
                if "." in ab:
                    about_company = about_company+" "+' '.join(ab.split(". ")[:-1])+"."
            #print salary,location, company_name, position_title
            #print about_company
            role_and_responsibilities = ""
            requirements = ""
            experience_required = ""
            rw_ro_resp = sp.find("div", {"itemprop":"description"})
            if rw_ro_resp:
                role_and_responsibilities = ' '.join(rw_ro_resp.text.split())
                
            rwrexper = sp.find("div", {"itemprop":"experienceRequirements"})
            if rwrexper:
                experience_required = ' '.join(rwrexper.text.split())
            requir = sp.find("div", {"itemprop":"skills"})
            if requir:
                val_re = requir.find_all("a",{"class":"label label-default pull-left mr10 nrs-14"})
                if len(val_re)>0:
                    gfs= ' '.join([k.text.strip() for k in val_re])
                    if gfs.startswith("and"):
                        gfs = gfs[4:]
                    requirements += gfs
            rw_ro_req = sp.find("div", {"class":"jcnt jobd"})
            if rw_ro_req:
                requirements = requirements+" "+' '.join(rw_ro_req.text.split())
            #print requirements
            dic = {}
            dic["position_title"] = position_title
            dic["company_name"] = company_name
            dic["about_company"] = about_company
            dic["location"] = location
            dic["requirements"] = requirements
            dic["role_and_responsibilities"] = role_and_responsibilities
            dic["experience_required"] = experience_required
            dic["job_url"] = jb_url
            dic["salary"] = salary
            dic["crawled_date"] = self.date_field
            dic["job_posted_date"] = posted_date
            #print dic
            if position_title !="":
                return dic
            else:
                #print url_link
                return None
        
        
        
    def get_urls(self, url_fun_list, dys):
        All_urls = []
        f = open('Pakistan_urls_rozee.txt','rb')
        All_urls = eval(f.read())
        f.close()
        print len(All_urls)
        Total_data = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=40) as executor:
            future_to_url = {executor.submit(self.scrape_job_value, url_jb[0], url_jb[1]): url_jb for url_jb in
                             All_urls}
            for future in concurrent.futures.as_completed(future_to_url):
                url2 = future_to_url[future]
                try:
                    data = future.result()
                    if data:
                        Total_data.append(data)
                        coll.insert(data)
                except Exception as exc:
                    print '=====>', url2, exc
                    pass
        return Total_data
#         for url in url_fun_list[:]:
#             url_temp = url
#             i=1
#             pagination_val = True
#             while pagination_val:
#                 print url_temp
#                 cc = 0
#                 while cc < 50:
#                     cc += 1
#                     try:
#                         session = requests.session()
#                         # session.proxies = proxi_get()
#                         resp = session.get(str(url_temp), verify=True, headers=self.headers, timeout=40, stream=True)
#                         if resp.status_code == 200:
#                             break
#                     except Exception as e:
#                         time.sleep(5)
#                         pass
#         
#                 if resp.status_code == 200:
#                     soup = BeautifulSoup(str(resp.text), 'html.parser')
#                     raw_job_div = soup.find_all("div", {"itemtype":"http://schema.org/JobPosting"})
#                     if len(raw_job_div)>0:
#                         for df in raw_job_div:
#                             temp = []
#                             val_f = df.find("span", {"itemprop":"datePosted"})
#                             if val_f:
#                                 val = val_f.text.strip() 
#                                 from dateutil import parser
#                                 datetime_object = parser.parse(val)
#                                 a= datetime.date(datetime_object)
#                                 b = datetime.date(datetime.now())
#                                 diff = b-a
#                                 date_range = diff.days
#                                 #print date_range
#                                 if date_range<=dys:
#                                     post = datetime_object.strftime("%d/%m/%Y")
#                                     raw_url =df.find("a",{"itemprop":"url"})
#                                     if raw_url:
#                                         urld = urljoin("https:",raw_url.get("href"))
#                                         temp.append(urld)
#                                         temp.append(post)
#                                         All_urls.append(temp)
#                                 else:
#                                     pagination_val = False
#                     raw_page = soup.find("div", {"class":"jbody"})
#                     if raw_page:
#                         false_text= raw_page.text.strip()
#                         if "is sought by  with  experience" in false_text:
#                             pagination_val = False
#                         else:
#                             url_temp = url+"/?fpn="+str(i*20)
#                             i=i+1
#             
#         print 'All_urls',len(All_urls),
#         All_urls = [list(item) for item in set(tuple(row) for row in All_urls)]
#         print 'All_urls1',len(All_urls)
#         f = open('Pakistan_urls_rozee.txt','wb')
#         f.write(str(All_urls))
#         f.close()
    def crawl(self, url_link, days):
        cc = 0
        while cc < 50:
            cc += 1
            try:
                session = requests.session()
                # session.proxies = proxi_get()
                res = session.get(str(url_link), verify=True, headers=self.headers, timeout=40, stream=True)
                if res.status_code == 200:
                    break
            except Exception as e:
                time.sleep(5)
                pass

        if res.status_code == 200:
            sou = BeautifulSoup(str(res.text), 'html.parser')
            raw_funct = sou.find("div", {"id":"byFunction"})
            if raw_funct:
                raw_li_func = raw_funct.find_all("a")
                all_url_func =[]
                if len(raw_li_func)>0:
                    all_url_func.extend([urljoin("https:", j.get("href")) for j in raw_li_func[:-1] if j])
                #print all_url_func
                return self.get_urls(all_url_func, days)
                                
if __name__=="__main__":
    obj = PakistanScraper()
    all_da = obj.crawl("https://www.rozee.pk/",28)
    coll_demo.insert(all_da)
    
        
        
        