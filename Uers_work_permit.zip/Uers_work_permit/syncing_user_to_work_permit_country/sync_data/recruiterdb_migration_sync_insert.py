# -*-coding:utf-8 -*-
import sys
import time
import datetime
reload(sys)
sys.setdefaultencoding("utf-8")
from base64 import b64decode
import mysql.connector
from mysql.connector import pooling
import concurrent.futures
import sched,time
import os
import psutil
from dateutil.parser import parse
from recruiterdb_migration_sync_update import set_scheduler_function_update
from corpaccount_insert import run_corp_insert
from corpaccount_update import run_corpaccount_update
from  recruiteruser_role_insert import run_recruiter_role_insert_script
from  recruiteruser_role_update import run_recruiter_role_update_script
from job_migration_insert import jobs_insert_fun
from job_migration_update import jobs_update_fun_script

main_directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txtfiles")
savepid_insert = main_directory+"/savepid_insert"
fd = open(savepid_insert)
pidval = fd.read()
fd.close()
if pidval:
    if int(pidval) in [p.info["pid"] for p in psutil.process_iter(attrs=['pid'])]:
        print '------', pidval
        exit(0)
fd1 = open(savepid_insert,'w')
fd1.write(str(os.getpid()))
fd1.close()
s = sched.scheduler(time.time, time.sleep)


def db1sl_connection():
    conf={"user": "readonly","password": "readonly","host": "10.216.248.117","database": "bazooka"}
    connection = mysql.connector.connect(user=conf['user'], password=conf['password'],
                                                     host=conf['host'],
                                                     database=conf['database'])
    cursor = connection.cursor(dictionary=True,buffered=True)
    return connection,cursor

def eagle_connection():
    conf_eagle = {"user": "migration", "password": "migration007", "host": "10.216.247.110", "database": "eagle"}
    connection_eagle = mysql.connector.connect(user=conf_eagle['user'], password=conf_eagle['password'],
                                         host=conf_eagle['host'],
                                         database=conf_eagle['database'])
    cursor_eagle = connection_eagle.cursor(dictionary=True)
    return connection_eagle,cursor_eagle

def get_industry_uuid(ind_id):
    ind_val=None
    if ind_id>0:
        connection_object, curs = db1sl_connection()
        query = "select name from industry where id=%s;"%(ind_id)
        # print query
        curs.execute(query)
        value_data = curs.fetchone()
        connection_object.close()
        if value_data:
           ind_name = value_data.get("name","")
           #connection_object.close()
           connection_obj_eag, cursor_read = eagle_connection()
           query1 = "select uuid from industries where id in (select industry_id from industry_langs where name ='%s');"%(ind_name)
           # print query1
           cursor_read.execute(query1)
           data = cursor_read.fetchone()
           if data:
               ind_val = data.get("uuid","")
           connection_obj_eag.close()
    return ind_val

def get_country_uuid(iso_code):
    iso_value = None
    if iso_code:
        connection_object, cursor_read = eagle_connection()
        query1 = "select uuid from countries where iso_code ='%s';" % (
            iso_code)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            iso_value= data.get("uuid", "")
        connection_object.close()
    return iso_value
# print get_country_uuid('IN')
def get_service_channel_id(service_name):
    service_id = None
    if service_name:
        connection_object, cursor_read = eagle_connection()
        query1 = "select id from service_channels where name ='%s';" % (
            service_name)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            service_id= data.get("id", "")
        connection_object.close()
    return service_id

def get_city_uuid(city_name, id):
    cityuuid = None
    if city_name:
        connection_object, cursor_read = eagle_connection()
        query1 = "select uuid from job_locations where id in (select job_location_id from job_location_langs where name ='%s');" % (
            city_name)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            cityuuid =  data.get("uuid", "")
        connection_object.close()
    return cityuuid
# print '=============', get_city_uuid("Kolkata")
def get_extra_info_value(info_data):
    aor_exp_date = None
    cjt_exp_date =None
    rec_social_profile =None
    orig_service_channel_id=None
    customize_type=None
    company_list=None
    if info_data:
        try:
            extra_value = info_data.replace("~", '')
            extra_info_list = extra_value.split(":")
            for value in extra_info_list:
                if 'AOR_EXP_DATE' in value:
                    aor_exp_date  = value.split("=")[-1].strip()
                if 'CJT_EXP_DATE' in value:
                    cjt_exp_date  = value.split("=")[-1].strip()
                if 'REC_SOCIAL_PROFILE' in value:
                    rec_social_profile  = value.split("=")[-1].strip()
                if 'ORIG_SERVICE_CHANNEL' in value:
                    orig_service_channel_id = get_service_channel_id(value.split("=")[-1].strip())
                if 'CUSTOMIZE_TYPE' in value:
                    customize_type  = value.split("=")[-1].strip()
                if 'COMPANY_LIST' in value:
                    company_list  = value.split("=")[-1].strip()
        except Exception as exc:
            print 'get_extra_info_value', exc
            pass
    return aor_exp_date, cjt_exp_date,rec_social_profile,orig_service_channel_id,customize_type,company_list

def get_dateunixtimestamp(datatime_data):
    flag_time = False
    if datatime_data:
        # print datatime_data
        # import datetime
        if ' ' in str(datatime_data):
            flag_time = True
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
            h, mi, sec = map(int, str(datatime_data).split()[-1].split(':'))
        else:
            y, m, day = map(int, str(datatime_data).split()[0].split('-'))
        if flag_time:
            d = datetime.datetime(y, m, day, h, mi, sec)
        else:
            d = datetime.datetime(y, m, day).date()
        unixtime = int(time.mktime(d.timetuple()))*1000
        return unixtime
    else:
        return int(time.time()*1000)

def get_logo_url(logocode, xcode):
    if logocode:
        if 'JDLOGO' in logocode:
            if xcode:
                return "https://media.monsterindia.com/logos/"+str(xcode).strip()+"/jdlogo.gif"
            else:
                return None
        else:
            return None
    else:
        return None
def get_corp_profile(corpid):
    profile_text = None
    if corpid:
        connection_object, cursor_read = db1sl_connection()
        query1 = "select profile from corps_profile where corp_id =%s;" % (
            corpid)
        # print query1
        cursor_read.execute(query1)
        data = cursor_read.fetchone()
        if data:
            profile_text = data.get("profile", None)
        connection_object.close()
    return profile_text

def get_site_context(subchannelid):
    site = {1: "rexmonster", 2: "monstergulf", 6: "monstersingapore", 8: "monsterthailand",
            7: "monsterphilippines", 9: "monstervietnam", 11: "monstermalaysia", 10: "monsterindonesia",
            5: "monsterhongkong"}
    site_context = None
    try:
        if subchannelid:
            site_context = site.get(subchannelid)
    except:
        pass
    return site_context

def get_corp_profile_url_insert(corps_id, kiwicordid):
    total_profile1 = []
    if kiwicordid:
        connection_object, cursor_read = db1sl_connection()
        query = "select * from corps_brandings where type = 'CP' and corp_id='%s';" % (
            kiwicordid)
        cursor_read.execute(query)
        datalist = cursor_read.fetchall()
        for data in datalist:
            if data:
                if data.get("extra_info",None):
                    if data.get("extra_info",None).split(":")[-1]:
                        total_profile = []
                        total_profile.append(corps_id)
                        total_profile.append(data.get("enabled",None))
                        total_profile.append(data.get("extra_info",None).split(":")[-1])
                        total_profile.append(get_dateunixtimestamp(data.get("created", None)))
                        total_profile.append(get_dateunixtimestamp(data.get("updated", None)))
                        total_profile.append(get_dateunixtimestamp(data.get("expiry", None)))
                        total_profile.append(data.get("channel_id",None))
                        total_profile.append(get_site_context(data.get("subchannel_id", None)))
                        total_profile1.append(tuple(total_profile))
        connection_object.close()
    return total_profile1

def fetch_data(lastid):
    total_data_main = []
    last_store_id = None
    connection_object, cursor = db1sl_connection()
    query = "select * from corps where id>%s order by id asc;"%(lastid)
    # print query
    cursor.execute(query)
    total_data_main = cursor.fetchall()
    if len(total_data_main)>0:
        last_store_id = total_data_main[-1].get("id", None)
    else:
        last_store_id = lastid
    connection_object.close()
    return total_data_main, last_store_id

def get_pcp_value(valuedata):
    val1 = None
    val2 = None
    if valuedata:
        naame = valuedata.split()
        if len(naame) > 1:
            val1 = naame[0]
            val2 = ' '.join(naame[1:])
    return val1, val2

def get_evaluated_temp_corps_record(row):
    value_none = None
    temp = []
    temp.append(row["xcode"])
    temp.append(row["name"])
    temp.append(row["short_name"])
    temp.append(row["phone"])
    temp.append(row["address"])
    temp.append(row["url"])
    temp.append(row["email"])
    temp.append(str(row["loginexpires"]))
    temp.append(row["maxagent"])
    temp.append(row["enabled"])
    temp.append(get_industry_uuid(row["industry"]))
    if row["pcp_name"]:
        naame = row["pcp_name"].split()
        if len(naame) > 1:
            temp.append(naame[0])
            temp.append(' '.join(naame[1:]))
        else:
            temp.append(row["pcp_name"])
            temp.append(value_none)
    else:
        temp.append(value_none)
        temp.append(value_none)
    # temp.append(row["pcp_name"])
    if row["package_purchased"]:
        temp.append(row["package_purchased"])
    else:
        temp.append(value_none)
    if row["company_type"]:
        temp.append(row["company_type"])
    else:
        temp.append(value_none)
    temp.append(row["redirect_url"])
    temp.append(get_logo_url(row["logos"], row["xcode"]))
    temp.append(get_city_uuid(row["city"], row["id"]))
    temp.append(row["city"])
    temp.append(get_country_uuid(row["country"]))
    temp.append(row["mail_report"])
    temp.append(row["company_website"])
    temp.append(row["customize"])
    if row["service_type"]:
        temp.append(row["service_type"])
    else:
        temp.append(value_none)
    temp.append(get_service_channel_id(row["service_channel"]))
    temp.append(row["redirect_url_control"])
    temp.append(row["can_edit_compname"])
    temp.append(row["keep_confidential"])
    temp.append(row["ip_restriction"])
    aor_exp_date, cjt_exp_date, rec_social_profile, orig_service_channel_id, customize_type, company_list = get_extra_info_value(
        row["extra_info"])
    temp.append(aor_exp_date)
    temp.append(cjt_exp_date)
    temp.append(rec_social_profile)
    temp.append(orig_service_channel_id)
    temp.append(customize_type)
    temp.append(company_list)
    temp.append(row["xcode"])
    temp.append(row["id"])
    temp.append(get_corp_profile(row["id"]))
    temp.append(get_dateunixtimestamp(row["currdt"]))
    temp.append(int(time.time() * 1000))
    temp.append(value_none)
    return temp

def get_extra_info_cjt_value(info_data):
    cjt_exp_date =None
    if info_data:
        try:
            extra_value = info_data.replace("~", '')
            extra_info_list = extra_value.split(":")
            for value in extra_info_list:
                if 'CJT_EXP_DATE' in value:
                    cjt_exp  = value.split("=")[-1].strip()
                    parse(str(cjt_exp))
                    cjt_exp_date  = value.split("=")[-1].strip()
        except Exception as exc:
            print 'get_extra_info_value', exc
            pass
    return cjt_exp_date

def get_corps_service_record(new_corp_id,row):
    temp = []
    if new_corp_id:
        is_microsite='0'
        is_cjt = '0'
        if row["customize"]=='1':
            is_microsite='1'
        if row["customize"]=='2':
            is_cjt='1'
        if row["customize"]=='3':
            is_cjt='1'
            is_microsite = '1'
        temp.append(new_corp_id)
        temp.append(is_microsite)
        temp.append(is_cjt)
        cjt_exp_date = get_extra_info_cjt_value(
            row["extra_info"])
        temp.append(cjt_exp_date)
        temp.append(get_dateunixtimestamp(row["currdt"]))
        temp.append(int(time.time() * 1000))

    return temp

def migrate(all_data):
    i=0
    connection_object, cursor_write = eagle_connection()
    for rows in all_data:
        try:
            temp = get_evaluated_temp_corps_record(rows)
            ssourcesql = 'insert into corps (corp_id,name,short_name,phone,address,apply_url,email,login_expire_at,max_login_account,enabled,industry_uuid,owner_first_name,owner_last_name,package_purchased,company_type,redirect_url,logo_url,city_uuid,city_text,country_uuid,mail_report,company_website,customize,service_type,service_channel_id,redirect_url_control,can_edit_company_name,keep_confidential,ip_restriction,aor_exp_date,cjt_exp_date,rec_social_profile,orig_service_channel_id,customize_type,company_list,kiwi_xcode,kiwi_corp_id,profile,created_at,updated_at,created_by_uuid) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
            ssourceval = tuple(temp)
            cursor_write.execute(ssourcesql,ssourceval)
            cursor_write.execute("select LAST_INSERT_ID() as id")
            corp_id = cursor_write.fetchone()['id']
            get_corp_profile_url_records = get_corp_profile_url_insert(corp_id,rows["id"])
            # print get_corp_profile_url_records
            if len(get_corp_profile_url_records)>0:
                ssourcesql = 'insert into corp_profile_url (corp_id,enabled,profile_url,created_at,updated_at,expires_at,channel_id,site_context) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)'
                ssourceval = get_corp_profile_url_records
                cursor_write.executemany(ssourcesql, ssourceval)
            temp_service = get_corps_service_record(corp_id,rows)
            if len(temp_service)>0:
                ssourcesql1 = 'insert into corp_service (corp_id,is_microsite,is_cjt,cjt_expiry_date,created_at,updated_at) VALUES (%s,%s,%s,%s,%s,%s)'
                ssourceval1 = tuple(temp_service)
                # print ssourceval
                cursor_write.execute(ssourcesql1,ssourceval1)
            if i==10:
                connection_object.commit()
                i=0
            i+=1 
            print "Insert Corps Id : "+str(rows["id"])+" Time : "+str(datetime.datetime.now().strftime("%Y:%m:%d:%H:%M:%S"))
        except Exception as e:
            print 'Error in corps insert : ',str(e)
            pass
    connection_object.commit()
    connection_object.close()

def set_scheduler_function():
    last_corp_id = main_directory+"/last_corp_id"
    read_file = open(last_corp_id)
    lastid = read_file.read()
    read_file.close()
    print lastid.strip()
    if lastid:
        total_data_main, last_store_id = fetch_data(lastid)
        print 'Total new corps account : ',len(total_data_main)
        migrate(total_data_main)
        #print '000000000000',len(total_data_main)
        last_writeid = open(last_corp_id, 'w')
        last_writeid.write(str(last_store_id))
        last_writeid.close()
    # s.enter(1, 1, set_scheduler_function, (sc,))



if __name__ == "__main__":
    set_scheduler_function()
    #time.sleep(5)
    set_scheduler_function_update()
    #time.sleep(5)
    run_corp_insert()
    time.sleep(5)
    run_corpaccount_update()
    time.sleep(10)
    run_recruiter_role_insert_script()
    time.sleep(5)
    run_recruiter_role_update_script()
    time.sleep(5)
    jobs_insert_fun()
    #time.sleep(5)
    jobs_update_fun_script()



