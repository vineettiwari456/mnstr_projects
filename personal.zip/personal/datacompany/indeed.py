# -*-coding:utf-8 -*-

import sys
import requests
import re
import copy
import operator, pymongo
from bs4 import BeautifulSoup
import json, time, uuid
from datetime import datetime, timedelta
reload(sys)
sys.setdefaultencoding("utf-8")
import urllib3
from urlparse import urljoin
import concurrent.futures
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)


class Indeed:
    def __init__(self):

        self.date_field = datetime.now().strftime("%d/%m/%Y")
        self.headers = {
                'User-Agent':
                'Mozilla/5.0 (Windows NT 10.0; WOW64)\
                AppleWebKit/537.36 (KHTML'}
        

    def scrape_job_value(self, url_link, posted_dat):
        cc = 0
        while cc < 50:
            cc += 1
            try:
                session = requests.session()
                # session.proxies = proxi_get()
                res = session.get(str(url_link), verify=False, headers=self.headers, timeout=40, stream=True)
                if res.status_code == 200:
                    break
            except Exception as e:
                time.sleep(5)
                pass

        if res.status_code == 200:
            sou = BeautifulSoup(str(res.text), 'html.parser')
            job_title = ""
            company_name = ""
            experience_required = ""
            job_location = ""
            edu_requirement = ""
            about_company = ""
            salary = "Not Found"
            job_type = ""
            raw_job_title = sou.find('b', {'class' : 'jobtitle'})
            if raw_job_title:
                job_title = raw_job_title.text.strip()
            raw_job_location = sou.find('span', {'class' : 'location'})
            if raw_job_location:
                job_location = raw_job_location.text.strip()
            raw_job_description = sou.find('span', {'id' : 'job_summary'})
            requirements = ""
            role_and_responsibilities = ""
            if raw_job_description:
                text = ""
                raw_div = raw_job_description.find_all("p")
                if len(raw_div)==0:
                    raw_div = raw_job_description.find_all("b")
                #print len(raw_div)
                if len(raw_div)>0:
                    raw_requirement = [j for j in raw_div if j if 'Requirement' in j.text if (len(j.text)>12 and len(j.text)<40)]
                    #print raw_requirement
                    if len(raw_requirement)>0:
                        text = ' '.join(raw_requirement[0].text.split())
                        try:
                            requirements = ' '.join(raw_requirement[0].next_sibling.text.split())
                        except:
                            requirements = ' '.join(raw_requirement[0].findNext("ul").text.split())
                            pass
                        if requirements=="":
                            try:
                                requirements = ' '.join(raw_requirement[0].next_sibling.next_sibling.text.split())
                            except:
                                #requirements = ' '.join(raw_requirement[0].next_sibling.next_sibling.text.split())
                                pass
                    else:
                        requirements = ' '.join(raw_job_description.text.split()).encode("utf8")
            
                else:
                    requirements = ' '.join(raw_job_description.text.split()).encode("utf8")
                
                role_and_responsibilities = ' '.join(raw_job_description.text.split()).encode("utf8")
                if role_and_responsibilities == requirements:
                    role_and_responsibilities = role_and_responsibilities
                else:
                    role_and_responsibilities = role_and_responsibilities.replace(requirements,'')
                    if text !="":
                        role_and_responsibilities = role_and_responsibilities.replace(text,'')
                
                #job_description = raw_job_description.text.strip()
            raw_company_name = sou.find('span', {'class' : 'company'})
            if raw_company_name:
                company_name = raw_company_name.text.strip()
            raw_about_cmp = sou.find("div", {"class":"cmp_description"})
            if raw_about_cmp:
                about_company = raw_about_cmp.text
            raw_salary = sou.find("span", {"class":"no-wrap"})
            if raw_salary:
                salary = raw_salary.text.strip().encode("utf8")
            dic = {}
            dic["job_url"] = url_link
            dic["position_title"] = job_title
            dic["company_name"] = company_name
            dic["location"] = job_location
            dic["about_company"] = ' '.join(about_company.split())
            dic["salary"] = salary
            dic["job_posted_date"] = posted_dat
            dic["crawled_date"] = self.date_field
            dic["role_and_responsibilities"] = role_and_responsibilities
            dic["requirements"] = requirements
            
            if job_title != "":
                return dic
            else:
                return None

    def crawl(self, url_list, days, base_url):
        h_url = base_url
        All_urls = []
        for url in url_list:
            url_temp = url
            pagination_val = True
            while pagination_val:
                print url_temp
                cc = 0
                while cc < 50:
                    cc += 1
                    try:
                        session = requests.session()
                        # session.proxies = proxi_get()
                        resp = session.get(str(url_temp), verify=False, headers=self.headers, timeout=40, stream=True)
                        if resp.status_code == 200 or resp.status_code == 404:
                            break
                    except Exception as e:
                        time.sleep(5)
                        pass

                if resp.status_code == 200:
                    sou_value = str(resp.text)
                    soup = BeautifulSoup(sou_value, 'html.parser')
                    raw_result = soup.find("td", {"id":"resultsCol"})
                    if raw_result:
                        raw_job_links = raw_result.find_all('div',{'data-tn-component':'organicJob'})
                        if raw_job_links:
                            for raw_job in raw_job_links:
                                raw_posted_dates = soup.find('span', {'class': 'date'})
                                # print raw_posted_dates
                                if raw_posted_dates:
                                    date_text = raw_posted_dates.text.strip()

                                    date_range = 0
                                    if 'day ' in date_text.lower() or 'days ' in date_text.lower():
                                        date_range = int(date_text.split()[0].strip())
                                        
                                    if 'today' in date_text.lower() or 'just' in date_text.lower() or "hour" in date_text.lower() or date_range <= days:
                                        yesterday = datetime.now() - timedelta(days=date_range)
                                        post = yesterday.strftime("%d/%m/%Y")
                                        raw_link = raw_job.find('a')
                                        if raw_link:
                                            temp = []
                                            temp.append(urljoin(h_url,raw_link.get('href')))
                                            temp.append(post)
                                            All_urls.append(temp)
                                            # for getting next page, end if no pagination is present.
                                            pagination_get_next = soup.find_all('span', {'class': 'np'})
                                            if pagination_get_next:
                                                flag = True
                                                for __pagination in pagination_get_next:
                                                    if 'next' in __pagination.text.lower():
                                                        flag = False
                                                if flag:
                                                    pagination_val = False

                                            pagination = soup.find_all('div', {'class': 'pagination'})
                                            if pagination:
                                                pages = pagination[0].find_all('a')
                                                if pages:
                                                    url_temp = h_url + pages[-1].get('href')
                                                else:
                                                    pagination_val = False
                                    else:
                                        pagination_val = False

        print 'All_urls', len(All_urls)
        All_urls = [list(item) for item in set(tuple(row) for row in All_urls)]
        f = open('Pakistan_urls.txt','wb')
        f.write(str(All_urls))
        f.close()
        Total_data = []
#         with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
#             future_to_url = {executor.submit(self.scrape_job_value, url_jb[0], url_jb[1]): url_jb for url_jb in
#                              list(set(All_urls[:]))}
#             for future in concurrent.futures.as_completed(future_to_url):
#                 url2 = future_to_url[future]
#                 try:
#                     data = future.result()
#                     if data:
#                         Total_data.append(data)
#                 except Exception as exc:
#                     print '=====>', url2, exc
#                     pass
        return Total_data

    def create_main_urls(self, home_url):
        cc = 0
        while cc < 50:
            cc += 1
            try:
                session = requests.session()
                # session.proxies = proxi_get()
                res = session.get(str(home_url), verify=False, headers=self.headers, timeout=40, stream=True)
                if res.status_code == 200:
                    break
            except Exception as e:
                time.sleep(5)
                pass

        if res.status_code == 200:
            main_urls = []
            sou_value = str(res.text)
            soup = BeautifulSoup(sou_value, 'html.parser')
            urls = soup.find_all('a', {'class' : 'icl-NavigationList-link icl-NavigationList--primary '})
            if len(urls)>0:
                for url in urls[:-3]:
                    main_urls.append(home_url.replace('/?sq=1', '') + str(url.get('href')).strip() + '&sort=date')
            main_urls = [m for m in main_urls if 'government' not in m.lower()]
            return main_urls

if __name__ == "__main__":
    obj = Indeed()
#     val = obj.scrape_job_value("https://www.indeed.com.pk/viewjob?jk=f6d78c6116901e14&tk=1cg62o34a944gc50&from=serp&vjs=3", "url_source")
#     print val
    main_url = obj.create_main_urls('https://www.indeed.com.pk/?sq=1')
#     print main_url, len(main_url)
    # pass additional argument days to configure days, by default set to 20 (crawl(main_url[:1]), 30).
    # pass this in case of other urls like usa -> main_url = ['https://www.indeed.com/jobs?q=USA&sort=date']
    # main_url = ['https://www.indeed.com/jobs?q=USA&sort=date']
    data = obj.crawl(main_url[:],15, "https://www.indeed.com.pk")
#     print len(data), data